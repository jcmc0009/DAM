"Consulta A",
(:Obtener el teléfono de todos los socios)
RESULTADO:

<socios cantidad="4">
	<telef>612345678</telef>
	<telef>723456789</telef>
	<telef>634567890</telef>
	<telef>745678901</telef>
</socios>

:)

 
"Consulta B"
(:Obtener el nombre, teléfono del DNI_Sando de Córdoba
FORMATO:
<socio>García Martínez, Ana (723456789)</socio>
<socio>Rodríguez Gómez, Pedro (634567890)</socio>
:)


"Consulta C",
(:Sabemos que el precio que pagan los socios por los servicios que contratan
depende de la antigüedad en el club. Obtener los nombres del socios que pagan menos 65 €
por el servicio de 'Clases de Tenis' junto con el precio que pagan, ordendados desde el 
precio más alto al más bajo
FORMATO
<precio_Tenis precio="60">Rodríguez Gómez, Pedro</precio_Tenis>
<precio_Tenis precio="50">García Martínez, Ana</precio_Tenis>
<precio_Tenis precio="40">López Pérez, Juan</precio_Tenis>
:)



	