package tarea07;

/** Ejercicio 2. Clasificación de mascotas
 * @author Profesor
 */
public class Ejercicio02 {

    public static void main(String[] args) {
        
        //----------------------------------------------
        //    Declaración de variables y constantes
        //----------------------------------------------
        
        // Constantes
        
        final int NUMERO_MASCOTAS = 10;

        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        
        // No se piden datos al usuario, ya que se usa un número fijo de elementos aleatorios
        
        System.out.println("CLASIFICACIÓN DE MASCOTAS");
        System.out.println("-------------------------");

        // Rellenamos la lista con mascotas aleatorias hasta que haya NUMERO_MASCOTAS


        
        //----------------------------------------------
        //               Procesamiento
        //----------------------------------------------
        
        
        
        
        
        //----------------------------------------------
        //            Salida de resultados
        //----------------------------------------------



        
    }

}
