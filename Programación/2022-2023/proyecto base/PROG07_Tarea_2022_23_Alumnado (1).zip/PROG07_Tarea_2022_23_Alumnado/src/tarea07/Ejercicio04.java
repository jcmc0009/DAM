package tarea07;

/** Ejercicio 4. Clasificación de mascotas coincidentes
 * @author Profesor
 */
public class Ejercicio04 {

    public static void main(String[] args) {
        
        //----------------------------------------------
        //    Declaración de variables y constantes
        //----------------------------------------------
        
        // Constantes
        
        final int NUMERO_MASCOTAS = 20;

        
        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        
        // No se piden datos al usuario, ya que se usa un número fijo de elementos aleatorios
        
        System.out.println("CLASIFICACIÓN DE COINCIDENTES");
        System.out.println("-----------------------------");

        // Rellenamos la lista con mascotas aleatorias hasta que haya NUMERO_MASCOTAS

        
        //----------------------------------------------
        //                 Procesamiento
        //----------------------------------------------

        
        
        
        //----------------------------------------------
        //           Salida de resultados
        //----------------------------------------------

        
        
    }

}
