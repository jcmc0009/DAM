package tarea07;

/** Ejercicio 5. Ordenación de mascotas
 * @author Profesor
 */
public class Ejercicio05 {

    public static void main(String[] args) {
        
        //----------------------------------------------
        //    Declaración de variables y constantes
        //----------------------------------------------

        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        
        // No se piden datos al usuario, ya que vamos a introducir unos datos concretos
        

        
        // Mostramos el contenido inicial de la lista
        
        //----------------------------------------------
        //     Procesamiento + Salida de resultados
        //----------------------------------------------

        // Ordenación de la lista por nombre de la mascota (alfabético) y la mostramos por pantalla

        
        // Ordenación de la lista por edades y la mostramos por pantalla

        
        
        // Ordenación de la lista por número de características de las mascotas y la mostramos por pantalla


    }

            
}

