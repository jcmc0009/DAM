package trenes;



/**
 * Clase VagonTren.
 *
 * Esta clase representa un vagon de tren donde se tiene un conjunto de
 * Controles de Servicio para controlar dicho vagón. Para ello esta clase cuenta
 * con un array de objetos de tipo ControlServicio.
 *
 * @author David - IES Trassierra
 * @version 1.0
 */
public class VagonTren {

    /*
     * Atributo companyiaTrenes.
     */

    
    /*
     * Atributo descripcion. 
     */
    
    

    /*
     * Atributo servicios. 
     */

    /*
     * Constructor con tres parámetros companyia, descripción y número de controles
     * de VagonTren. 
     */
    
    


    /*
     * Constructor con tres parámetros companyia, descripción y array de objetos de controles
     * de VagonTren. 
     */


    
    
    /*
     * Método observador (getter) que devuelve el nombre de la compañía 
     */

    
    

    /*
     * Método modificador (setter)  nombre de la compañía 
     */

    
    

    /*
     * Método observador (getter) que devuelve la descripción 
     * 
     */

    
    

    /*
     * Método modificador (setter) que establece la descripción 
     */

    

    /*
     * Método observador (getter) que devuelve el array 
     */

    

    /*
     * Método modificador (setter) que establece el array 
     * 
     */

    
    

    /*
     * Método observador (getter)  número de elementos     
     */

    
    
    
    /*
     * Método observador (getter)  numero de Controles Puerta
     */

    
    
    /*
     * Método observador (getter)  numero de Controles  Tira de Luz 
     */

    
    
    
    /**
     * Método observador (getter) numero de Controles  Ventanilla
     */


    
    /**
     * Método observador (getter) numero de Controles Conjunto Altavoces
     */

    
    /*
     * Método cerrarPuertas 
     *
     */


    /*
     * Método activarTodosServicios 
     */


    /*
     * Método toString 
     */
   

}
