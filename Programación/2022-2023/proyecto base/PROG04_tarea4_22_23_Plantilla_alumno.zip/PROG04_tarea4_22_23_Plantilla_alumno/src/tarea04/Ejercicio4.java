package tarea04;

import java.util.StringTokenizer;

/**
 *
 * @author luisnavarro
 */
//parsea notas y las mete en matriz, calcula medias, etc y si aprobados
public class Ejercicio4 {

    private enum Asignaturas {
        LENGUA, MATEMATICAS, INGLES, HISTORIA, FISICA, LATIN
    };

    public static void main(String[] args) {

        final int NUMERO_ALUMNOS = 30;
        final int NUMERO_NOTAS = 6;
        String leidoDeFichero = "6,6,0,4,10,8\n"
                + "7,7,7,4,2,4\n"
                + "4,7,1,2,3,5\n"
                + "5,10,5,8,5,7\n"
                + "6,3,4,2,1,6\n"
                + "4,8,8,8,8,9\n"
                + "2,4,0,4,5,4\n"
                + "3,1,8,9,8,7\n"
                + "5,3,2,8,7,9\n"
                + "7,3,1,2,8,4\n"
                + "6,8,2,6,10,4\n"
                + "3,3,7,5,6,9\n"
                + "1,7,10,2,1,2\n"
                + "3,5,3,4,8,9\n"
                + "2,3,1,1,2,10\n"
                + "3,1,2,6,3,9\n"
                + "2,9,9,7,0,8\n"
                + "8,9,8,8,2,0\n"
                + "2,4,3,7,6,1\n"
                + "8,0,5,4,7,1\n"
                + "8,8,5,7,1,6\n"
                + "8,0,6,4,10,1\n"
                + "5,6,9,1,2,7\n"
                + "5,6,7,8,6,4\n"
                + "0,7,9,4,9,5\n"
                + "6,4,9,2,8,5\n"
                + "5,1,3,1,10,3\n"
                + "6,6,10,0,2,8\n"
                + "4,7,9,5,3,8\n"
                + "2,5,6,6,8,1";
    }
}