package tarea04;

/**
 *
 * @author luisnavarro
 */
public class Ejercicio2 {
    public static void main(String[] args) {
        
     // final int VUELTAS=2; //Al cifrado/descifrado le doy dos vueltas o hago dos correspondencias consecutivas
        int vueltas=1;
        
        String alfabeto        = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String alfabetoCifrado = "BVWHGZMLXKONIYFSTUCEDPRAQJ";
        
        String textoOriginal = "Doha se suma a las ciudades que han acogido uno de los grandes duelos europeos, los España-Alemania, las dos selecciones que han ganado más veces la Eurocopa (tres), ambas con estrellas en su camiseta (4-1 para los germanos) y qu";
        String textoTraducido = "";
        
        System.out.println("El texto original:"+textoOriginal);
        System.out.println("El texto traducido:"+textoTraducido);
    }
}
