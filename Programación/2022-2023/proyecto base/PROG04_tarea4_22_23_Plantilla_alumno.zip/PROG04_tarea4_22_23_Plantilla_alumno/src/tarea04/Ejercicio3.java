package tarea04;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 *
 * @author luisnavarro
 */
public class Ejercicio3 {

    
    public static void main(String[] args) {

        final int MAXIMO_CARACTERES_POR_LINEA=80;
        String cadenaEntrada = "PA-762-ED & 191#CU-3344-H & 166 # 3344BBF & 136 #RM 437-LU & 122 #A233456L & 156 # RM 437-BB & 132# CD-332-SD&144#RM333-FF&172#DD-333-EE&222#RR-444-WW&148# 4567EBF & 116 ";
        
    }

}
