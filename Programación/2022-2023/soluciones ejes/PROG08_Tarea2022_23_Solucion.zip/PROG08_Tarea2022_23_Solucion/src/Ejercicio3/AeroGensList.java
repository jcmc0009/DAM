/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio3;

import java.util.List;

/**
 *
 * @author profesor
 */
public class AeroGensList {
    List<AeroGenerador> listaAerogen;

    public List<AeroGenerador> getListaAerogen() {
        return listaAerogen;
    }

    public void setListaAerogen(List<AeroGenerador> listaAerogen) {
        this.listaAerogen = listaAerogen;
    }
    
    
}
