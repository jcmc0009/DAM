
package febrero.ejercicio1;

/**
 * Clase Bolsa.
 * @author 
 */
public class Bolsa {
    
    // Atributos de clase
   

    // Atributos de objeto
   
    

    


    public static void main (String args[]) {
        

    }


    
    
}
