package junio.ejercicio2;

/**
 * Interface Transformacion
 * @author 
 */

