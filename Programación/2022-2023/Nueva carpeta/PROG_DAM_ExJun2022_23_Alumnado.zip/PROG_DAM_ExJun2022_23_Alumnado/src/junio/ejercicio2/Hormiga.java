package junio.ejercicio2;

/**
 * Clase Hormiga que hereda de Insecto
 * @author 
 */

    
    
  

