package junio.ejercicio3;

/**
 * 
 *
 * @author 
 */
public class Ejercicio3 {

    public static void main(String[] args) {

        
    }

}
