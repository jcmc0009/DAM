package tarea02;

import java.util.Scanner;

/**
 * Ejercicio 2: Signos del Zodíaco.
 *
 * Programa en Java que solicite al usuario un número de día y un número de mes.
 * Evidentemente el mes debe encontrarse entre 1 y 12 ambos inclusive, y el
 * número de día debe estar entre 1 y el número máximo de días que pueda tener
 * cada mes en concreto (para el mes de Febrero tomaremos como máximo 29; para
 * los meses de Abril, Junio, Septiembre, y Noviembre tomaremos 30; y para el
 * resto de meses 31 ). Si mes o el día introducido no es válido (no está en ese
 * rango), se indicará que la fecha no es correcta, y finalizará el programa
 * mostrando el correspondiente mensaje de error por pantalla.
 *
 * @author Programación DAM y DAW IES Trassierra
 */
public class Ejercicio02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        //----------------------------------------------
        //    Declaración de variables y constantes
        //----------------------------------------------
        // Variables de entrada (aquí se definen las variables que recibirán valores, si fueran necesarias)
        // Variable tipo byte para almacenar el día del mes
        byte dia;

        // Variable tipo byte para almacenar el mes
        byte mes;

        // Constante para el número de días máximo que puede tener cada mes.
        final int MAX_DIAS_MES;

        // Variables de salida (aquí se definen las variables que almacenarán resultados y se mostrarán al usuario, si fueran necesarias)
        // Objeto tipo String (cadena) para almacenar el signo del zodíaco.
        String signo = "";

        // Objeto tipo String (cadena) para almacenar la cadena de salida
        String salida = "";

        // Clase Scanner para petición de datos al usuario a través del teclado
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        System.out.println("Ejercicio 2. Signos del Zodíaco");
        System.out.println("----------------------------------------------------");

        // Se solicita el mes
        System.out.println("Introduce número del MES");
        mes = teclado.nextByte();

        // Se solicita el día del mes
        System.out.println("Introduce el DÍA del mes");
        dia = teclado.nextByte();

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        /*  
         Según el mes elegido asignamos a la constante el número máximo de 
         días que pueden tener. Si el mes no es correcto, se asignarán 31 días y 
         posteriormente se validará el mes. Si no se pone el caso por defecto, el 
         compilador presentará problemas al no haber inicializado. Es decir, 
         en cualquiera de los posibles casos la constante debe tener un valor antes
         de utilizarla.
         */
        switch (mes) {
            // Mes Febrero
            case 2:
                MAX_DIAS_MES = 29;
                break;

            // Meses Abril, Junio, Septiembre y Noviembre
            case 4:
            case 6:
            case 9:
            case 11:
                MAX_DIAS_MES = 30;
                break;

            // Cualquier otro mes no contemplado en los casos anteriores
            default:
                MAX_DIAS_MES = 31;

        } // Fin switch selección máximo días del mes

        /* 
           Se valida si la fecha es correcta, es decir, si el mes está entre 1 y 12 
           inclusive. Y si el día está entre 1 y el número de días máximo para cada 
           mes establecido antes.       
         */
        if (mes < 13 && mes > 0 && dia > 0 && dia < MAX_DIAS_MES) {

            /*
                Según el mes se divide por la fecha que divide cada signo y se asigna
                un valor del horóscopo u otro
             */
            switch (mes) {
                // Enero
                case 1:
                    if (dia >= 21) {
                        signo = "Acuario";
                    } else {
                        signo = "Capricornio";
                    }
                    break;
                // Febrero
                case 2:
                    if (dia >= 20) {
                        signo = "Piscis";
                    } else {
                        signo = "Acuario";
                    }
                    break;

                // Marzo                   
                case 3:
                    if (dia >= 21) {
                        signo = "Aries";
                    } else {
                        signo = "Piscis";
                    }
                    break;

                // Abril
                case 4:
                    if (dia >= 21) {
                        signo = "Tauro";
                    } else {
                        signo = "Aries";
                    }
                    break;
                // Mayo
                case 5:
                    if (dia >= 22) {
                        signo = "Géminis";
                    } else {
                        signo = "Tauro";
                    }
                    break;
                // Junio
                case 6:
                    if (dia >= 23) {
                        signo = "Cáncer";
                    } else {
                        signo = "Géminis";
                    }
                    break;
                // Julio
                case 7:
                    if (dia >= 24) {
                        signo = "Leo";
                    } else {
                        signo = "Cáncer";
                    }
                    break;
                // Agosto
                case 8:
                    if (dia >= 24) {
                        signo = "Virgo";
                    } else {
                        signo = "Leo";
                    }
                    break;
                // Septiembre
                case 9:
                    if (dia >= 24) {
                        signo = "Libra";
                    } else {
                        signo = "Virgo";
                    }
                    break;
                // Octubre
                case 10:
                    if (dia >= 24) {
                        signo = "Escorpio";
                    } else {
                        signo = "Libra";
                    }
                    break;
                // Noviembre
                case 11:
                    if (dia >= 23) {
                        signo = "Sagitario";
                    } else {
                        signo = "Escorpio";
                    }
                    break;
                // Diciembre
                case 12:
                    if (dia >= 22) {
                        signo = "Capricornio";
                    } else {
                        signo = "Sagitario";
                    }
                    break;
            } // Fin switch meses

            //----------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------
            
            /* 
                Se ajusta utilizando el operador ternario si el día es menor que 10
                se concatena un cero para dar el formato de dos dígitos. Idem para
                el caso del mes          
            */
            String diaSalida = (dia < 10) ? "0" + dia : "" + dia;
            String mesSalida = (mes < 10) ? "0" + mes : "" + mes;
            
            // Guardamos la salida en la cadena de salida
            salida = "\nRESULTADO\n---------\nEl signo correspondiente al " + diaSalida + "/" + mesSalida + " es: \t " + signo + "\n";

        } else { // Caso de que la fecha introducida sea incorrecta

            salida = "\nRESULTADO\n---------\nFecha incorrecta\n";
        }

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.printf(salida);

    } // Fin main

} // Fin class
