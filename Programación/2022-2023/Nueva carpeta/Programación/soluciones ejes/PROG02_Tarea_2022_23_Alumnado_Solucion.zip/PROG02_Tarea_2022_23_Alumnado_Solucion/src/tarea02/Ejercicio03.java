package tarea02;

import java.util.Random;
import java.util.Scanner;

/**
 * Ejercicio 3: Juego de las Siete y Media
 *
 * Aplicación para simular el juego de naipes conocido como "Las Siete y Media".
 * El objetivo del juego consiste en sumar puntos hasta conseguir 7,5 puntos y
 * medio solicitando cartas, pero "SIN PASARSE" y se emplea la baraja española
 * de cartas.
 *
 * @author Programación DAM y DAW IES Trassierra
 */
public class Ejercicio03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        //----------------------------------------------
        //    Declaración de variables y constantes
        //----------------------------------------------
        // Variables de entrada (aquí se definen las variables que recibirán valores, si fueran necesarias)
        // Variable para almacenar el objeto Scanner para gestionar la entrada de datos por teclado
        Scanner teclado = new Scanner(System.in);

        // Variable para almacenar el objeto Random para gestionar la generación de números aleatorios
        Random r = new Random();

        // Variable para acumular los valores de las cartas que obtiene el jugador
        float acumulado = 0;

        // Variable para controlar si el jugador decide plantarse
        boolean seguir = true;

        // Variable para acumular el valor de suma de cartas obtenido  por la banca
        float banca;

        System.out.println("Ejercicio 4. Juego Siete y Media");
        System.out.println("----------------------------------------------------");

        /* La clase Random es una clase de Java que nos sirve para generar elementos aleatorios
            en este caso el objeto "r", consigue a través de su método nextInt(número), generar
            un número aleatorio entero entre 0 y número-1, por ejemplo r.nextInt(4), generará 
            un número entero entre 0 y 3, es decir, podrá devolver 0,1,2 o 3 cada vez que se 
            utilice.
            En la siguiente línea generamos un número entre  0 y 3, al que le sumamos 4, de esta
            forma la banca obtendrá siempre un número bastante competivo, entre 4 y 7.
            Posteriormente utilizamos este mismo método sin parámetros, generando un entero entre
            0 y 2 elevado a 32
         */
        // Generamos un número entre 4 y 7.5
        banca = 4 + r.nextInt(4) + ((r.nextInt() % 2 == 0) ? 0f : 0.5f);

        System.out.println("La banca ha jugado, hasta donde te atreves a apostar");

        System.out.println();
        System.out.println("JUEGO");
        System.out.println("---------");
        /*
            Se realiza la petición del cartas al usuario hasta que este se haya 
            pasado de 7.5, o bien, decida plantarse.
            Al no saber el número de veces que se va a repetir el bucle NO se 
            utiliza el for, y al ser mínimo una carta se utiliza do-while
         */
        do {

            // Se genera una carta entre 1 y 12
            int carta = 1 + r.nextInt(12);

            /*
                Si la carta está entre 1 y 7, se asigna el propio valor de la carta,
                el valor es mayor que 9, es decir: 10, 11 o 12, se sumará 0.5 a su
                puntuación acumulada. En el caso de obtener 8 o 9, no se ha d 
                realizar ninguna operación ya que suman 0.
            */
            if (carta < 8) {
                acumulado += carta;
            } else if (carta > 9) {
                acumulado += 0.5;
            }
            
            //----------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------
            
            // Se muestra la carta obtenida
            System.out.println("Ha obtenido " + ((carta < 8) ? "" + carta : ((carta > 9) ? "Una figura (0.5)" : "Carta sin valor (0)")));
            
            // Se muestran los puntos acumulados tras la carta obtenida
            System.out.println("La suma total de sus cartas es: " + acumulado);

            /*
                Antes de ver si el jugador desea una nueva carta, se debe comprobar
                si el jugador ya está pasado, y por tanto no tiene sentido solicitar
                una nueva carta. Si no está pasado, se pregunta si desea seguir 
                jugando o desea plantarse true-seguir; false-plantarse
            */
            if (acumulado < 7.5) {
                System.out.println("Desea seguir (true-false)");
                seguir = teclado.nextBoolean();
            }

        } while (acumulado < 7.5 && seguir);

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");
        
        /* 
            Se comprueba si el jugador se ha salido porque se ha plantado o se ha 
            pasado. Si se ha pasado, se muestra el mensaje correspondiente. Si se
            ha plantado, se debe comprobar el ganador (el que obtiene más puntos).
            En caso de empate gana la banca.
        */
        if (!seguir || (acumulado <= 7.5 && seguir)) {
            if (banca < acumulado) {
                System.out.println("Has ganado: banca(" + banca + ") vs (" + acumulado + ") jugador");
            } else {
                System.out.println("Ha ganado la banca: banca(" + banca + ") vs (" + acumulado + ") jugador");
            }
        } else {
            System.out.println("Ha ganado la banca, te has pasado");

        } // Fin else

    }// Fin main

} // Fin class
