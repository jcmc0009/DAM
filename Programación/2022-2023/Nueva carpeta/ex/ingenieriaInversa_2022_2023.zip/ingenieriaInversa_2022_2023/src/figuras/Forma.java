package figuras;

/**
 *
 * @author Ana Espina Martínez
 */
public interface Forma {
    
    double getArea();
    double getPerimetro();
    
}
