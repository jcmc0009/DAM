package tarea05;

// ------------------------------------------------------------
//                   Clase ComputadorVuelo
// ------------------------------------------------------------
/**
 * <p>Clase que representa el <strong>computador de vuelo</strong>
 * que se interconecta con los sistemas de vuelo de ultraligeros con motor para
 * gestionar las diferentes operaciones de escuelas de vuelo.</p>
 * <p>Los objetos de esta clase permiten almacenar y gestionar la información
 * relativa al estado de la aeronave y la información de vuelo.</p>
 * <p>La clase también posee información general (estática), relativa a las
 * diferentes aeronaves que existen en la escuela, como:</p>
 * <ul>
 * <li><strong>cantidad total de aeronaves</strong> que existen en la
 * escuela</li>
 * <li><strong>cantidad de aeronaves volando</strong> en el momento actual</li>
 * <li><strong>cantidad total</strong> de horas de vuelo de todas las
 * aeronaves</li>
 * </ul>
 *
 * @author profesorado
 */
public class ComputadorVuelo {
    // ------------------------------------------------------------------------
    // Atributos estáticos públicos (inmutables)
    // Pueden ser accedidos desde cualquier caso
    // ------------------------------------------------------------------------

    /**
     * Piloto comandante por defecto * {@value #PILOTO_DEFECTO}.
     */
    public static final String PILOTO_DEFECTO = "Juan Pérez";

    /**
     * Modelo de aeronave por defecto * {@value #MODELO_DEFECTO}.
     */
    public static final String MODELO_DEFECTO = "Cessna 152";

    /**
     * Matrí­cula por defecto * {@value #MATRICULA_DEFECTO}.
     */
    public static final String MATRICULA_DEFECTO = "EC-ABC";

    /**
     * Altitud mí­nima de vuelo {@value #MIN_ALTITUD} (en metros)
     */
    public static final int MIN_ALTITUD = 1000;

    /**
     * Altitud máxima de vuelo {@value #MAX_ALTITUD} (en metros)
     */
    public static final int MAX_ALTITUD = 3000;

    /**
     * Vuelo de escuela {@value #MAX_ALTITUD} (0)
     */
    public static final int VUELO_ESCUELA = 0;

    /**
     * Vuelo privado {@value #MAX_ALTITUD} (1)
     */
    public static final int VUELO_PRIVADO = 1;

    // ------------------------------------------------------------------------
    // Atributos estáticos privados (mutables)
    // No dependen de instancias de objetos particulares y sólo pueden 
    // modificarse desde la propia clase
    // ------------------------------------------------------------------------
    // Cantidad total de aeronaves de la escuela
    private static int numAeronaves = 0;

    // Cantidad total de aeronaves que están volando
    private static int numAeronavesVolando = 0;

    // Número total de horas de vuelo de todas las aeronaves
    private static float numHorasVuelo = 0;

    // ------------------------------------------------------------------------
    // Atributos de objeto inmutables (privados)
    // Representan el estado del objeto pero no pueden cambiar su valor
    // ------------------------------------------------------------------------
    private final String matriculaAeronave; // matrí­cula de la aeronave (en formato EC-ABC)
    private final String modeloAeronave;    // modelo de la aeronave (no puede cambiar durante el tiempo de ejecución).

    // ------------------------------------------------------------------------
    // Atributos de objeto variables (privados)
    // Representan el estado del objeto y pueden cambiar su valor
    // ------------------------------------------------------------------------
    // ------------------------------------------------------------------------
    // Atributos del estado de la aeronave
    // ------------------------------------------------------------------------
    // Representan el estado básico de la aeronave en un momento dado
    // ------------------------------------------------------------------------
    private boolean volando;                // Indica si la aeronave está volando o no (TRUE / FALSE)
    private String piloto;                  // Nombre del piloto
    private int tipoVuelo;                  // Tipo de vuelo (0: escuela, 1: privado)
    private int tiempoTotalVuelo;           // Tiempo de vuelo total (en horas)

    // ------------------------------------------------------------------------
    // Atributos de la información de vuelo
    // ------------------------------------------------------------------------
    // Almacenan información sobre los parámetros de vuelo
    // ------------------------------------------------------------------------
    private int velocidad;                  // Velocidad de la aeronave (en km/h)
    private int rumbo;                      // Rumbo del avión (en grados)
    private int altitud;                    // Altitud de vuelo (en metros

    // ------------------------------------------------------------------------
    // Constructores de la clase
    // ------------------------------------------------------------------------
    /**
     * Constructor con tres parámetros. Crea un objeto
     * <code>ComputadorVuelo</code> y almacena los datos básicos de la aeronave
     * (<b>matrí­cula</b>, <b>modelo</b> y <b>piloto</b>). La <b>matrí­cula</b> debe cumplir el formato
     * correcto (EC-ABC)
     *
     * @param matricula matrí­cula de la aeronave
     * @param modelo odelo de la aeronave
     * @param piloto piloto de la aeronave
     * @throws IllegalArgumentException Si alguno de los parámetros no es válido
     */
    public ComputadorVuelo(String matricula, String modelo, String piloto) throws IllegalArgumentException, NullPointerException {
        // Se comprueba si los atributos recibidos son nulos
        if (matricula == null)
        {
            // Si la matrícula es nula, se lanza la excepción NullPointerException
            throw new NullPointerException("La matrícula de la aeronave no puede ser nula");
        }
        else if (modelo == null)
        {
            // Si el modelo es nulo, se lanza la excepción NullPointerException
            throw new NullPointerException("El modelo de la aeronave no puede ser nulo");
        }
        else if (piloto == null)
        {
            // Si el piloto es nulo, se lanza la excepción NullPointerException
            throw new NullPointerException("El piloto de la aeronave no puede ser nulo");
        }
        
        // Si los atributos no son nulos, comprueba entonces si la matrícula es la cadena vacía
        if (matricula.equals(""))
        {
            // Se lanza una excepción de tipo IllegalArgumentException
            throw new IllegalArgumentException("La matrícula contiene una cadena vacía");
        }
        
        // Si todas las comprobaciones anteriores son satisfactorias, se comprueba ahora el formato de la matrícula
        if (comprobarMatricula(matricula)) {
            // El formato de la matrí­cula es correcta, se inicializa el objeto
            // Inicialización de atributos inmutables
            this.matriculaAeronave = matricula;
            this.modeloAeronave = modelo;

            // Inicialización de las variables de estado (algunas no es necesario inicializarlas, 
            // ya que Java las inicializará con un nulo, en función del tipo de dato).
            this.volando = false;
            this.piloto = piloto;
            this.tipoVuelo = 0;
            this.tiempoTotalVuelo = 0;

            // Inicialización de las variables de información de vuelo (algunas no es necesario inicializarlas, 
            // ya que Java las inicializará con un nulo, en función del tipo de dato).
            this.velocidad = 0;
            this.rumbo = 0;
            this.altitud = 0;

            // Se actualizan los atributos de la clase
            ComputadorVuelo.numAeronaves++;
        } 
        else 
        {
            // El formato de la matrí­cula es incorrecto. Se lanza una excepción de tipo IllegalArgumentException
            // Se lanza la excepción
            throw new IllegalArgumentException("El fomato de la matrícula es incorrecto: " + matricula);
        }
    }

    /**
     * Constructor con dos parámetros. Crea un objeto
     * <code>ComputadorVuelo</code> y almacena los datos básicos de la aeronave
     * (<b>matrí­cula</b>, <b>modelo</b>). La <b>matrí­cula</b> debe cumplir el
     * formato correcto (EC-ABC)
     *
     * @param matricula matrí­cula de la aeronave
     * @param modelo odelo de la aeronave
     * @throws IllegalArgumentException Si alguno de los parámetros no es válido
     */
    public ComputadorVuelo(String matricula, String modelo) throws IllegalArgumentException, NullPointerException {
        // Se inicialzia el objeto utilizando el constructor de 3 parámetros pasando el valor de pic por defecto
        this(matricula, modelo, ComputadorVuelo.PILOTO_DEFECTO);
    }

    /**
     * Constructor sin parámetros. Crea un objeto <code>ComputadorVuelo</code>
     * con los valores por defecto
     */
    public ComputadorVuelo() throws IllegalArgumentException, NullPointerException {
        // Se utiliza el constructor con 3 parámetros y recibe los valores por defecto
        this(ComputadorVuelo.MATRICULA_DEFECTO, ComputadorVuelo.MODELO_DEFECTO, ComputadorVuelo.PILOTO_DEFECTO);
    }

    /**
     * Método fábrica que crea un array de objetos ComputadorVuelo, que
     * representa, cada uno de ellos, a una aeronave. Internamente, crea un
     * array de referencias a objetos de tipo <code>ComputadorVuelo</code> con
     * los parámetros por omisión
     *
     * @param cantidad tamaí±o del array
     * @return array vector de referencias a las aeronaves de la escuela
     * @throws IllegalArgumentException Si la cantidad es inferior a 1 o
     * superior a 10
     */
    public static ComputadorVuelo[] crearArrayComputadorVuelo(int cantidad) throws IllegalArgumentException {
        // Se comprueba la cantidad recibida como parámetro
        if (cantidad < 1 || cantidad > 10) {
            // Se lanza una excepción porque la cantidad no es correcta
            throw new IllegalArgumentException("Número de aviones incorrecto " + cantidad + ", debe ser mayor o igual que 1 y menor o igual que 10");
        }

        // Se crea el vector de referencias
        ComputadorVuelo[] arrayDispositivos = new ComputadorVuelo[cantidad];

        // Se inicializa cada una de las aeronaves con sus valores por defecto
        for (int i = 0; i < arrayDispositivos.length; i++) {
            arrayDispositivos[i] = new ComputadorVuelo();
        }

        // Se devuelve el vector generado
        return arrayDispositivos;
    }

    /**
     * Método de utilidad que comprueba si la matrí­cula recibida como parámetro
     * es correcta y cumple el formato indicado. Devuelve false si no es
     * correcta y true si es correcta
     *
     * @param matricula matrí­cula de la aeronave
     * @return <b>true</b> (si la matrí­cula es correcta) o <b>false</b> (en
     * caso contrario)
     */
    private boolean comprobarMatricula(String matricula) {
        // Se comprueba si contiene el prefijo "EC", el guión y tiene 6 caracteres de longitud como máximo
        return !(!matricula.startsWith("EC-") || !(matricula.length() == 6));
    }

    // ------------------------------------------------------------------------
    // Getters (consultan el estado del objeto)
    // ------------------------------------------------------------------------
    /**
     * Devuelve la matrícula de la aeronave
     *
     * @return String matrícula de la aeronave
     */
    public String getMatricula() {
        if (matriculaAeronave != null)
            return this.matriculaAeronave;
        else
            return MATRICULA_DEFECTO;
    }

    /**
     * Devuelve el modelo de la aeronave
     *
     * @return String modelo de la aeronave
     */
    public String getModelo() {
        if (modeloAeronave != null)
            return this.modeloAeronave;
        else
            return MODELO_DEFECTO;
    }

    /**
     * Devuelve el estado de la aeronave (si está volando o no)
     *
     * @return boolean Indica si la aeronave está volando o no (TRUE / FALSE)
     */
    public boolean isVolando() {
        return this.volando;
    }

    /**
     * Devuelve el nombre del piloto comandante
     *
     * @return String nombre del piloto comandante
     */
    public String getPiloto() {
        if (piloto != null)
            return this.piloto;
        else
            return PILOTO_DEFECTO;
    }

    /**
     * Devuelve el tipo de vuelo
     *
     * @return int Tipo de vuelo (0: escuela, 1: privado)
     */
    public int getTipoVuelo() {
        return this.tipoVuelo;
    }

    /**
     * Devuelve el tiempo de vuelo total
     *
     * @return int Tiempo de vuelo total (en horas)
     */
    public int getTiempoTotalVuelo() {
        return this.tiempoTotalVuelo;
    }

    /**
     * Devuelve la velocidad de la aeronave
     *
     * @return int Velocidad de la aeronave
     */
    public int getVelocidad() {
        return this.velocidad;
    }

    /**
     * Devuelve la rumbo de la aeronave
     *
     * @return int Curso de la aeronave
     */
    public int getRumbo() {
        return this.rumbo;
    }

    /**
     * Devuelve la altitud de la aeronave
     *
     * @return int Altitud de la aeronave
     */
    public int getAltitud() {
        return this.altitud;
    }
    
    // ------------------------------------------------------------------------
    // Métodos estáticos (acceden a los atributos estáticos de la clase)
    // ------------------------------------------------------------------------
    /**
     * Devuelve el número de aeronaves de la escuela
     *
     * @return int Número de aeronaves de la escuela
     */
    public static int getNumAeronaves() {
        return ComputadorVuelo.numAeronaves;
    }

    /**
     * Devuelve la cantidad total de aeronaves que están volando
     *
     * @return int Cantidad de aeronaves que están volando
     */
    public static int getNumAeronavesVolando() {
        return ComputadorVuelo.numAeronavesVolando;
    }

    /**
     * Devuelve el número de horas totales de vuelo de la escuela
     *
     * @return int Altitud de la aeronave
     */
    public static float getNumHorasVuelo() {
        return ComputadorVuelo.numHorasVuelo;
    }
    
    // ------------------------------------------------------------------------
    // Setters (modifican el estado del objeto)
    // ------------------------------------------------------------------------
    /**
     * Modifica la velocidad de la aeronave
     *
     * @param velocidad Velocidad de la aeronave
     */
    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }
    
    /**
     * Modifica el rumbo de la aeronave
     *
     * @param rumbo Rumbo de la aeronave
     */
    public void setRumbo(int rumbo) {
        this.rumbo = rumbo;
    }
    
    /**
     * Modifica la altitud de la aeronave
     *
     * @param altitud Altitud de la aeronave
     */
    public void setAltitud(int altitud) {
        // Se comprueba que la altitud esté dentro de los parámetros establecidos
        if (altitud < MIN_ALTITUD || altitud > MAX_ALTITUD)
        {
            // La altitud introducida no es correcta, asignamos una altitud dentro del intervalo
            this.altitud = MIN_ALTITUD;
        }
        else
        {
            // Se asigna la altitud
            this.altitud = altitud;
        }
    }

    // ------------------------------------------------------------------------
    // Métodos de "acción" (almacenan la lógica y el comportamiento del objeto)
    // ------------------------------------------------------------------------
    /**
     * Registra la maniobra de despegue e inicializa un nuevo vuelo en la
     * aeronave
     *
     * @throws IllegalStateException Si el avión ya ha despegado previamente
     * @param tipoVuelo Tipo de vuelo (0: escuela, 1: privado)
     * @param velocidad Velocidad de vuelo
     * @param altitud Altitud de vuelo
     */
    public void despegar(int tipoVuelo, int velocidad, int altitud) throws IllegalStateException, IllegalArgumentException {
        // Se comprueba primero el parámetro de la altitud
        if (altitud < MIN_ALTITUD || altitud > MAX_ALTITUD)
        {
             // Se lanza una excepción porque la altitud es incorrecta
            throw new IllegalArgumentException("La altitud de vuelo de " + altitud + " metros es incorrecta");
        }
        
        // Se comprueba si el avión está volando
        if (!isVolando()) {
            // Se cambia el estado del avión
            this.volando = true;

            // Se modifican los parámetros de vuelo
            this.velocidad = velocidad;
            this.altitud = altitud;
            this.tipoVuelo = tipoVuelo;

            // Se modifican los atributos de clase (número de aeronaves volando)
            ComputadorVuelo.numAeronavesVolando++;
        } else {
            // Se lanza una excepción porque el avión ya está volando
            throw new IllegalStateException(getMatricula() + " ya ha despegado y se encuentra fuera del aeropuerto");
        }
    }

    /**
     * Registra la maniobra de aterrizaje y finaliza el vuelo de la aeronave
     *
     * @throws IllegalStateException Si el registro de vuelo está lleno o si el
     * avión ya ha aterrizado previamente
     * @param aeropuertoSalida Aeropuerto de salida (ejemplo: LEBA; LEDE,
     * LEDL...)
     * @param aeropuertoLlegada Aeropuerto de salida (ejemplo: LEBA; LEDE,
     * LEDL...)
     * @param tiempoVuelo Tipo de vuelo (0: escuela, 1: privado)
     */
    public void aterrizar(String aeropuertoSalida, String aeropuertoLlegada, int tiempoVuelo) throws IllegalStateException {
        // Se comprueba si el avión está volando previamente
        if (isVolando()) {
            // Se cambia el estado del avión para detener el vuelo
            this.volando = false;

            // Se modifican los parámetros de vuelo
            this.velocidad = 0;
            this.altitud = 0;

            // Se modifican los atributos de clase (número de aeronaves volando)
            ComputadorVuelo.numAeronavesVolando--;

            // Se actualiza el tiempo de vuelo
            this.tiempoTotalVuelo += tiempoVuelo;

            // Se actualiza también el número de horas totales de la escuela
            ComputadorVuelo.numHorasVuelo += (tiempoVuelo / 60.0);
        } else {
            // Se lanza una excepción porque el avión está en tierra y debe despegar de nuevo antes de volver a aterrizar
            throw new IllegalStateException(getMatricula() + " ya ha aterrizado y debe despegar de nuevo antes de volver a aterrizar");
        }
    }

    /**
     * Devuelve el estado del objeto en un mensaje formateado en un tipo String
     *
     * @return String Estado del objeto
     */
    @Override
    public String toString() {
        // Se utiliza un objeto de tipo StringBuilder para formatear el estado de la aeronave
        StringBuilder estado = new StringBuilder();

        // Se añade la información del estado de la aeronave
        estado.append("[");
        estado.append(String.format("Matricula=%s, ", this.matriculaAeronave));
        estado.append(String.format("Modelo=%s, ", this.modeloAeronave));
        estado.append(String.format("isVolando=%s, ", this.volando));
        estado.append(String.format("Piloto=%s, ", this.piloto));
        estado.append(String.format("TipoVuelo=%s, ", this.tipoVuelo));
        estado.append(String.format("TiempoTotal=%s, ", this.tiempoTotalVuelo));
        estado.append(String.format("V=%s km/h, ", this.velocidad));
        estado.append(String.format("Rumbo=%sº, ", this.rumbo));
        estado.append(String.format("Altitud=%s metros]", this.altitud));

        // Se devuelve el estado formateado como una cadena
        return estado.toString();
    }
}
