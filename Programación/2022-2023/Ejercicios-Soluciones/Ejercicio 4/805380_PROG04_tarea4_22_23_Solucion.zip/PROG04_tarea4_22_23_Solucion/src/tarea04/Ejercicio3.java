package tarea04;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * Ejercicio 3. Capturas de Radar
 * @author David Martin -IES Trassierra
 */
public class Ejercicio3 {

    public static void main(String[] args) {

        System.out.println("Ejercicio 3 - Ajustando el nuevo radar de la DGT\n");

        // Punto 0. Declaración de constantes y variables
        // Declaración de constantes
        final String MEDICIONES = "PA-762-ED & 191#CU-3344-H & 166 # 3344BBF & 136 #RM 437-LU & 122 #A233456L & 156 #RM 437-BB & 132# CD-332-SD&144#RM333-FF&172#DD-333-EE&222#RR-444-WW&148# 4567EBF & 116 ";
        final int MAX_CARACTERES_LINEA = 80;
        final int[][] TABLA_MULTAS = {{15, 100}, {30, 200}, {40, 300}, {50, 500}};

        //----------------------------------------------------------------------
        //                     Declaración de variables
        //----------------------------------------------------------------------
        // Necesitaremos, al menos, las siguientes variables:
        // Definir un StringTokenizer para recorrer la cadena de mediciones y 
        // poder trocearlo asignando la cadena de mediciones y utilizando # 
        // como separador
        StringTokenizer tokenizerCoches = new StringTokenizer(MEDICIONES, "#");

        // StringTokenizer para separar una medición concreta en matrícula y velocidad
        // la separación se recorrer la cadena de mediciones y poder 
        StringTokenizer tokenizerMedicion;

        // Una variable entera para almacenar cuantos coches se han medido
        // busca en la API un método que te permita contar cuantos token 
        // tiene una instancia StringTokenizer según el separador indicado
        int numeroCoches = tokenizerCoches.countTokens();

        // Un array de instancias CapturaRadar. Las instancias de CapturaRadar nos 
        // servirán para almacenar en objetos de ese tipo  la información de pais, 
        // velocidad y matrícula de cada medición (para ver su constructor consulta 
        // la API en el JavaDoc proporcionado. El tamaño de este array será 
        // igual al número de Coches que se han medido
        CapturaRadar[] cochesCapturadosRadar = new CapturaRadar[numeroCoches];

        // Una instancia de CapturaRadar para almacenar una medición individual
        CapturaRadar unaMedida;

        // Una instancia de CapturaRadar.Paises para almacenar el país de una medición
        CapturaRadar.Paises paisLeido;

        // Otro array de instancias CapturaRadar para guardar los coches multados
        CapturaRadar[] cochesMultados = new CapturaRadar[numeroCoches];

        // Array de enteros para almacenar el importe de la multa de cada coche
        int[] cuantiaMultas = new int[numeroCoches];

        // Scanner para pedir datos
        Scanner teclado = new Scanner(System.in);

        // Otras variables auxiliares para guardar límites de velocidad, velocidades
        // cantidad de multados o importe de las multas, etc.
        // (puedes crear las que necesites según tu planteamiento)
        int limiteVelocidad = 0, velocidadMedida = 0;
        int multa;
        int numeroMultados = 0, sumaMultas = 0;
        boolean entradaValida = false;
        int medicionesLeidas = 0;
        int velocidadLeida;
        String matricula;
        String continuar;
        int j = 0;

        do {
            //----------------------------------------------------------------------
            //                     Entrada de Datos
            //----------------------------------------------------------------------
            // Punto 1. Pedimos al usuario el límite de velocidad (controlamos excepciones)
            do {
                try {
                    System.out.print("Introduce el límite de velocidad a partir del que se establece la multa: ");
                    limiteVelocidad = teclado.nextInt();
                    entradaValida = true;
                    teclado.nextLine(); // limpiar el buffer
                } catch (InputMismatchException e) {
                    System.err.println("ERROR! Por favor, introduce un valor numérico");
                    teclado.nextLine(); // limpiar el buffer
                }

            } while (!entradaValida);

            System.out.println("");

            //----------------------------------------------------------------------
            //                        Procesamiento
            //----------------------------------------------------------------------
            sumaMultas = 0;
            numeroMultados = 0;

            // Punto 2. recorrer el tokenizer mientras siga habiendo tokens sin recorrer
            while (tokenizerCoches.hasMoreTokens()) {

                // Punto 2.1 Extraer una medición individual (el separador será &);
                tokenizerMedicion = new StringTokenizer(tokenizerCoches.nextToken(), "&");

                // Punto 2.1.1 Leer el primer token de esa medición (será la matrícula)
                // Es interesante eliminar los espacios del dato leído con el método trim
                matricula = tokenizerMedicion.nextToken().trim();

                // Punto 2.1.2 Leer el segundo token de esa medición (será la velocidad, valor entero)
                velocidadLeida = Integer.parseInt(tokenizerMedicion.nextToken().trim());

                // Identificar la matrícula según los patrones descritos en el enunciado
                if (matricula.matches("[0-9]{4}[A-Z]{3}")
                        || matricula.matches("[A-Z]{1,2}\\-[0-9]{4}\\-[A-Z]{1,2}")) {
                    paisLeido = CapturaRadar.Paises.ESPAÑA;
                } else if (matricula.matches("[A-Z]{2}\\ [0-9]{3}\\-[A-Z]{2}")) {
                    paisLeido = CapturaRadar.Paises.ITALIA;
                } else if (matricula.matches("[A-Z]{2}\\-[0-9]{3}\\-[A-Z]{2}")) {
                    paisLeido = CapturaRadar.Paises.FRANCIA;
                } else {
                    paisLeido = CapturaRadar.Paises.OTRO;
                }

                // Punto 2.1.4. Creamos la instancia de CapturaRadar con los datos obtenidos
                unaMedida = new CapturaRadar(paisLeido, velocidadLeida, matricula);

                // Punto 2.1.5 Almacenamos la instancia de CapturaRadar el array de CapturaRadar
                cochesCapturadosRadar[medicionesLeidas] = unaMedida;

                // Punto 2.1.6 Incrementamos el contador de mediciones ya que hemos leído una
                medicionesLeidas++;
            }

            /* Punto 3. A continuación, vamos a recorrer el array de CapturaRadar para ver 
             a qué coches hay que multar según el límite establecido
             */
            for (int i = 0; i < numeroCoches; i++) {

                // Punto 3.1 Obtenemos la velocidad de la captura 
                velocidadMedida = cochesCapturadosRadar[i].getVelocidadCaptura();

                //  Punto 3.2. Si la velocidad de captura es superior al límite debemos calcular
                // el importe de la multa. Según la diferencia entre la velocidad
                // medida y ese límite establecido el importe será 100, 200, 300 o 500€
                if (velocidadMedida > limiteVelocidad) {

                    // Punto 3.2.1. Cálculo del porcentaje
                    multa = 0;
                    int diferencia = velocidadMedida - limiteVelocidad;
                    double porcentajeExceso = (double) (diferencia * 100 / limiteVelocidad);

                    /* Punto 3.2.2. calculamos el porcentaje de velocidad en que se ha excedido el vehículo
                     empezamos a multar a partir del 15% (si el exceso es menor, no lo multamos)
                     debemos recorrer la tabla de multas e identificar a qué tramo de multa corresponde el exceso
                     */
                    if (porcentajeExceso > 15) {

                        multa = 0;
                        // Punto 3.2.2.1 Recorremos la tabla de multas 
                        for (j = 0; j < TABLA_MULTAS.length; j++) {
                            if (porcentajeExceso > TABLA_MULTAS[j][0]) {
                                multa = TABLA_MULTAS[j][1];
                            }
                        }

                        /// Punto 3.2.2.2 almacenamos el vehículo multado en el array de coches multados
                        cochesMultados[numeroMultados] = cochesCapturadosRadar[i];

                        /// Punto 3.2.2.3 sumamos la multa al array de multas
                        cuantiaMultas[numeroMultados] = multa;

                        // Punto 3.2.2.4 incrementamos el acumulador total de las multas
                        sumaMultas += multa;

                        // Punto 3.2.2.5 hemos multado a un coche --> incrementamos el contador de coches multados
                        numeroMultados++;

                    }
                }

            }

            //----------------------------------------------------------------------
            //            Salida de resultados
            //----------------------------------------------------------------------
            // Punto 4. Mostramos la cadena de entrada con un máximo de 80 caracteres por línea
            // Primera forma
            System.out.println("La cadena original ofrecida por el radar es\n");
            for (int i = 0; i < MEDICIONES.length(); i++) {
                System.out.print(MEDICIONES.charAt(i));
                if (i % MAX_CARACTERES_LINEA == MAX_CARACTERES_LINEA - 1) // a los 80 caracteres
                {
                    System.out.println(""); // salto de línea
                }
            }

            // Segunda forma
            for (j = 0; j < MEDICIONES.length() / MAX_CARACTERES_LINEA; j++) {
                System.out.println(MEDICIONES.substring(j * MAX_CARACTERES_LINEA, MAX_CARACTERES_LINEA * (j + 1)));
            }
            System.out.println(MEDICIONES.substring(j * MAX_CARACTERES_LINEA));

            // Imprimimos el array de instancias creado a partir de los datos del Radar 
            System.out.println("\nUna vez procesados, los datos que hemos obtenido son:\n");
            System.out.println(Arrays.toString(cochesCapturadosRadar));

            // Mostramos la información de los coches multados (Punto 6)
            System.out.println("Vamos a simular las multas que se establecerían para los coches que superen " + limiteVelocidad + "km/h\n");
            if (numeroMultados > 0) {
                // Punto 6.1 si hay multas se muestra información del vehículo multado (matrícula, velocidad, país y cuantía de la multa)
                for (int i = 0; i < numeroMultados; i++) {
                    double velocidadVehiculo = cochesMultados[i].getVelocidadCaptura();
                    double exceso = cochesMultados[i].getVelocidadCaptura() - limiteVelocidad;
                    double porcentajeExceso = Math.round(exceso * 100 / limiteVelocidad);

                    System.out.println("Matrícula: " + cochesMultados[i].getMatricula()
                            + "\t- Velocidad: " + velocidadVehiculo
                            + "km/h (exceso de " + exceso + "km/h, " + porcentajeExceso + "%)"
                            + " -\tPaís: " + cochesMultados[i].getPais() + " -\tMulta: " + cuantiaMultas[i] + "€");
                }

                // Punto 6.2. Por último, a modo de resumen se muestra el total de coches multados, el importe total de las multas y el importe medio de la multa
                System.out.println("\nSe han encontrado " + numeroMultados + " coches multados");
                System.out.println("La cuantía total de las multas es de " + sumaMultas + "€");
                System.out.println("El importe medio de la multa es de " + ((sumaMultas) / numeroMultados) + "€\n");

            } else {
                // si no hay multas se indica mediante un mensaje
                System.out.println("-- Ningún coche ha superado el límite establecido, por tanto no hay multas -- \n");
            }

            // Punto 7, preguntamos para simular una nuevo límite de velocidad.
            System.out.print("\n\n¿Desea simular otro límite de velocidad? ");

            continuar = teclado.nextLine();

        } while (continuar.equalsIgnoreCase("SI"));
    }
}
