package tarea04;

import java.util.Scanner;

/**
 * Ejercicio 2. Cifrado y Descifrado.
 * @author David Martin -IES Trassierra
 */
public class Ejercicio2 {

    public static void main(String[] args) {
        // 0 Declaración de variables
        int vueltas = 2;

        String alfabeto = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String alfabetoCifrado = "BVWHGZMLXKONIYFSTUCEDPRAQJ";

        String textoOriginal = "Doha se suma a las ciudades que han acogido uno de los grandes duelos europeos, los España-Alemania, las dos selecciones que han ganado más veces la Eurocopa (tres), ambas con estrellas en su camiseta (4-1 para los germanos) y qu";
        String textoTraducido = "";
        StringBuilder resultado = new StringBuilder("");
        char caracterCifrado;
        String cifrarDescifrar;
        Scanner tecladoNumeros = new Scanner(System.in);
        Scanner tecladoLetras = new Scanner(System.in);
        String textoMayusculas;

        System.out.println("Cifrado de Cadenas. Varias Vueltas");
        // Selección de datos de entrada 
        // 1. Selección de Cifrado o Descifrado. Verificando si es C o D (tanto mayúscula como minúscula)
        do {
            System.out.println("Quiere cifrar o descifrar ('C' o 'D')");
            cifrarDescifrar = tecladoLetras.nextLine();
        } while (cifrarDescifrar.compareToIgnoreCase("C") != 0 && cifrarDescifrar.compareToIgnoreCase("D") != 0);

        // 2.Selección de número de vueltas entre 2 y 5
        do {
            System.out.println("Introduce el número de vueltas de cifrado o descifrado");
            vueltas = tecladoNumeros.nextInt();
        } while (vueltas < 2 || vueltas > 5);

        // 3. Introducción del texto para  el cifrado
        System.out.println("Dígame el texto a " + ((cifrarDescifrar.compareToIgnoreCase("C") == 0) ? "cifrar" : "descifrar"));
        textoOriginal = tecladoLetras.nextLine();

        // 4. Se pasa  el texo introducido a mayúsculas
        textoMayusculas = textoOriginal.toUpperCase();

        // 5. Si vamos a cifrar o descifrar elegimos un camino y otro
        
        if (cifrarDescifrar.compareToIgnoreCase("C") == 0) {            // Cifrar
            for (int j = 0; j < vueltas; j++) {
                 
                 // 5.1 Empezamos por el cifrado. Se debe recorrer caracter a caracter del texto a cifrar
                 
                resultado.delete(0, resultado.length());
                for (int i = 0; i < textoMayusculas.length(); i++) {
                    // 5.1.1 Obtenemos cada caracter de la cadena en mayúscula
                    char caracterOriginal = textoMayusculas.charAt(i);
                    // 5.1.2 Se obtiene la posición en el alfabero del caracter de la cadena original en mayúscula que estamos recorriendo
                    int posAlfabeto = alfabeto.indexOf(caracterOriginal);
                    // 5.1.3 Se debe comprobar si la posición es superior a 0, lo que nos indica que tenemos caracter para traducir. Si no la encontramos, la dejamos sin cifrar, ya que será un caracter "raro", espacio, guión, etc.
                    if (posAlfabeto >= 0) {
                        // 5.1.3.1 Obtenemos el caracter en alfabetoCifrado que se encuentr en la posición obtenida del alfabeto original
                        caracterCifrado = alfabetoCifrado.charAt(posAlfabeto);
                    } else {
                         // 5.1.3.2 Caracter raro se agrega tal cual
                        caracterCifrado = caracterOriginal;
                    }
                    // 5.1.4 Añadimos ese caracter cifrado al StringBuilder resultado
                    resultado.append(caracterCifrado);
                }
                
                textoTraducido = resultado.toString();
                System.out.println("El texto original vuelta " + j + ":" + textoMayusculas);
                System.out.println("El texto traducidovuelta " + j + ":" + textoTraducido);
                textoMayusculas = textoTraducido;
            }

        } else {            // Descifrar

            for (int j = 0; j < vueltas; j++) {
                resultado.delete(0, resultado.length());
                 // 5.2 Descifrado. Se debe recorrer caracter a caracter del texto a descifrar

                for (int i = 0; i < textoMayusculas.length(); i++) {
                     // 5.2.1 Obtenemos cada caracter de la cadena en mayúscula

                    char caracterOriginal = textoMayusculas.charAt(i);
                    // 5.1.2 Se obtiene la posición en el alfaberoCifrado del caracter de la cadena original en mayúscula que estamos recorriendo

                    int posAlfabeto = alfabetoCifrado.indexOf(caracterOriginal);
                    // 5.2.3 Se debe comprobar si la posición es superior a 0, lo que nos indica que tenemos caracter para traducir. Si no la encontramos, la dejamos sin descifrar, ya que será un caracter "raro", espacio, guión, etc.

                    if (posAlfabeto >= 0) {
                    // 5.2.3.1 Obtenemos el caracter en alfabeto que se encuentre en la posición obtenida del alfabetoCifrado original

                        caracterCifrado = alfabeto.charAt(posAlfabeto);
                    } else {
                        caracterCifrado = caracterOriginal;
                    }
                    // 5.2.4 Añadimos ese caracter descifrado al StringBuilder resultado
                    resultado.append(caracterCifrado);
                }
                textoTraducido = resultado.toString();
                System.out.println("El texto original vuelta " + j + ":" + textoMayusculas);
                System.out.println("El texto traducido vuelta " + j + ":" + textoTraducido);
                textoMayusculas = textoTraducido;
            }
        }
        // 6. Se muestran los resultados.

    }
}
