package tarea04;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Ejercicio 1. Generación de correspondencia cifrado.
 * @author David Martin -IES Trassierra
 */
public class Ejercicio1 {

    public static void main(String[] args) {
        
        // Creamos las variables necesarias

        String alfabeto = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        String[] palabrasProhibidas = {"STAR", "THE", "AL", "DE", "AS"};

        StringBuilder alfabetoManejable = new StringBuilder(alfabeto);

        StringBuilder correspondencia = new StringBuilder();

        Random aleatorio = new Random();

        int i = 0;

        System.out.println("Cifrado. Generación de correspondencia entre alfabeto origen y destino.");

        // Creamos una variable booelana para controlar si la correspondencia creada es válida.
        boolean continuar = true;

        // 1. Repetiremos el proceso de do-while hasta que tengamos una correspondencia válida
        do {
            
            // 1.1 Creamos los StringBuilder necesarios uno de ellos con el alfabeto
            System.out.println("");

            alfabetoManejable = new StringBuilder(alfabeto);
            correspondencia = new StringBuilder();
            continuar = true;
            
            // 1.2 Mientras haya letras en nuestro alfabeto manejable elegimos y sacamos letras
            while (alfabetoManejable.length() > 0) {
                
                // 1.2.1 Elegimos una posición aleatoria entre 0 y el tamaño de nuestro alfabeto manejable

                int indiceAleatorio = aleatorio.nextInt(alfabetoManejable.length());

                // 1.2.2 Obtenemos el caracter de la posición elegida
                char caracterAleatorio = alfabetoManejable.charAt(indiceAleatorio);

                // 1.2.3 Añadimos ese caracter a nuestro StringBuilder de correspondencia
                correspondencia.append(caracterAleatorio);

                // 1.2.4 Eliminamos el caracter de la posición elegida de nuestro alfabeto manejable

                alfabetoManejable = alfabetoManejable.deleteCharAt(indiceAleatorio);

            }
            
            // 1.3 Ahora comprobamos que la correspondencia generada es válida, primero con las palabras prohibidas

            System.out.println("Intento de correspondencia: " + correspondencia);

            while (i < palabrasProhibidas.length && continuar) {

                if (correspondencia.toString().contains(palabrasProhibidas[i])) {

                    StringBuilder reemplazo = new StringBuilder("");
                    for (int k = 0; k < palabrasProhibidas[i].length(); k++) {
                        reemplazo.append("*");
                    }

                    System.out.println("Palabra Prohibida: " + palabrasProhibidas[i] + ":" + correspondencia.toString().replace(palabrasProhibidas[i], reemplazo));
                    continuar = false;

                }
                i++;

            }
            
            // 1.4 Ahora comprobamos que la correspondencia generada es válida, primero con el patrón vocal-consonante-vocal

            System.out.println("");

            Pattern patron = Pattern.compile("[AEIOU][BCDFGHJKLMNPQRSTVXZWY][AEIOU]");
            Matcher texto = patron.matcher(correspondencia);

            while (texto.find() && continuar) {
                System.out.println("Patrón de una sola consonante entre dos vocales encontrado=" + texto.replaceAll("***"));
                continuar = false;

            }
        } while (!continuar);

        // 2. Una vez llegados a este punto 2, hemos generado una correspondecia válida y mostramos el resultado
        System.out.println("Ya se ha generado una correspondencia válida.");
        System.out.println("Las letras correspondientes a: " + alfabeto);
        System.out.println("Son las siguientes en orden..: " + correspondencia);

        System.out.println("");
        System.out.println("Letra sin codificar-------Letra codificada");

        for (int j = 0; j < alfabeto.length(); j++) {
            System.out.println(alfabeto.charAt(j) + "-----------------" + correspondencia.charAt(j));
        }
    }
}
