package tarea04;

import java.util.StringTokenizer;

/**
 * Ejercicio 4. Análisis de calificaciones y Estadísticas
 * @author IES Trassierra
 */

public class Ejercicio4 {

    public static void main(String[] args) {

        System.out.println("Ejercicio 4 - Análisis de calificaciones y Estadísticas\n");

        //----------------------------------------------------------------------
        //                     Declaración de variables
        //----------------------------------------------------------------------        
        
        // Punto 0. Declaración de variables y constantes
        
        final int NUMERO_ALUMNOS = 30;
        final int NUMERO_NOTAS = 6;
        final String NOTAS_ALUMNOS =  "6,6,0,4,10,8\n"
                                    + "7,7,7,4,2,4\n"
                                    + "4,7,1,2,3,5\n"
                                    + "5,10,5,8,5,7\n"
                                    + "6,3,4,2,1,6\n"
                                    + "4,8,8,8,8,9\n"
                                    + "2,4,0,4,5,4\n"
                                    + "3,1,8,9,8,7\n"
                                    + "5,3,2,8,7,9\n"
                                    + "7,3,1,2,8,4\n"
                                    + "6,8,2,6,10,4\n"
                                    + "3,3,7,5,6,9\n"
                                    + "1,7,10,2,1,2\n"
                                    + "3,5,3,4,8,9\n"
                                    + "2,3,1,1,2,10\n"
                                    + "3,1,2,6,3,9\n"
                                    + "2,9,9,7,0,8\n"
                                    + "8,9,8,8,2,0\n"
                                    + "2,4,3,7,6,1\n"
                                    + "8,0,5,4,7,1\n"
                                    + "8,8,5,7,1,6\n"
                                    + "8,0,6,4,10,1\n"
                                    + "5,6,9,1,2,7\n"
                                    + "5,6,7,8,6,4\n"
                                    + "0,7,9,4,9,5\n"
                                    + "6,4,9,2,8,5\n"
                                    + "5,1,3,1,10,3\n"
                                    + "6,6,10,0,2,8\n"
                                    + "4,7,9,5,3,8\n"
                                    + "2,5,6,6,8,1";
        
        /* Array doble para almacenar las notas (tendrá una columna más que el número de notas y una fila más que el número de alumnos).
           - En la última columna de cada fila se almacenará la nota media de ese alumno (se consideran solo valores enteros)
           - En la última fila se almacenará en cada columna el número de suspensos de cada asignatura
        */
        int[][] notasAlumnos = new int[NUMERO_ALUMNOS + 1][NUMERO_NOTAS + 1];
        
        
        /* Dos arrays para almacenar:
            - Las notas medias de cada asigntaura
            - El número de asignaturas suspensas de cada alumno
        */
        int[] notaMediaAsignatura = new int[NUMERO_NOTAS];
        int[] numeroSuspensasAlumno = new int[NUMERO_ALUMNOS];
        
        // Otras variables auxiliares para guardar notas individuales, índices, contadores, acumuladores, etc.
        // (puedes crear las que necesites según tu planteamiento)
        
        String notasDelAlumno; // String para almacenar una fila de la lista de notas
        int nota, contadorSuspensas, sumaNotasAlumno, sumaNotasAsignatura;
        int i = 0, j = 0;
        int alumnoConMasMedia = 0, asignaturaConMasSuspensos = 0, maximoParcial = 0;
        
        //  StringTokenizer para separar las notas de los alumnos mediante el símbolo \n (cada token estará compuesto por 6 notas separadas por coma) 
        StringTokenizer tokenizerAlumnos = new StringTokenizer(NOTAS_ALUMNOS, "\n");
        
        

        //----------------------------------------------------------------------
        //                        Procesamiento
        //----------------------------------------------------------------------        
        
        //  Punto 1. Recorrer el tokenizer de alumnos mientras siga habiendo tokens sin recorrer 
        
        while (tokenizerAlumnos.hasMoreTokens()) {
            
            // Punto 1.1 Extraer el siguiente token a una variable String (es la nota de un alumno);
            notasDelAlumno = tokenizerAlumnos.nextToken();

            // Punto 1.2 Mediante otro StringTokenizer extraer las notas 6 individuales de esa cadena (el separador será el símbolo coma);
            StringTokenizer tokenizerNotas = new StringTokenizer(notasDelAlumno, ",");
            
            //  Punto 1.3 Recorrer el tokenizer de notas de alumno mientras siga habiendo tokens sin recorrer 
            sumaNotasAlumno = 0;
            contadorSuspensas = 0;
            
            while (tokenizerNotas.hasMoreTokens()) {
                // Punto 1.4 Leer cada nota como valor numérico entero y almacenarla en el array doble de notas de alumnos 
                // La última columna de ese array doble aún no se rellenará
                nota = Integer.parseInt(tokenizerNotas.nextToken());
                notasAlumnos[i][j++] = nota;
            }
            j = 0;
            i++;
        }
        
        
        // Punto 2. Una vez tenemos relleno el array doble de notas de alumnos podemos trabajar directamente con él. Para ello,
        // recorremos el array doble fila a fila y calculamos la nota media de cada alumno y su número de asignaturas suspensas 
        for (i = 0; i < NUMERO_ALUMNOS; i++) {
            sumaNotasAlumno = 0;
            contadorSuspensas = 0;
            for (j = 0; j < NUMERO_NOTAS; j++) {

                // Punto 2.1 Para cada alumno, si alguna de sus notas es inferior a 5 se incrementará su contador de suspensos
                if (notasAlumnos[i][j] < 5) {
                    contadorSuspensas++;
                }

                // Punto 2.2 Para cada alumno, sumamos cada una de sus notas en un acumulador (nos servirá para calcular la nota media) 
                sumaNotasAlumno += notasAlumnos[i][j];
            }

            // Punto 2.3 Para cada alumno, guardamos en el array de asignaturas suspensas el contador de suspensos de ese alumno
            numeroSuspensasAlumno[i] = contadorSuspensas;
            
            /* Punto 2.4 Para cada alumno, se calculará la nota media dividiendo la suma de sus notas entre el número de notas. Este valor
               se guardará en la última columna de notas de ese alumno (esta columna estaba vacía, la usamos para almacenar las medias calculadas) */ 
            notasAlumnos[i][NUMERO_NOTAS] = sumaNotasAlumno / NUMERO_NOTAS;//nota media del alumno
            
            /* Punto 2.4.1 Podemos comprobar si la nota media del alumno es la más alta de las encontradas hasta ahora
               Si es así, guardaremos en una variable la posición del array en la que está ese alumno y actualizamos el valor 
               de la media más alta encontrada hasta ahora con el valor de la nota media de este alumno */
            if (notasAlumnos[i][NUMERO_NOTAS] > maximoParcial) {
                maximoParcial = notasAlumnos[i][NUMERO_NOTAS];
                alumnoConMasMedia = i;
            }
            
        }
      
        // Punto 3. Ahora recorreremos de nuevo el array doble de notas para calcular, esta vez por cada asignatura (no por cada alumno) el número de 
        // suspensos por asignatura y la asignatura con más suspensos. Para ello, recorremos el array doble columna a columna y calculamos la nota media 
        // de cada asignatura y la cantidad de suspensos en cada asignatura
        maximoParcial = 0;
        for (i = 0; i < NUMERO_NOTAS; i++) {
            sumaNotasAsignatura = 0;
            contadorSuspensas = 0;
            for (j = 0; j < NUMERO_ALUMNOS; j++) {

                // Punto 3.1 Para cada asignatura, si alguna de las notas es inferior a 5 se incrementará su contador de suspensos em esa asigntura
                if (notasAlumnos[j][i] < 5) {
                    contadorSuspensas++;
                }

                // Punto 3.2 Para cada asignatura, sumamos la nota de cada uno de los alumnos en un acumulador (nos servirá para calcular la nota media de esa asignatura) 
                sumaNotasAsignatura += notasAlumnos[j][i];
            }

            // Punto 3.3 Para cada asignatura, guardamos en la última array doble de notas de asignaturas suspensas el contador de suspensos de ese alumno
            notasAlumnos[NUMERO_ALUMNOS][i] = contadorSuspensas;//nota media del alumno

            /* Punto 3.4 Para cada asignatura, se calculará la nota media dividiendo la suma de las notas de cada alumno entre el número de alumnos. Este valor
               se guardará en el array de notas medias de cada asignatura */ 
            notaMediaAsignatura[i] = sumaNotasAsignatura / NUMERO_ALUMNOS;

            /* Punto 3.4.1 Podemos comprobar si la cantidad de suspensos de una asignatura es la más alta de las encontradas hasta ahora
               Si es así, guardaremos en una variable la posición del array en la que está esa asignatura y actualizamos el valor de la 
               cantidad de suspensos más alta encontrada hasta ahora con el valor de suspensos de esa asignatura */
            if (notasAlumnos[NUMERO_ALUMNOS][i] > maximoParcial) {
                maximoParcial = notasAlumnos[NUMERO_ALUMNOS][i];
                asignaturaConMasSuspensos = i;
            }
        }

        //----------------------------------------------------------------------
        //            Salida de resultados
        //----------------------------------------------------------------------        
        
        // Punto 4. Recorrer el array doble de notas y mostrar la información de notas separadas por guiones
        System.out.println("He leído la cadena de texto con las 6 notas de los 30 alumnos original y represento cada alumno en una fila y en ella las notas de las 6 asignaturas por orden. En cada columna están todas las notas de una asignatura.");

        System.out.print("\t\tAsig1\tAsig2\tAsig3\tAsig4\tAsig5\tAsig6");
        for (i = 0; i < NUMERO_ALUMNOS; i++) {
            System.out.print("\nAlumno " + (((i+1)<10)? " "+(i+1):(i+1))  +": " );
            for (j = 0; j < NUMERO_NOTAS; j++) {
                System.out.print( "\t"+(notasAlumnos[i][j] < 10 ? " " : "") + notasAlumnos[i][j]);
            }
            
            // Punto 4.1. Localizar al alumno con la media más alta e incluir un mensaje junto a sus notas
            if(i==alumnoConMasMedia)
                System.out.print(" <-- Este es el alumno con la nota media más alta.");
        }
        
        // Punto 5. Mostrar para cada asignatura su nota media y número de suspensos
        System.out.println("\n\nInforme por ASIGNATURAS:");
        for (i = 0; i < NUMERO_NOTAS; i++) {
            System.out.println("Asignatura" + (i + 1) + " -> Nota media: " + notaMediaAsignatura[i] + " - Suspensos: " + notasAlumnos[NUMERO_ALUMNOS][i]);
        }
        
        
        // Punto 6. Mostrar para cada alumno su nota media y número de suspensos
        System.out.println("\n\nInforme por ALUMNOS:");
        for (i = 0; i < NUMERO_ALUMNOS; i++) {
            System.out.println("[Alumno " + (i + 1) + " -> Suspensos:" + numeroSuspensasAlumno[i] + " - Nota media:" + notasAlumnos[i][NUMERO_NOTAS] + "]");
        }
        System.out.println("");
        
        // Punto 7. Mostrar la asignatura con más suspensos y el alumno con la nota media más alta
        System.out.println("La asignatura con mayor número de suspensos es la asignatura número " + (asignaturaConMasSuspensos + 1) + ".");
        System.out.println("El alumno con la nota media más alta es el alumno número " + (alumnoConMasMedia + 1) + ".");
    }
}
