/*
 * Ejercicio 02
 */
package tarea02;


/**
 *
 * @author david
 */
public class Ejercicio02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        //----------------------------------------------
        //    Declaración de variables y constantes
        //----------------------------------------------
        // Variables de entrada (aquí se definen las variables que recibirán valores, si fueran necesarias)
        // Variables de salida (aquí se definen las variables que almacenarán resultados y se mostrarán al usuario, si fueran necesarias)
        // Clase Scanner para petición de datos al usuario a través del teclado
        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        System.out.println("Ejercicio 2. Signos del Zodíaco");
        System.out.println("----------------------------------------------------");



        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
       

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
           

    }

}
