/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarea02;


/**
 *
 * @author Programación DAM y DAW IES Trassierra
 */
public class Ejercicio04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

         //----------------------------------------------
        //    Declaración de variables y constantes
        //----------------------------------------------
        // Variables de entrada (aquí se definen las variables que recibirán valores, si fueran necesarias)
        
        // Variables de salida (aquí se definen las variables que almacenarán resultados y se mostrarán al usuario, si fueran necesarias)
        
        // Clase Scanner para petición de datos al usuario a través del teclado
        

        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
       
        
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
       
    }

}
