package Ejercicio2;

import java.util.List;

public class AeroGeneradorIO{

    /**
     * Ruta del archivo donde se lee y escribe la colección de objetos AeroGenerador
     */
    private String rutaArchivo;

    /**
     * Método constructor
     * @param archivo Ruta del archivo donde se lee y escribe la colección de objetos AeroGenerador
     */
    public AeroGeneradorIO(String archivo) {
        this.rutaArchivo = archivo;
    }
 
    /**
     * Método que lee, desde un archivo binario, una colección de objetos AeroGenerador serializados.
     * @return Lista de objetos AeroGenerador que estaba almacenada en el archivo binario.
     */
    public List leer() {
        
    }

    /**
     * Método que escribe, en un archivo binario, una colección de objetos AeroGenerador serializables.
     * @param aeroGens Lista de objetos AeroGenerador serializables para almacenar en el archivo binario.
     */
    public void escribir(List aeroGens) {
       
    }

}
