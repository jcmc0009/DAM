package tarea03;

/**
 * Ejercicio 2: Uso de la clase Dado
 *
 * @author Profe
 */
public class Ejercicio02 {

    public static void main(String[] args) {
       
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        
        //Constantes
        
        // Variables de entrada (dados y puntuación máxima)
        

        // Variables de salida
        
        
        // Variables auxiliares
        
        
        // Clase Scanner para petición de datos de entrada (no es necesario)
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        //En realidad no hay entrada de datos como tal, pero podemos considerar
        //el número máximo como información de entrada ya que variará el
        //comportamiento del programa.

        //1. Cálculo del número aleatorio de puntos (entre 30 y 60)
        
                
        //----------------------------------------------
        //                 Procesamiento
        //----------------------------------------------  

        //2. Creación de 3 dados (jugadores) de 6 caras
        
        
        //3. Lanzamiento de los dados y acumulación de las puntuaciones
        
        
            //3.1 Lanzamos cada uno de los dados y mostramos las puntuaciones
            //Utilizamos los métodos de la clase para contar los lanzamientos
           
            
            //3.2 Utilizando los métodos de la clase, acumulamos las puntuaciones
            //de todos los dados en todos los lanzamientos.
            
            
        
           
        //4. Comprobación de cuál de los dados ha sido el ganador y consulta de
        //todas sus tiradas
        
        
        
        //----------------------------------------------
        //      Salida de resultados
        //----------------------------------------------
        System.out.println("LANZAMIENTO DE DADOS");
        System.out.println("----------------------------------------");
        
        
    }
}
