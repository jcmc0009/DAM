package tarea04;

import java.time.LocalDate;

/**
 * Tarea Online 4. Ejercicio 3: Días Festivos y Puentes
 * @author David Martín
 * @version 1.0
 */
public class Ejercicio03 {

    public static void main(String[] args) {

        // DEFINICIÓN DE CONSTANTES
        final String CADENA_FESTIVOS = "12,8;12,25;1,1;1,6;5,1;5,18;10,12;11,1;12,6";
        final LocalDate[] FESTIVOS;

        // DEFINICIÓN DE VARIABLES
        
        // Objeto tipo fecha con la fecha de hoy
        LocalDate hoy;


        // Objeto de tipo StringBuilder para mostrar el resultado al final
        StringBuilder resultado = new StringBuilder("");

        /* ************************************************************************
         * PROCESAMIENTO
         * ***********************************************************************/
        
        // Obtención de la fecha actual (hoy)
     
        // Si queremos hacer pruebas  podemos descomentar la siguiente línea y cambiar las fechas
        // hoy=LocalDate.of(2025, 4, 12);
        
        
        /*
            Comprobamos si el día de hoy es posterior al 25 de Diciembre, en tal 
            caso debemos incrementar el año actual en una unidad. Ya que, el último día
            festivo del año es el 25 de Diciembre, y por tanto no tiene sentido calcular
            los festivos hasta final de años, ya que no habría ninguno. 
         */
       
        
        
        

        /* Creamos un array con los festivos, para ello, utilizando la clase 
           StringTokenizer, dividimos en  tokens las fechas que nos han entregado 
           con la cadena constante CADENA_FESTIVOS. Por tanto, debemos obtener los
           diferentes tokens para la pareja de fechas día y mes, separados de las otras
           parejas, días y mes mediante ";". Y posteriormente, obtener el día y el mes
           de cada pareja, sabiendo que estos están separados por una coma ","
           Cargaremos cada una de las fechas creadas en el array constante de FESTIVOS
         */
        
        
        
        // Ordenamos el array

        
        
        /* 
           Calculamos el próximo día festivo que vamos a tener, para  ello recorremos
           el array de Festivos hasta que encontremos una fecha posterior a la actual
         */

        
        
        
        /* 
           A continuación, queremos saber si ese próximo festivo calculado, se encuentra
           en viernes o lunes, en cuyo caso se generaría un PUENTE
         */

        

        // Mostramos los festivos desde el día actual hasta el final de año que generan puente
        // Generamos el formato de fecha que queremos
       
        
        
        
        // Recorremos el array de festivos para ver qué festivos hasta final de año generan puente


 


        /* ***********************************************************************
         * SALIDA de DATOS 
         *************************************************************************/
        System.out.println(resultado);
    }

}
