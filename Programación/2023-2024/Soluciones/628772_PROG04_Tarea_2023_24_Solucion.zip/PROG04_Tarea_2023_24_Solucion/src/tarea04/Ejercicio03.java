package tarea04;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.StringTokenizer;

/**
 * Tarea Online 4. Ejercicio 3: Días Festivos y Puentes
 * @author David Martín
 * @version 1.0
 */
public class Ejercicio03 {

    public static void main(String[] args) {

        // DEFINICIÓN DE CONSTANTES
        final String CADENA_FESTIVOS = "12,8;12,25;1,1;1,6;5,1;5,18;10,12;11,1;12,6";
        final LocalDate[] FESTIVOS;

        // DEFINICIÓN DE VARIABLES
        
        // Objeto tipo fecha con la fecha de hoy
        LocalDate hoy;

        // Variable  entera con el año actual o el año siguiente si es posterior al 25/12
        int anyoActual;

        // Varibale para contener el objeto StringTokenizer que separa cadenas
        StringTokenizer fechas;

        // Variable para almacenar el día de la semana correspondiente al día de hoy
        DayOfWeek diaSemana;

        // Objeto de tipo StringBuilder para mostrar el resultado al final
        StringBuilder resultado = new StringBuilder("");

        /* ************************************************************************
         * PROCESAMIENTO
         * ***********************************************************************/
        
        // Obtención de la fecha actual (hoy)
        hoy = LocalDate.now();

        // Si queremos hacer pruebas  podemos descomentar la siguiente línea y cambiar las fechas
        // hoy=LocalDate.of(2025, 4, 12);
        
        
        /*
            Comprobamos si el día de hoy es posterior al 25 de Diciembre, en tal 
            caso debemos incrementar el año actual en una unidad. Ya que, el último día
            festivo del año es el 25 de Diciembre, y por tanto no tiene sentido calcular
            los festivos hasta final de años, ya que no habría ninguno. 
         */
        anyoActual = hoy.getYear();
        if (hoy.isAfter(LocalDate.of(anyoActual, 12, 25))) {
            anyoActual++;
        }

        /* Creamos un array con los festivos, para ello, utilizando la clase 
           StringTokenizer, dividimos en  tokens las fechas que nos han entregado 
           con la cadena constante CADENA_FESTIVOS. Por tanto, debemos obtener los
           diferentes tokens para la pareja de fechas día y mes, separados de las otras
           parejas, días y mes mediante ";". Y posteriormente, obtener el día y el mes
           de cada pareja, sabiendo que estos están separados por una coma ","
           Cargaremos cada una de las fechas creadas en el array constante de FESTIVOS
         */
        fechas = new StringTokenizer(CADENA_FESTIVOS, ";");
        FESTIVOS = new LocalDate[fechas.countTokens()];
        int i = 0;

        while (fechas.hasMoreTokens()) {
            StringTokenizer dias = new StringTokenizer(fechas.nextToken(), ",");
            FESTIVOS[i] = LocalDate.of(anyoActual, Integer.parseInt(dias.nextToken()), Integer.parseInt(dias.nextToken()));
            i++;
        }

        // Ordenamos el array
        Arrays.sort(FESTIVOS);

        /* 
           Calculamos el próximo día festivo que vamos a tener, para  ello recorremos
           el array de Festivos hasta que encontremos una fecha posterior a la actual
         */
        i = 0;
        while (i < FESTIVOS.length && hoy.isAfter(FESTIVOS[i])) {
            i++;
        }
        resultado.append("\nEl próximo festivo es: " + FESTIVOS[i]);

        /* 
           A continuación, queremos saber si ese próximo festivo calculado, se encuentra
           en viernes o lunes, en cuyo caso se generaría un PUENTE
         */
        diaSemana = FESTIVOS[i].getDayOfWeek();
        if (FESTIVOS[i].getDayOfWeek() == DayOfWeek.FRIDAY || FESTIVOS[i].getDayOfWeek() == DayOfWeek.MONDAY) {
            resultado.append(" y TENDREMOS PUENTE");
        } else {
            resultado.append(" y NO TENDREMOS PUENTE");
        }

        // Mostramos los festivos desde el día actual hasta el final de año que generan puente
        
        // Generamos el formato de fecha que queremos
        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd MMMM yyyy");

        // Recorremos el array de festivos para ver qué festivos hasta final de año generan puente
        resultado.append("\n\nFestivos con puente hasta final del año " + anyoActual);
        /* 
        for (i = 0; i < FESTIVOS.length; i++) {
            if ((FESTIVOS[i].getDayOfWeek() == DayOfWeek.FRIDAY || FESTIVOS[i].getDayOfWeek() == DayOfWeek.MONDAY) && FESTIVOS[i].isAfter(hoy)) {
                resultado.append("\n\t* En el festivo " + FESTIVOS[i].format(formatoFecha).toUpperCase() + " genera PUENTE");
            }
        }
         */

        for (LocalDate diaArray : FESTIVOS) {
            if ((diaArray.getDayOfWeek() == DayOfWeek.FRIDAY || diaArray.getDayOfWeek() == DayOfWeek.MONDAY) && diaArray.isAfter(hoy)) {
                resultado.append("\n\t* En el festivo " + diaArray.format(formatoFecha).toUpperCase() + " genera PUENTE");
            }
        }
        /* ***********************************************************************
         * SALIDA de DATOS 
         *************************************************************************/
        System.out.println(resultado);
    }

}
