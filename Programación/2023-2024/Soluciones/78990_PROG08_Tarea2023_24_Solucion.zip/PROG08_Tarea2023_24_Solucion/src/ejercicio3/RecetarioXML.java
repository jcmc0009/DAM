package ejercicio3;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import com.thoughtworks.xstream.XStream;

/**
 * Clase que permite serializar un objeto Recetario al formato XML y 
 viceversa.
 *   
 * @author profe
 */
public class RecetarioXML {
    
     // Ruta del archivo donde se lee y escribe el objeto Recetario
    private String rutaArchivo;
    
    
    // Objeto Xstream que permite la L/E con archivos XML
    private XStream xstream;

    /**
     * Método constructor
     * @param nombreArchivo Ruta del archivo donde se lee y escribe el objeto Recetario
     */
    public RecetarioXML(String nombreArchivo) {
        this.rutaArchivo = nombreArchivo;
        this.xstream = new XStream();
        //Permite asignar privilegios para poder operar con los archivos XML
        this.xstream.allowTypesByWildcard(new String[] { 
            "ejercicio3.**",
            "com.mydomain.utilitylibraries.**"
        });
    }

    
    // -----------------------------------------------------
    // Ejercicio 3: Métodos que debe implementar el alumnado
    // -----------------------------------------------------
    
    // 3.1. Método escribir()
    /**
     * Método que escribe, en un archivo de texto, un objeto Recetario serializable.
     * @param recetario Objeto Recetario serializable para almacenar en el archivo de texto.
     */    
    public void escribir(Recetario recetario) {
        // Serializa a XML.
        String xml = xstream.toXML(recetario); 
        
        // Escribimos en archivo de texto los datos serializados.
        try (PrintWriter pwArchivo = new PrintWriter(new FileWriter(rutaArchivo));) {
            pwArchivo.print(xml);
         
        // Con try-with-resources los flujos se cierran de forma automática.
        } catch (IOException e) {
            System.err.printf("Error de entrada/salida: %s\n", e.getMessage());
        }
    }
    
    // 3.2. Método leer()
     /**
     * Método que lee, desde un archivo de texto, un objeto Recetario serializado.
     * @return Objecto Recetario que estaba almacenado en el archivo de texto.
     */
    public Recetario leer() {
        String xml = "";
        String cadena = "";
        // Declaración del objeto de tipo Recetario donde se va a almacenar
        // la información contenida en el archivo de texto, que contiene el objeto
        // Recetario serializado.
        Recetario recetario = null;

        try ( // Abrimos el archivo para la lectura
                BufferedReader brArchivo = new BufferedReader(new FileReader(rutaArchivo));) {

            // Vamos leyendo las diferentes líneas del archivo de texto que contiene el XML
            // y las almacenamos en una única cadena de caracteres.
            while ((cadena = brArchivo.readLine()) != null) {
                xml += cadena;
            }
            // Des-serializamos la cadena que contiene la estructura XML y generamos
            // el objeto Recetario que tenemos que devolver.
            recetario = (Recetario) this.xstream.fromXML(xml);
            
        // Con try-with-resources los flujos se cierran de forma automática.           
        } catch (FileNotFoundException e) {
            System.out.println("Error: archivo " + rutaArchivo + " no encontrado.");
        } catch (IOException e) {
            System.err.printf("Error de entrada/salida: %s\n", e.getMessage());
        }
        // Devolvemos el objeto Recetario que estaba almacenado en el archivo de texto.
        return recetario;
    }
}
