package ejercicio1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

/**
 * Ejercicio 1: Lectura/escritura de un recetario en ficheros de texto.
 *
 * @author profe
 */
public class Ejercicio1 {

    /**
     * Método principal.
     *
     * @param args argumentos que recibe el método
     */
    public static void main(String args[]) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Variables de entrada
        // Ruta al fichero que almacena el listado de recetas.
        String rutaRecetas = System.getProperty("user.dir") + "/recursos/ListadoRecetas.txt";
        
        // Variables de salida
        // Ruta al fichero que almacenará el recetario.
        String rutaRecetario = System.getProperty("user.dir") + "/recursos/Recetario.txt";

        // Variables auxiliares
        String cadena, nombre, tipoPlato, ingredientes, instrucciones;
        StringTokenizer tokenRecetas;
        LocalDate fechaCreacion;
        Receta receta;
        String[] cadenaSeparada;
        String[] ingredientesSeparados;
        String[] listaInstrucciones;
        List<String> listaIngredientes = new ArrayList<>();
        // Objeto de tipo Recetario para almacenar las recetas.
        Recetario miRecetario = new Recetario();

        //----------------------------------------------
        //       Entrada de datos + Procesamiento
        //----------------------------------------------
        System.out.println("Abriendo archivo de recetas...");

        // Abrimos el archivo de recetas para la lectura.
        try (BufferedReader brRecetas = new BufferedReader(new FileReader(rutaRecetas))) {

            // Leemos las recetas del fichero y vamos extrayendo cada uno de los campos.
            while ((cadena = brRecetas.readLine()) != null) {
                cadenaSeparada = cadena.split(";");
                nombre = cadenaSeparada[0].trim();
                tipoPlato = cadenaSeparada[1].trim();
                fechaCreacion = LocalDate.parse(cadenaSeparada[2].trim());
                ingredientes = cadenaSeparada[3].trim();
                instrucciones = cadenaSeparada[4].trim();

                // Extraemos los ingredientes y los insertamos en una lista
                ingredientesSeparados = ingredientes.split(",");
                for (String ing : ingredientesSeparados) {
                    listaIngredientes.add(ing);
                }

                // Para cada receta generamos un objeto de tipo Receta.
                receta = new Receta(nombre, tipoPlato, fechaCreacion, listaIngredientes, instrucciones);
                // Vacíamos la lista de ingredientes actual para utilizarla en la nueva iteración.
                listaIngredientes.clear();

                // Insertamos la receta en el recetario.
                miRecetario.add(receta);
            }
        } catch (FileNotFoundException e) {
            System.out.printf("Error de entrada/salida: %s\n", e.getMessage());
        } catch (IOException e) {
            System.out.printf("Error de entrada/salida: %s\n", e.getMessage());
        } catch (NullPointerException e) {
            System.out.printf(e.getMessage());
        }

        System.out.println("Cerrando archivo de recetas...");

        System.out.println();

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        // Antes de almacenar la información del recetario en el fichero de salida,
        // nos aseguramos de que contiene información (recetas).
        if (miRecetario.numRecetas() != 0) {

            System.out.println("Abriendo archivo del recetario...");

            // Abrimos el archivo de salida para almacenar la información del recetario.
            try (PrintWriter pwRecetario = new PrintWriter(new FileWriter(rutaRecetario))) {

                tokenRecetas = new StringTokenizer(miRecetario.toString(), "#");

                // Escribimos los campos de cada receta en el fichero de salida con la estructura especificada.
                pwRecetario.printf("*".repeat(130));
                pwRecetario.printf("\nLIBRO DE RECETAS\n");
                pwRecetario.printf("*".repeat(130));
                while (tokenRecetas.hasMoreTokens()) {
                    String recetaInfo = tokenRecetas.nextToken();
                    // Para extraer cada campo dentro de una receta, usamos StringTokenizer. Recuerda 
                    // que los campos están separados por el carácter ';'.
                    StringTokenizer tokenReceta = new StringTokenizer(recetaInfo, ";");
                    pwRecetario.printf("\nNOMBRE DE LA RECETA:%s\nTIPO DE PLATO:%s\nFECHA DE CREACIÓN:%s\nINGREDIENTES:%s\n",
                            tokenReceta.nextToken(), tokenReceta.nextToken(), tokenReceta.nextToken(), tokenReceta.nextToken());

                    pwRecetario.printf("INSTRUCCIONES:\n");
                    listaInstrucciones = tokenReceta.nextToken().split("\\.");
                    for (int i = 0; i < listaInstrucciones.length; i++) {
                        pwRecetario.printf("%d.- %s.\n", i + 1, listaInstrucciones[i]);
                    }
                    pwRecetario.printf("*".repeat(130));
                }
            } catch (IOException e) {
                System.out.printf("Error de entrada/salida: %s\n", e.getMessage());
            }

            System.out.println("Cerrando archivo del recetario...");

            System.out.println();
            System.out.println("Archivos cerrados y procesamiento finalizado");
            System.out.println("---------");
            System.out.println();
            System.out.println("Fin del programa.");
        } // Si el recetario no contiene ninguna receta, mostramos el mensaje correspondiente por pantalla.
        else {
            System.out.println("El recetario no tiene ninguna receta. El archivo 'Recetario.txt' no ha sido creado.");
        }
    }
}
