package ejercicio2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * Clase encargada de realizar la lectura y escritura de objetos Recetario en archivos binarios.
 * @author profe
 */
public class RecetarioIO {
    
    // Ruta del archivo donde se lee y escribe el objeto Recetario
    private String rutaArchivo;

    /**
     * Método constructor
     * @param archivo Ruta del archivo donde se lee y escribe el objeto Recetario
     */
    public RecetarioIO(String archivo) {
        this.rutaArchivo = archivo;
    }
    
 
    // -----------------------------------------------------
    // Métodos
    // -----------------------------------------------------
    
    /**
     * Método que lee, desde un archivo binario, un objeto Recetario serializado.
     * @return Objeto Recetario que estaba almacenado en el archivo binario.
     */
    public Recetario leer() {
        // Declaración del objeto de tipo Recetario
        Recetario recetario = null;

        try ( // Abrimos el archivo para lectura
                ObjectInputStream oisRecetario = new ObjectInputStream(new FileInputStream(rutaArchivo));) {

            // Cargamos el contenido completo del archivo en el objeto Recetario
            recetario = (Recetario) oisRecetario.readObject();

        // Con try-with-resources los flujos se cierran de forma automática.
        } catch (FileNotFoundException e) {
            System.out.println("Error: archivo " + rutaArchivo + " no encontrado.");
        } catch (IOException e) {
            System.out.println("Error: fallo en el acceso al archivo: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("Error: el contenido del archivo no se corresponde con lo que se esperaba.");
        } catch (ClassCastException e) {
            System.out.println("Error: el archivo no contiene un recetario.");
        }
        // Devolvemos el objeto Recetario que estaba almacenado en el archivo binario.
        return recetario;
    }
    
    /**
     * Método que escribe, en un archivo binario, un objeto Recetario serializable.
     * @param recetario Objeto Recetario serializable para almacenar en el archivo binario.
     */   
    public void escribir(Recetario recetario) {

        try ( //Abrimos los flujos de datos serializados de salida.
                ObjectOutputStream oosRecetario = new ObjectOutputStream(new FileOutputStream(rutaArchivo));) {

            // Escribimos en archivo binario los datos serializados.
            oosRecetario.writeObject(recetario);

        // Con try-with-resources los flujos se cierran de forma automática.
        } catch (IOException e) {
            System.out.println("Error: fallo en el acceso al archivo: " + e.getMessage());
        }
    }
}
