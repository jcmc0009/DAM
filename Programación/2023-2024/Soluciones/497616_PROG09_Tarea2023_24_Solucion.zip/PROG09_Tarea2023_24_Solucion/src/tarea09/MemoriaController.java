package tarea09;

import java.io.File;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Control;
import javafx.util.Duration;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

/**
 * Clase Controladora
 * @author Fran Jiménez (IES Trassierra)
 */
public class MemoriaController implements Initializable {

    // definición de variables internas para el desarrollo del juego
    private JuegoMemoria juego;         // instancia que controlará el estado del juego (tablero, parejas descubiertas, etc)
    private ArrayList<Button> cartas;   // array para almacenar referencias a las cartas @FXML definidas en la interfaz 
    private int segundos=0;             // tiempo de juego
    private boolean primerBotonPulsado = false, segundoBotonPulsado = false; // indica si se han pulsado ya los dos botones para mostrar la pareja
    private int idBoton1, idBoton2;     // identificadores de los botones pulsados
    private boolean esPareja;           // almacenará si un par de botones pulsados descubren una pareja o no
    
    private String tipo;                // permitirá definir varios juegos (escudos, personas, plantas)
    
    private MediaPlayer player;         // reproductor de sonido

    @FXML private AnchorPane main;      // panel principal
    @FXML private ImageView win;            // imagen @FXML para cargar la pantalla de victoria

    @FXML  private Label intentos, tiempo;   // etiquetas @FXML de texto para mostrar en la interfaz los intentos y el tiempo
    
    
    // botones @FXML asociados a las 16 cartas del juego (botones 0 a 15)
    @FXML private Button carta0, carta1, carta2, carta3,
                         carta4, carta5, carta6, carta7,
                         carta8, carta9, carta10, carta11,
                         carta12, carta13, carta14, carta15;

    // linea de tiempo para gestionar la finalización del intento al pasar 1.5 segundos
    private final Timeline ocultar = new Timeline(new KeyFrame(Duration.seconds(1.5), e -> finalizarIntento()));
    
    // linea de tiempo para gestionar el contador de tiempo del juego
    private Timeline contadorTiempo;

    
    /**
     * Método interno que configura todos los aspectos necesarios para inicializar el juego.
     *
     * @param url No utilizaremos este parámetro (null).
     * @param resourceBundle No utilizaremos este parámetro (null).
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        juego = new JuegoMemoria(); // instanciación del juego (esta instancia gestionará el estado de juego)
        juego.iniciarJuego();       // comienzo de una nueva partida
        cartas = new ArrayList<>(); // inicialización del ArrayList de referencias a cartas @FXML
        
        win.setVisible(false);  // pantalla de victoria oculta inicialmente
        tipo = juego.getTipoPartida(); // permite establecer el tipo de juego (aleatorio: plantas, personas, escudos)
        
        // guarda en el ArrayList "cartas" todas las referencias @FXML a las cartas para gestionarlo cómodamente
        cartas.addAll(Arrays.asList(carta0, carta1, carta2, carta3,
                                      carta4, carta5, carta6, carta7,
                                      carta8, carta9, carta10, carta11,
                                      carta12, carta13, carta14, carta15));


        segundos=0;                   // contador de segundos a 0
        intentos.setText("0");  // colocar los intentos a 0 en la interfaz
        
        // contador de tiempo de la partida (Duration indica cada cuanto tiempo se actualizará)
        contadorTiempo = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
            segundos++;                     // actualización del número de segundos
            tiempo.setText(""+segundos);    // el número de segundos se copia en el label "tiempo" de la interfaz
        }));
        contadorTiempo.setCycleCount(Timeline.INDEFINITE);  // reproducción infinita
        contadorTiempo.play();                                // iniciar el contador en este momento

        
        // carga de la música de fondo
        Media media = new Media(new File(System.getProperty("user.dir") + "/src/tarea09/assets/sonidos/musica.mp3").toURI().toString());
        player = new MediaPlayer(media);         
        player.setAutoPlay(true);
        player.setCycleCount(MediaPlayer.INDEFINITE);
    }
    
    /**
     * Acción asociada al botón <strong>Comenzar nuevo juego</strong> que permite comenzar una nueva partida.
     *
     * Incliuye la notación @FXML porque será accesible desde la interfaz de usuario
     * @param url No utilizaremos este parámetro (null).
     * @param resourceBundle No utilizaremos este parámetro (null).
     */
    @FXML
    private void reiniciarJuego(ActionEvent event) {
        player.stop();              // detener la música de fondo
        contadorTiempo.stop();      // parar el contador de tiempo
        finalizarIntento();  // ocultar casillas visibles (si las hubiera)
        
        tiempo.setText("0");    // colocar el tiempo a 0 en la interfaz
        
        /* hacer visibles las 16 cartas de juego ya que es posible que no todas estén visibles 
           si se encontraron parejas en la partida anterior */
        for(int i = 0; i<cartas.size();i++){
            cartas.get(i).setVisible(true);
            cartas.get(i).setGraphic(null);
        }
        
        initialize(null,null);
    }

    @FXML
    private void mostrarContenidoCasilla(ActionEvent event) {
        String ruta;
        int padding = 0;
        
        if (!primerBotonPulsado) {
            if (!esPareja) {
                finalizarIntento();
                ocultar.stop();
            }
            esPareja = false;
            primerBotonPulsado = true;

            String botonId = ((Button) event.getSource()).getId();
            idBoton1 = Integer.parseInt(botonId.substring(5, botonId.length()));

            Button btn = cartas.get(idBoton1);

            String opcion1 = juego.getCartaPosicion(idBoton1);

            try {
                ImageView im = new ImageView(new Image(getClass().getResourceAsStream("assets/cartas/" + tipo +"/"+ opcion1 + ".png")));
                im.setFitWidth(btn.getWidth() - (padding * 2));
                im.setFitHeight(btn.getHeight() - (padding * 2));
                btn.setGraphic(im);
                btn.setPadding(new Insets(padding));

            } catch (NullPointerException e) {
                btn.setText(opcion1);
                System.err.println("No existe la imagen");
            }
        }

        if (!segundoBotonPulsado) {

            String botonId = ((Control) event.getSource()).getId();
            idBoton2 = Integer.parseInt(botonId.substring(5, botonId.length()));
            if (idBoton1 != idBoton2) {
                segundoBotonPulsado = true;

                Button btn = cartas.get(idBoton2);

                String opcion2 = juego.getCartaPosicion(idBoton2);
                
                try {
                    ImageView im = new ImageView(new Image(getClass().getResourceAsStream("assets/cartas/" + tipo +"/"+ opcion2 + ".png")));
                    im.setFitWidth(btn.getWidth() - (padding * 2));
                    im.setFitHeight(btn.getHeight() - (padding * 2));
                    btn.setGraphic(im);
                    btn.setPadding(new Insets(padding));

                } catch (NullPointerException e) {
                    btn.setText(opcion2);
                    System.err.println("No existe la imagen");
                }

                intentos.setText( "" +  ( Integer.valueOf(intentos.getText())+1) );
                
                if (juego.compruebaJugada(idBoton1, idBoton2)) {
                    esPareja = true;

                    ruta = System.getProperty("user.dir") + "/src/tarea09/assets/sonidos/pareja.mp3"; // Ruta del fichero
                }
                else {
                    ruta = System.getProperty("user.dir") + "/src/tarea09/assets/sonidos/noPareja.mp3"; // Ruta del fichero
                }

                Media media = new Media(new File(ruta).toURI().toString());
                MediaPlayer player = new MediaPlayer(media);                    
                player.setVolume(0.5);
                player.play();
                ocultar.play();
            }
        }
    }

    /**
     * Este método permite finalizar un intento realizado. Se pueden dar dos situaciones:
     * <ul>
     *    <li>Se ha descubierto una pareja: en este caso se ocultarán las cartas. Además, se debe comprobar
     *        si la pareja descubierta es la última pareja del tablero y en ese caso terminar la partida.</li>
     *    <li>Si NO se ha descubierto una pareja: las cartas deben volver a ocultarse (colocando su imagen a null).</li>
     * </ul>
     * Este método será interno y NO se podrá acceder desde la interfaz, por lo que NO incorpora notación @FXML.
     */  
    private void finalizarIntento() {
        
        // se comprueba si es pareja
        if (esPareja) {
            cartas.get(idBoton1).setVisible(false);  // se hace desaparecer la primera carta de la pareja
            cartas.get(idBoton2).setVisible(false);  // se hace desaparecer la segunda carta de la pareja
            
            // se comprueba si el juego ha finalizado
            if(juego.compruebaFin()) {
                contadorTiempo.stop();     // se detiene el contador de tiempo
                win.setVisible(true);  // se muestra la pantalla de victoria
                player.stop();             // se detiene la música de fondo
                
                // se reproduce la música de victoria
                Media media = new Media(new File(System.getProperty("user.dir") + "/src/tarea09/assets/sonidos/tada.mp3").toURI().toString());
                player = new MediaPlayer(media);         
                player.setAutoPlay(true);
            }
        } 
        else {  // si no son pareja
            cartas.get(idBoton1).setGraphic(null);  // se elimina la imagen asociada al botón (vuelve a aparecer el reverso de la carta)
            cartas.get(idBoton2).setGraphic(null);  // se elimina la imagen asociada al botón (vuelve a aparecer el reverso de la carta)
        }        
         
        primerBotonPulsado = false;     // se preparan los botones para el siguiente intento
        segundoBotonPulsado = false;    // se preparan los botones para el siguiente intento
        
    }
    
    @FXML   private void salir() {       
        
        // Alerta de confirmación que permita elegir si se desea salir o no del juego
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Salir de Memory GAME!");
        alert.setHeaderText("¿Quieres salir de la aplicación Memory GAME!?");

        // SOLO si se confirma la acción se cerrará la ventana y el juego finalizará. 
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
              
                contadorTiempo.stop();
                player.stop();
                
                // Sonido para salir del juego
                Media media = new Media(new File(System.getProperty("user.dir") + "/src/tarea09/assets/sonidos/bye_bye.mp3").toURI().toString());
                player = new MediaPlayer(media);
                player.setVolume(0.35);
                player.setAutoPlay(true);
                
                // Hasta que no finalice el sonido, no se ejecuta la función Exit:
                player.setOnEndOfMedia(() -> {
                    Platform.exit();  // Salida de la aplicación
                });
            } 
        });
    }
}
