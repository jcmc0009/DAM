/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tarea02;

import java.util.Scanner;

/**
 *
 * @author luisnavarro
 */
public class Ejercicio03 {

    public static void main(String args[]) {
        //----------------------------------------------
        //               Declaración de variables
        //----------------------------------------------
        Scanner entrada = new Scanner(System.in);
        int numElementos;
        int soldadosSobran=0;
        String formacion;
        String forma = "";
        int lado;
        System.out.println("Ejercicio03: Formación romana a partir de un número de soldados.");

        do {
            //----------------------------------------------
            //               Entrada de datos 
            //----------------------------------------------
            // Bloque 1. Solicitud de.
            // Validación de entrada
            System.out.println("Introduce el número de elementos de la formación (debe ser mayor que cero)");
            numElementos = entrada.nextInt();
        } while (numElementos < 1);
        System.out.println("Introduce el tipo de formación");
        formacion = entrada.next();

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        // Sólo si la entrada ha sido válida llevamos a cabo los cálculos
        switch (formacion.toUpperCase()) {
            case "LINEA":
                forma += "\n";
                for (int i = 0; i < numElementos; i++) {

                    forma += "* ";
                }
                forma += "\n";
                break;

            case "CUADRADO":
                lado = (int) Math.sqrt(numElementos);

                for (int i = 0; i < lado; i++) {
                    for (int j = 0; j < lado; j++) {
                        forma += "* ";
                    }
                    forma += "\n";
                }
                soldadosSobran=numElementos-lado*lado;
                break;

            case "TRIANGULO":
                lado = (int) ((Math.sqrt(1 + 8 * numElementos) - 1) / 2);

                for (int i = 0; i < lado; i++) {
                    for (int k = 0; k < i + 1; k++) {
                        forma += " ";
                    }
                    for (int j = 0; j < lado - i; j++) {
                        forma += "* ";
                        soldadosSobran++; //En soldados sobran cuento los que voy metiendo
                    }
                    forma += "\n";
                }
                soldadosSobran=numElementos-soldadosSobran; //Ahora resto el total de los que he metido
                break;

            default:
                forma += "Opción NO CORRECTA";
        }
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println(forma);
        if (soldadosSobran>0)
               System.out.println("De los "+numElementos+" soldados asignados, una vez hecha la mayor formación posible del tipo indicado, sobran "+soldadosSobran+" soldados.");
    }
}
