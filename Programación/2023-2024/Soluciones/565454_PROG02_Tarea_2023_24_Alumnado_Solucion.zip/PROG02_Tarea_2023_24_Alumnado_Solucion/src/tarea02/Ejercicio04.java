/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tarea02;

import java.util.Random;

/**
 *
 * @author luisnavarro
 */
public class Ejercicio04 {

    public static void main(String[] args) {
        // Plátano, Fresa, Manzana, Naranja, Cerezas
        //----------------------------------------------
        //               Declaración de variables
        //----------------------------------------------

        final String VALORES = "PFMNC";
        Random aleatorio = new Random();
        int contador = 0;
        int premio = 0;
        String secuencia = "";
        System.out.println("Ejercicio 4. Simulador de Máquina Tragaperras.");
        System.out.println("----------------------------------------------------");        

        //----------------------------------------------
        //              Entrada de datos
        //----------------------------------------------
        // En este caso no hay entrada de datos. 
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        // Sólo si la entrada ha sido válida llevamos a cabo los cálculos
        System.out.println("Voy a generar secuencias de 3 frutas entre Plátano, Fresa, Naranja, Manzana y Cereza hasta conseguir 3 iguales y te diré qué premio has obtenido de los cinco:");
        do {
            secuencia = "";
            for (int i = 0; i < 3; i++) {
                secuencia += VALORES.charAt(aleatorio.nextInt(VALORES.length()));
            }
            contador++;
            System.out.println(contador + "-" + secuencia);

        } while (secuencia.charAt(0) != secuencia.charAt(1) || secuencia.charAt(1) != secuencia.charAt(2));

        switch (secuencia) {
            case "PPP":
                premio = 1;
                break;
            case "FFF":
                premio = 2;
                break;
            case "MMM":
                premio = 3;
                break;
            case "NNN":
                premio = 4;
                break;
            case "CCC":
                premio = 5;
                break;

        }

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println("Has conseguido el premio " + premio + " en el intento " + contador + " con la secuencia: " + secuencia);
    }
}
