/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tarea02;

/**
 *
 * @author luisnavarro
 */
import java.util.Scanner;

public class Ejercicio02 {

    public enum Bebidas {
        COCACOLA, PEPSI, AGUA, ZUMO, OTRO
    };

    public static void main(String[] args) {
        //----------------------------------------------
        //               Declaración de variables
        //----------------------------------------------
        Scanner scanner = new Scanner(System.in);
        int opcion;
        double precio = 0;
        Bebidas miBebida = null;
        System.out.println("Ejercicio 2: Máquina expendedora de Bebidas\n");
        System.out.println("----------------------------------------------------");       
        do {
            //----------------------------------------------
            //               Entrada de datos 
            //----------------------------------------------
            // Bloque 1. Solicitud de.
            // Validación de entrada
            System.out.println("Bienvenido a la Máquina Expendedora de Bebidas");
            System.out.println("Seleccione una bebida:");
            System.out.println("1. " + Bebidas.COCACOLA + " - 1.50€");
            System.out.println("2. " + Bebidas.PEPSI + " - 1.50€");
            System.out.println("3. " + Bebidas.AGUA + " - 1.00€");
            System.out.println("4. " + Bebidas.ZUMO + " de naranja - 2.00€");
            System.out.println("0. Salir");

            System.out.println("\nSeleccione una  opción: ");

            opcion = scanner.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            // Sólo si la entrada ha sido válida llevamos a cabo los cálculos
            //System.out.println("\nHa seleccionado la opción: "+opcion);
            switch (opcion) {
                case 1:
                    precio = 1.50;
                    miBebida = Bebidas.COCACOLA;
                    break;
                case 2:
                    precio = 1.50;
                    miBebida = Bebidas.PEPSI;
                    break;
                case 3:
                    precio = 1.00;
                    miBebida = Bebidas.AGUA;
                    break;
                case 4:
                    precio = 2.00;
                    miBebida = Bebidas.ZUMO;
                    break;
                case 0:
                    System.out.println("Gracias por usar la Máquina Expendedora. ¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción no válida. Seleccione una bebida válida.\n");
                    miBebida = Bebidas.OTRO;

            }
        } while (opcion < 0 || opcion > 4);

        if (miBebida != null && miBebida != Bebidas.OTRO) {
            System.out.printf("Ha seleccionado una %s. El precio es %.2f €%n", miBebida, precio);

            System.out.print("Ingrese la cantidad de dinero en euros: ");
            double dineroIngresado = scanner.nextDouble();

            //----------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------
            if (dineroIngresado < precio) {
                System.out.println("Dinero insuficiente. Su dinero será devuelto.");
            } else {
                double cambio = dineroIngresado - precio;
                System.out.println("Compra exitosa. Su cambio es: " + String.format("%.2f", cambio) + " €");
                System.out.println("Disfrute su " + miBebida + "!");
            }
        }
        scanner.close();
    }

}
