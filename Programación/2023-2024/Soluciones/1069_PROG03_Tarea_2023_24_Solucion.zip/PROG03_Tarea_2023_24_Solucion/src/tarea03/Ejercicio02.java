package tarea03;

import libtarea3.Dado;

/**
 * Ejercicio 2: Uso de la clase Dado
 *
 * @author Profe
 */
public class Ejercicio02 {

    public static void main(String[] args) {
       
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        
        //Constantes
        
        // Variables de entrada (dados y puntuación máxima)
        Dado dado1, dado2, dado3;
        int numMaximo;

        // Variables de salida
        long sumaPuntos, dadoGanador;
        int puntosGanador;
        String jugada;
        String cadenaLanzamientos ="";
        
        // Variables auxiliares
        byte lanzamiento1, lanzamiento2, lanzamiento3;
        
        // Clase Scanner para petición de datos de entrada (no es necesario)
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        //En realidad no hay entrada de datos como tal, pero podemos considerar
        //el número máximo como información de entrada ya que variará el
        //comportamiento del programa.

        //1. Cálculo del número aleatorio de puntos (entre 30 y 60)
        numMaximo = 30 + (int) (Math.random() * 31);
                
        //----------------------------------------------
        //      Procesamiento
        //----------------------------------------------  

        //2. Creación de 3 dados (jugadores) de 6 caras
        dado1 = new Dado();
        dado2 = new Dado();
        dado3 = new Dado();
        
        //3. Lanzamiento de los dados y acumulación de las puntuaciones
        
        do {
            //3.1 Lanzamos cada uno de los dados y mostramos las puntuaciones
            //Utilizamos los métodos de la clase para contar los lanzamientos
            lanzamiento1 = dado1.lanzar();
            lanzamiento2 = dado2.lanzar();
            lanzamiento3 = dado3.lanzar();

            cadenaLanzamientos += String.format("Lanzamiento nº %2d:   %-6d  %-6d  %-6d\n",
                    dado1.getNumeroLanzamientos(),
                    lanzamiento1, lanzamiento2, lanzamiento3);
            
            //3.2 Utilizando los métodos de la clase, acumulamos las puntuaciones
            //de todos los dados en todos los lanzamientos.
            //Controlamos que no se supere el número máximo de puntos
            sumaPuntos = dado1.getSumaPuntuacionHistorica()+dado2.getSumaPuntuacionHistorica()+dado3.getSumaPuntuacionHistorica();
            
        }while (sumaPuntos<numMaximo);
        
           
        //4. Comprobación de cuál de los dados ha sido el ganador y consulta de
        //todas sus tiradas
        
        //Suponemos que el ganador es el dado 1
        puntosGanador = lanzamiento1; 
        jugada= dado1.getSerieHistoricaLanzamientos();
        dadoGanador = 1;
        
        //Y comprobamos si el resto de dados superan su puntuación para actualizar
        //los valores
        if (lanzamiento2 > puntosGanador) {
            puntosGanador = lanzamiento2;
            dadoGanador = 2;
            jugada= dado2.getSerieHistoricaLanzamientos();
        }
        if (lanzamiento3 > puntosGanador) {
            puntosGanador = lanzamiento3;
            dadoGanador = 3;
            jugada= dado3.getSerieHistoricaLanzamientos();
        }
        
        //----------------------------------------------
        //      Salida de resultados
        //----------------------------------------------
        System.out.println("LANZAMIENTO DE DADOS");
        System.out.println("----------------------------------------");
        System.out.printf("Número máximo de puntos: %d\n", numMaximo);
        System.out.println();
        System.out.println("                   DADO1   DADO2   DADO3\n"); 
        System.out.println(cadenaLanzamientos);
        System.out.printf("Juego Terminado. La suma de los lanzamientos es: %d.\n", sumaPuntos);
        System.out.printf("El ganador es el dado %d con %d puntos en la última jugada.\n", dadoGanador,puntosGanador);
        System.out.printf("El valor %d ha salido %d veces en todo el juego y se han realizado un total de %d lanzamientos.\n", puntosGanador,
                Dado.getNumeroVecesCaraGlobal(puntosGanador),
                Dado.getNumeroLanzamientosGlobal());
        System.out.printf("Todos los lanzamientos del dado %d: %s.\n", dadoGanador, jugada);
        
    }
}
