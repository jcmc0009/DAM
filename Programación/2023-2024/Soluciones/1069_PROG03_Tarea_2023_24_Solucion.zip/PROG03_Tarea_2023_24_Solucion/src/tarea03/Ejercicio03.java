package tarea03;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.InputMismatchException;
import java.util.Locale;
import java.util.Scanner;

/**
 * Ejercicio 3: Día de cumpleaños
 *
 * @author profe
 */
public class Ejercicio03 {

    public static void main(String[] args) {
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        final int YEAR_MIN = 1900;
        final int YEAR_MAX = LocalDate.now().getYear();

        // Variables de entrada
        int yearNacimiento = 0;
        int mesNacimiento = 0;
        int diaNacimiento = 0;

        // Variables de salida
        int contadorCumples;

        // Variables auxiliares
        boolean errorEntrada;
        DayOfWeek diaSemanaCumple;
        String diaSemanaCumpleEs;
        int longitudMes;

        // Objeto Scanner para lectura desde teclado
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("DÍA DE CUMPLEAÑOS");
        System.out.println("-----------------");

        // 1. Entrada de datos: lectura de año de nacimiento
        // 1.1.- Leer y comprobar el año de nacimiento (entre 1900 y año actual)
        do {
            System.out.printf("Introduzca año de nacimiento (%d-%d): \n", YEAR_MIN, YEAR_MAX);
            try {
                yearNacimiento = teclado.nextInt();
                errorEntrada = (yearNacimiento < YEAR_MIN || yearNacimiento > YEAR_MAX);
            } catch (InputMismatchException ex) {
                errorEntrada = true;
                teclado.nextLine(); // "Purgamos" o "leemos sin usarlo" lo que haya en el teclado, que es incorrecto
            }
            if (errorEntrada) {
                System.out.println("Error de lectura: año incorrecto.");
            }
        } while (errorEntrada);

        // 1.2.- Leer y comprobar el mes de nacimiento 
        do {
            System.out.printf("Introduzca mes de nacimiento (1-12): \n");
            try {
                mesNacimiento = teclado.nextInt();
                errorEntrada = (mesNacimiento < 1 || mesNacimiento > 12);
            } catch (InputMismatchException ex) {
                errorEntrada = true;
                teclado.nextLine(); // "Purgamos" o "leemos sin usarlo" lo que haya en el teclado, que es incorrecto
            }
            if (errorEntrada) {
                System.out.println("Error de lectura: mes incorrecto.");
            }
        } while (errorEntrada);

        // 1.3.- Averiguamos cuántos días tiene el mes de nacimiento
        longitudMes = LocalDate.of(yearNacimiento, mesNacimiento, 1).lengthOfMonth();

        // 1.4.- Leer y comprobar el día de nacimiento 
        do {
            System.out.printf("Introduzca día de nacimiento: \n");
            try {
                diaNacimiento = teclado.nextInt();
                errorEntrada = (diaNacimiento < 1 || diaNacimiento > longitudMes);
            } catch (InputMismatchException ex) {
                errorEntrada = true;
                teclado.nextLine(); // "Purgamos" o "leemos sin usarlo" lo que haya en el teclado, que es incorrecto
            }
            if (errorEntrada) {
                System.out.println("Error de lectura: día incorrecto.");
            }
        } while (errorEntrada);

        //----------------------------------------------
        //    Procesamiento + Salida de resultados  
        //----------------------------------------------
        //2.- Cálculo del día de la semana en que cayó el nacimiento       
        diaSemanaCumple = LocalDate.of(yearNacimiento, mesNacimiento, diaNacimiento).getDayOfWeek();
        diaSemanaCumpleEs = diaSemanaCumple.getDisplayName(TextStyle.FULL, new Locale("es", "ES"));

        System.out.printf("El día que naciste fue %s\n", diaSemanaCumple.getDisplayName(TextStyle.FULL, new Locale("es", "ES")));
        System.out.println();
        System.out.printf("¿Cuántas veces tu cumpleaños ha caído en %s?\n", diaSemanaCumpleEs);
        System.out.println("-----------------------------------------------------");

        // 3.- Recorremos desde el año posterior al año de nacimiento hasta el año actual (bucle)
        // Iniciamos el contador de cumpleaños
        contadorCumples = 0;
        for (int year = yearNacimiento + 1; year <= YEAR_MAX; year++) {
            if (!(diaNacimiento == 29 && mesNacimiento == 2 && !LocalDate.of(year, 1, 1).isLeapYear())) {
            //if (diaNacimiento==29 || mesNacimiento==2 || LocalDate.of(year,1,1).isLeapYear()))
                LocalDate fecha = LocalDate.of(year, mesNacimiento, diaNacimiento);
                if (fecha.getDayOfWeek() == diaSemanaCumple) {
                    contadorCumples++;
                    System.out.printf("%2d. %s\n", contadorCumples, fecha.format(FORMATO_FECHA));
                }
            } 
        }

        // 4.- Mostramos por pantalla el número de coincidencias
        System.out.printf("\nNúmero total de coincidencias: %d\n", contadorCumples);
    }
}
