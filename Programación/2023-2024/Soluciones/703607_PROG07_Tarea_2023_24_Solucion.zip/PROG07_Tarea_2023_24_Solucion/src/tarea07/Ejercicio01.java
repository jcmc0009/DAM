package tarea07;

import java.util.HashSet;
import java.util.Set;

/**
 * Ejercicio 1. Creando jardín botánico
 * @author Profesor
 */
public class Ejercicio01 {
    
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        
        // Constantes
        
        final int CANTIDAD_ESPECIES_PLANTAS = 5;
        
        // Variables de entrada
        
        // Variables auxiliares
        
        // Variables de salida
        
        Set<String> setEspeciesPlantas1, setEspeciesPlantas2, union, interseccion, diferencia;
        
        // Al usar conjuntos (set) garantizamos que no se pueden repetir elementos
        
        setEspeciesPlantas1 = new HashSet<>();
        setEspeciesPlantas2 = new HashSet<>();
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        
        // No hay, pues se usa un número fijo de elementos aleatorios
        
        System.out.println("CONJUNTOS DE ESPECIES DE PLANTAS");
        System.out.println("--------------------------------");

        //----------------------------------------------
        //                  Procesamiento
        //----------------------------------------------
        
        // Rellenamos los conjuntos con especies de plantas aleatorias hasta que haya CANTIDAD_ESPECIES_PLANTAS
        
        while (setEspeciesPlantas1.size() < CANTIDAD_ESPECIES_PLANTAS) {
        
            // Al añadir en un conjunto, si se produce una repetición, es como si no se añadiera nada
            
            setEspeciesPlantas1.add(Utilidades.especiePlantaAleatoria()); 
        }
        
        while (setEspeciesPlantas2.size() < CANTIDAD_ESPECIES_PLANTAS) {
            
            // Al añadir en un conjunto, si se produce una repetición, es como si no se añadiera nada
            
            setEspeciesPlantas2.add(Utilidades.especiePlantaAleatoria()); 
        }
        
        // Unión de los dos conjuntos
        
        union = new HashSet<>(setEspeciesPlantas1);
        union.addAll(setEspeciesPlantas2);
        
        // Intersección de los conjuntos
        
        interseccion = new HashSet<>(setEspeciesPlantas1);
        interseccion.retainAll(setEspeciesPlantas2);
        
        // Diferencia de los conjuntos
        
        diferencia = new HashSet<>(setEspeciesPlantas2);
        diferencia.removeAll(setEspeciesPlantas1);
        
        //----------------------------------------------
        //              Salida de Resultados 
        //----------------------------------------------
        
        // Recorremos el conjunto y mostramos su contenido por pantalla
        
        System.out.printf ("Conjunto C1: %s\n", setEspeciesPlantas1);
        System.out.printf ("Conjunto C2: %s\n", setEspeciesPlantas2);
        System.out.printf ("Unión C1 y C2: %s\n", union);
        System.out.printf ("Intersección C1 y C2: %s\n", interseccion);
        System.out.printf ("Diferencia C2-C1: %s\n", diferencia);

        System.out.println();
    }
}