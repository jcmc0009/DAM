package tarea07;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.TreeMap;

/** Ejercicio 3. Calendario de especies de plantas
 * @author Profesor
 */
public class Ejercicio03 {

    public static void main(String[] args) {
        
        //----------------------------------------------
        //    Declaración de variables y constantes
        //----------------------------------------------
        
        // Constantes
        
        final int DIAS = 7;
        
        // Variables de entrada
        
        // Variables auxiliares
        
        String especiePlanta;
        boolean especiePlantaRepetida;
        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        
        // Variables de salida
        
        Map<LocalDate, String> mapCalendarioEspeciePlanta = new TreeMap<>();

        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        
        // No se piden datos al usuario, ya que se usa un número fijo de elementos aleatorios
        
        System.out.println("CALENDARIO DE ESPECIES DE PLANTAS");
        System.out.println("---------------------------------");
        
        //----------------------------------------------
        //                  Procesamiento
        //----------------------------------------------
        
        // Vamos creando las claves del map y asignando una especie de planta para cada clave
        
        // La especie de planta no puede repetirse
        LocalDate fechaInicial = LocalDate.now();
        
        // Recorremos fechas desde 01/01/2024 hasta 01/12/2024
        
        for (LocalDate fecha = fechaInicial; fecha.isBefore(fechaInicial.plusDays(DIAS)); fecha = fecha.plusDays(1)) {
            
            especiePlantaRepetida = true;
            
            do { // Generamos una especie de planta aleatoria y la insertamos en la nueva fecha sólo si aún no ha salido
               
                especiePlanta = Utilidades.especiePlantaAleatoria();
                
                if (!mapCalendarioEspeciePlanta.containsValue(especiePlanta)) {
                    
                    mapCalendarioEspeciePlanta.put(fecha, especiePlanta);
                    especiePlantaRepetida = false;
                }
                
            } while (especiePlantaRepetida);
        }
   
        //----------------------------------------------
        //           Salida de resultados
        //----------------------------------------------
        
        System.out.printf("Contenido final del mapa de especies de plantas organizado por fechas:\n\n");
        
        for (Map.Entry<LocalDate, String> elemento: mapCalendarioEspeciePlanta.entrySet()) {
            
            System.out.printf("Fecha %s: %s\n",elemento.getKey().format(formatoFecha),elemento.getValue());
        }
 
    }
}