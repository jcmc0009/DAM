package tarea07;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

/** Ejercicio 5. Ordenación de especies de plantas (por nombre y longitud)
 * @author Profesor
 */
public class Ejercicio05 {

    public static void main(String[] args) {
        
        //----------------------------------------------
        //    Declaración de variables y constantes
        //----------------------------------------------
        
        // Constantes
        
        final int NUMERO_ESPECIES_PLANTAS = 5;
        
        // Variables de entrada
        
        // Variables auxiliares
        
        String especiePlanta; 
       
        // Variables de salida

        List<String> listaEspeciesPlantas = new ArrayList<>();
        
        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        // No se piden datos al usuario, ya que se usa un número fijo de elementos aleatorios
        
        System.out.println("ORDENACIÓN DE ESPECIES DE PLANTAS");
        System.out.println("---------------------------------");
        
        // Rellenamos la lista con especies de plantas aleatorias distintas hasta que haya NUMERO_ESPECIES_PLANTAS
        
        while (listaEspeciesPlantas.size() < NUMERO_ESPECIES_PLANTAS) {

            especiePlanta = Utilidades.especiePlantaAleatoria();

            if (!listaEspeciesPlantas.contains(especiePlanta)) {
            
                listaEspeciesPlantas.add(especiePlanta);
            }
        }
        
        // Mostramos el contenido inicial de la lista
        
        System.out.printf("\nContenido inicial de la lista:\n\n");
        
        mostrarListaEspeciePlanta(listaEspeciesPlantas);
        
        //----------------------------------------------
        //     Procesamiento + Salida de resultados
        //----------------------------------------------

        // Ordenación de la lista por nombre de la mascota (alfabético) y la mostramos por pantalla
        System.out.printf ("\nOrdenación de la lista por nombre (alfabético):\n\n");
        Collections.sort(listaEspeciesPlantas, new ComparadorEspeciePlantaPorNombre() );
        mostrarListaEspeciePlanta(listaEspeciesPlantas);
        
        // Ordenación de la lista por edades y la mostramos por pantalla
        System.out.printf ("\nOrdenación de la lista por longitud:\n\n");
        Collections.sort(listaEspeciesPlantas, new ComparadorEspeciePlantaPorLongitud() );
        mostrarListaEspeciePlanta(listaEspeciesPlantas);
        
    }

    // Método que recorre una lista de plantas y las muestra cada una por pantalla
    static void mostrarListaEspeciePlanta (List<String> listaEspeciesPlantas) {
        
        int cont = 0;
        Iterator it = listaEspeciesPlantas.iterator();
        
        while (it.hasNext()) {
        
            System.out.printf("%d. %s\n", ++cont, (String)it.next());
        }        
    }
}

/**
 * Clase que permite comparar dos objetos String usando como criterio
 * de comparación el nombre de las especies de plantas. Se trata de una comparación
 * alfabética.
 * @author Profesor
 */
class ComparadorEspeciePlantaPorNombre implements Comparator<String> {
    
    @Override
    public int compare (String ep1, String ep2) {
        
        return ep1.compareToIgnoreCase(ep2);
    }
}

/**
 * Clase que permite comparar dos objetos String usando como criterio
 de comparación la longitud del nombre de las especies de plantas.
 * @author Profesor
 */
class ComparadorEspeciePlantaPorLongitud implements Comparator<String> {
    
    @Override
    public int compare (String ep1, String ep2) {
        return ep1.length() -  ep2.length();
    }
}
