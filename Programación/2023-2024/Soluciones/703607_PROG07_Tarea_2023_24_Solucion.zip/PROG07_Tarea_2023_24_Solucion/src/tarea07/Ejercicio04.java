package tarea07;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


/** Ejercicio 4. Clasificación de especies de plantas coincidentes 
 * (con el mismo nombre y en la misma posición)
 * @author Profesor
 */
public class Ejercicio04 {

    public static void main(String[] args) {

        //----------------------------------------------
        //    Declaración de variables y constantes
        //----------------------------------------------

        // Constantes
        
        final int NUMERO_ESPECIES_PLANTAS = 20;

        // Variables de entrada
        
        // Variables auxiliares
        
        String especiePlanta1;
        String especiePlanta2;
        int posicion=0;

        List<String> listaEspeciesPlantas1 = new ArrayList<>();
        List<String> listaEspeciesPlantas2 = new ArrayList<>();

        // Variables de salida
        Map<String, List<Integer>> mapCoincidencias = new HashMap<>();

        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        
        // No se piden datos al usuario, ya que se usa un número fijo de elementos aleatorios
        
        System.out.println("CLASIFICACIÓN DE COINCIDENTES");
        System.out.println("-----------------------------");

        // Rellenamos la lista 1 con especies de plantas aleatorias hasta que haya NUMERO_ESPECIES_PLANTAS
        
        while (listaEspeciesPlantas1.size() < NUMERO_ESPECIES_PLANTAS) {

            especiePlanta1 = Utilidades.especiePlantaAleatoria();

            listaEspeciesPlantas1.add(especiePlanta1);
        }
        
        // Rellenamos la lista 2 con especies de plantas aleatorias hasta que haya NUMERO_ESPECIES_PLANTAS
        
        while (listaEspeciesPlantas2.size() < NUMERO_ESPECIES_PLANTAS) {

            especiePlanta2 = Utilidades.especiePlantaAleatoria();
            
            listaEspeciesPlantas2.add(especiePlanta2);
        }
        
        //----------------------------------------------
        //                 Procesamiento
        //----------------------------------------------
        
        Iterator it1 = listaEspeciesPlantas1.iterator();
        Iterator it2 = listaEspeciesPlantas2.iterator();

        while (it1.hasNext() && it2.hasNext()) {

            especiePlanta1 = (String) it1.next();
            especiePlanta2 = (String) it2.next();

            if (especiePlanta1.equals(especiePlanta2)) {
                if (!mapCoincidencias.containsKey(especiePlanta1)) {

                    mapCoincidencias.put(especiePlanta1, new ArrayList<>());
                }
                
                mapCoincidencias.get(especiePlanta1).add(posicion);
            }
            posicion++;
        }

        //----------------------------------------------
        //            Salida de resultados
        //----------------------------------------------
        
        System.out.printf("Contenido inicial de la lista especies de plantas 1:\n %s\n", listaEspeciesPlantas1.toString());
        System.out.printf("Contenido inicial de la lista especies de plantas 2:\n %s\n", listaEspeciesPlantas2.toString());
        System.out.println();
        System.out.printf("Clasificación de coincidencias:\n %s\n", mapCoincidencias.toString());

    }
}