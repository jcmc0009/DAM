package tarea07;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/** Ejercicio 2. Búsqueda de especies de plantas populares
 * @author Profesor
 */
public class Ejercicio02 {

    public static void main(String[] args) {
        
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        
        // Constantes
        
        final int CANTIDAD_ESPECIES_PLANTAS = 10;
        
        // Variables de entrada
        
        // Variables auxiliares
       
        String especiePlanta1 = "";
        String especiePlanta2 = "";
        int posicion = 0;
        
        // Variables de salida

        List<String> listaEspeciesPlantas1 = new ArrayList<>();
        List<String> listaEspeciesPlantas2 = new ArrayList<>();
        
        List<String> listaEspeciesPlantasPopulares = new ArrayList<>();
        Set<String> setEspeciesPlantasPopulares = new HashSet<>();
        List<Integer> listaPosicionesPopulares = new ArrayList<>();
        
        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        
        System.out.println("BÚSQUEDA DE ESPECIES DE PLANTAS POPULARES");
        System.out.println("-----------------------------------------");
        
        
        // No hay, pues se usa un número fijo de elementos aleatorios

        // Rellenamos la lista con aleatorios hasta que haya CANTIDAD_ESPECIES_PLANTAS
        
        for (int i = 0; i < CANTIDAD_ESPECIES_PLANTAS; i++) {
            
            listaEspeciesPlantas1.add(Utilidades.especiePlantaAleatoria()); 
                        listaEspeciesPlantas2.add(Utilidades.especiePlantaAleatoria()); 

        }
        
        
       
        System.out.printf("1. Contenido inicial de la lista 1: %s\n", listaEspeciesPlantas1.toString());

        System.out.printf("2. Contenido inicial de la lista 2: %s\n", listaEspeciesPlantas2.toString());
        System.out.println();
        
        //----------------------------------------------
        //               Procesamiento
        //----------------------------------------------

        Iterator it1 = listaEspeciesPlantas1.iterator();
        Iterator it2 = listaEspeciesPlantas2.iterator();

        // Recorremos a la vez las dos listas
        
        while (it1.hasNext() && it2.hasNext()) {

            especiePlanta1 = (String) it1.next();
            especiePlanta2 = (String) it2.next();

            // Comprobamos si en la misma posición encontramos la misma especie de planta en ambas listas
            if (especiePlanta1.equals(especiePlanta2)) {

                listaEspeciesPlantasPopulares.add(especiePlanta1);
                setEspeciesPlantasPopulares.add(especiePlanta1);
                // posicion = listaEspeciesPlantas1.indexOf(especiePlanta1);
                listaPosicionesPopulares.add(posicion);
                listaEspeciesPlantas1.set(posicion, "*" + especiePlanta1 + "*");
                listaEspeciesPlantas2.set(posicion, "*" + especiePlanta2 + "*");
            }
            posicion++;
        }
        
        //----------------------------------------------
        //            Salida de resultados
        //----------------------------------------------
        
        System.out.printf("1. Contenido final de la lista 1:  %s\n", listaEspeciesPlantas1.toString());
        System.out.printf("2. Contenido final de la lista 2:  %s\n", listaEspeciesPlantas2.toString());
        System.out.printf("3. Contenido final de la lista de especies de plantas populares: %s\n", listaEspeciesPlantasPopulares.toString());
        System.out.printf("4. Contenido final de la lista de posiciones populares: %s\n", listaPosicionesPopulares.toString());
        System.out.printf("5. Contenido final del conjunto de especies de plantas populares: %s\n", setEspeciesPlantasPopulares.toString());

    }
}