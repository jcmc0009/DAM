package tarea01;

import java.util.Scanner;

/**
 * Ejercicio 2. Operadores aritméticos
 *
 * @author Profesor
 */
public class Ejercicio2 {

    public static void main(String[] args) {
        //----------------------------------------------
        //    Declaración de variables y constantes
        //----------------------------------------------

        // Constantes 
        // Variables de entrada 
        int numero1, numero2, numero3;
        
        // Variables de salida
        double tercioMitad;
        double cuadradoMitadSuma;
        boolean esPar;
        double sumaMultiplicacion;
        
        // Variables auxiliares
        
        // Clase Scanner para petición de datos al usuario a través del teclado
        Scanner teclado = new Scanner(System.in);

        
        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        System.out.println("Ejercicio 2. Operadores aritméticos");
        System.out.println("-----------------------------------");
        
        System.out.print("Introduce el valor del primer número: "); 
        numero1 = teclado.nextInt();                            

        System.out.print("Introduce el valor del segundo número: "); 
        numero2 = teclado.nextInt();                            

        System.out.print("Introduce el valor del tercer número: "); 
        numero3 = teclado.nextInt();                            
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        tercioMitad = ((double)numero1/3) + ((double)numero3/2);
        cuadradoMitadSuma = ((double)(numero2+numero3)/2)*((double)(numero2+numero3)/2);
        esPar = (3*(numero2+numero3-numero1)%2)==0;
        sumaMultiplicacion = (((double)numero1+(double)numero2)*((double)numero3-(double)numero1))/numero2;
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");
        
        System.out.println("Valor del tercio del primer número más la mitad del tercer número: " + tercioMitad);
        System.out.println("Valor del cuadrado de la mitad de la suma del segundo número más el tercero: " + cuadradoMitadSuma);
        System.out.println("Comprobamos si el triple de la suma del segundo más el tercer número menos el primero es par: " + esPar);
        System.out.println("Valor de la suma del primero más el segundo, multiplicado por la diferencia del tercero menos el primero y todo ello partido por el segundo número: " + sumaMultiplicacion);

        System.out.println();
        System.out.println("Fin del programa.");

    }
}
