package tarea01;

import java.util.Scanner;

/**
 * Ejercicio 3. Palabras circulares
 *
 * @author Profesor
 */
public class Ejercicio3 {

    public enum Resultado { SI, NO} ;
    
    public static void main(String[] args) {
        //----------------------------------------------
        //    Declaración de variables y constantes
        //----------------------------------------------

        // Constantes 
        
        // Variables de entrada 
        String palabra1, palabra2, palabra3;
        
        // Variables de salida 
        boolean menosDe6_masDe8, segundaMayorLongitud, palabrasEncadenadas, palabrasCirculares;

        // Variables auxiliares
        // Clase Scanner para petición de datos al usuario a través del teclado
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        System.out.println("Ejercicio 3. Palabras encadenadas");
        System.out.println("---------------------------------");

        System.out.print("Introduce la PRIMERA palabra: ");    
        palabra1 = teclado.next();                              
        System.out.print("Introduce la SEGUNDA palabra: ");    
        palabra2 = teclado.next();                              
        System.out.print("Introduce la TERCERA palabra: ");    
        palabra3 = teclado.next();                              

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        menosDe6_masDe8 = (palabra1.length() < 6 && palabra2.length() < 6) || palabra3.length() > 8;  // se compara la longitud de las dos primeras o de la última
        segundaMayorLongitud = palabra2.length()>palabra1.length() && palabra2.length()>palabra3.length(); // se comprueba si la segunda es de mayor longitud que las otras dos
        /* 
            para comprobar las palabras encadenadas miramos los primeros y últimos caracteres de cada palabra. Si queremos obviar el hecho de que 
            se introduzcan en mayúsculas o minúsculas podemos convertir cada palabra a minúsculas (o mayúsculas) antes de comparar
        */
        palabrasEncadenadas = palabra1.toLowerCase().charAt( palabra1.length()-1) == palabra2.toLowerCase().charAt(0) && 
                              palabra2.toLowerCase().charAt( palabra2.length()-1) == palabra3.toLowerCase().charAt(0);
        
        /* 
            para comprobar si se trata de palabras circulres nos apoyamos en la comprobación hecha anteriormente (solo podrán ser circulares si 
            también son encadenadas). Además comprobamos si la tercera palabra también está encadenada a la primera palabra.
        */
        palabrasCirculares = palabrasEncadenadas && palabra3.charAt( palabra3.length()-1) == palabra1.charAt(0);
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");
        System.out.println("La longitud de las dos primeras palabras es menor de 6 o la longitud de la tercera es mayor de 8 caracteres : " + (menosDe6_masDe8? Resultado.SI:Resultado.NO ) );
        System.out.println("La segunda palabra es la palabra de mayor longitud : " + (segundaMayorLongitud? Resultado.SI:Resultado.NO ) );
        System.out.println("Las tres palabras introducidas son palabras encadenadas: " + (palabrasEncadenadas? Resultado.SI:Resultado.NO ) );
        System.out.println("Las tres palabras introducidas son palabras circulares: " + (palabrasCirculares? Resultado.SI:Resultado.NO ) );
        System.out.println("");
        System.out.println("Fin del programa.");
        

    }
}
