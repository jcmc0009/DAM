package tarea01;

import java.util.Scanner;

/**
 * Ejercicio 4. Gestión de recursos hídricos
 *
 * @author Profesor
 */
public class Ejercicio4 {

    public static void main(String[] args) {
        //----------------------------------------------
        //    Declaración de variables y constantes
        //----------------------------------------------

        // Constantes 
        final int CAPACIDAD_EMBALSE = 2000;
        final int LIMITE = 95;
        
        final double LIBERACION1 = (double)10 / 100; //al 95% se debe liberar un 10%
        final double SIN_LIBERACION = 0; // 0%

        // Variables de entrada 
        double volumenActual;

        // Variables de salida 
        double porcentajeActual;
        double hectometrosLiberados;
        String mensajeLiberacion;
        

        // Variables auxiliares
        double porcentajeLiberacion;
        double porcentajeTrasLiberacion;
        
        // Clase Scanner para petición de datos al usuario a través del teclado
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        System.out.println("Ejercicio 4. Gestión de recursos hídricos");
        System.out.println("-----------------------------------------");
        
        System.out.print("Introduce el volumen actual de agua almacenada en el embalse (hectómetros cúbicos): ");
        volumenActual = teclado.nextDouble();
        System.out.println("");

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        porcentajeActual = volumenActual*100/CAPACIDAD_EMBALSE;
        System.out.printf("La capacidad máxima del embalse es de %d hectómetros cúbicos.\n", CAPACIDAD_EMBALSE );
        System.out.printf("Faltan %.2f hectómetros cúbicos para llenar completamente el embalse.\n", (CAPACIDAD_EMBALSE-volumenActual) );
        System.out.printf("El embalse está a un %.2f%% de su capacidad máxima.\n", porcentajeActual);
        
        porcentajeLiberacion = (porcentajeActual>LIMITE)? LIBERACION1 :        // liberación si la capacidad supera el límite
                                SIN_LIBERACION;                                 // no hay liberación
        
        hectometrosLiberados = volumenActual*porcentajeLiberacion;
        
        volumenActual -= hectometrosLiberados; // se actualiza el volumen del embalse restando la cantidad liberada
        porcentajeTrasLiberacion = volumenActual*100/CAPACIDAD_EMBALSE;
        
        // se construye el mensaje mediante una operación ternaria (si hay liberación se muestra toda la información, si no hay liberación solo se indica esa situación
        mensajeLiberacion = (porcentajeLiberacion>0)? "Se ha realizado una liberación del " + (porcentajeLiberacion*100) + "% vaciando un total de " + hectometrosLiberados +
                " hectómetros cúbicos.\nEn el embase quedan ahora " + volumenActual + " hectómetros cúbicos, que representan un " + porcentajeTrasLiberacion + "% de su capacidad máxima.": "No es necesario considerar la liberación controlada de agua en este momento.";
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");
        System.out.println(mensajeLiberacion); // se muestra el mensaje que se ha construido
        System.out.println();
        System.out.println("Fin del programa.");
    }
}
