package tarea01;

import java.util.Scanner;

/**
 * Ejercicio 1. Cálculo del volumen de un cilindro
 *
 * @author Profesor
 */
public class Ejercicio1 {

    public static void main(String[] args) {
        //----------------------------------------------
        //    Declaración de variables y constantes
        //----------------------------------------------

        // Constantes 
        final double PI = 3.1415927;

        // Variables de entrada 
        double radio;
        double altura;

        // Variables de salida 
        // Variables auxiliares
        double resultado;

        // Clase Scanner para petición de datos al usuario a través del teclado
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        System.out.println("Ejercicio 1. Cálculo del volumen de un cilindro");
        System.out.println("-----------------------------------------------");

        System.out.print("Introduce el radio del cilindro: "); // mostramos un mensaje sobre la información que vamos a pedir por teclado
        radio = teclado.nextDouble();                            // a través del Scanner pedimos al usuario que el valor del radio

        System.out.print("Introduce la altura del cilindro: ");   // mostramos un mensaje sobre la información que vamos a pedir por teclado
        altura = teclado.nextDouble();                            // a través del Scanner pedimos al usuario que el valor de la altura

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        resultado = PI * radio * radio * altura;  // fórmula: PI x radio al cuadrado x altura

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");
        System.out.printf("El volumen de un cilindro de radio %.2f y altura %.2f es %.2f\n\n", radio, altura, resultado);

        System.out.println("Fin del programa.");

    }
}
