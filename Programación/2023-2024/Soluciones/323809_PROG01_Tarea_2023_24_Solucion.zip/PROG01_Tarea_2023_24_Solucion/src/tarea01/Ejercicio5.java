package tarea01;

import java.util.Scanner;

/**
 * Ejercicio 5. ¡Vamos al parque acuático!
 * @author Profesor
 */
public class Ejercicio5 {

    public static void main(String[] args) {
    //----------------------------------------------
    //    Declaración de variables y constantes
    //----------------------------------------------

           // Constantes 
           final double PRECIO_INFANTIL = 9.00, PRECIO_ADULTO = 13.50;
           final double LIMITE_DESCUENTO1 = 50.00;
           final double LIMITE_DESCUENTO2 = 100.00;
           final double PORCENTAJE_DESCUENTO1 = (double)5/100; // 5% de descuento (división de dos enteros, es necesario casting explícito)
           final double PORCENTAJE_DESCUENTO2 = (double)15/100; // 15% de descuento  (división de dos enteros, es necesario casting explícito)
           final double NO_HAY_DESCUENTO = 0; // 0% -> No hay descuento          
           final double IVA = (double)21/100; // 21% IVA aplicable (división de dos enteros, es necesario casting explícito)
           
           // Variables de entrada 
           int entradasInfantil, entradasAdulto;
    
           // Variables de salida 
           double importeBase, importeTotalConDescuento, importeFinalIVAIncl;
           int cantidadPagar;
           
           // Variables auxiliares
           double descuentoAplicar;
           String textoDescuento;
           
    
           // Clase Scanner para petición de datos al usuario a través del teclado
           Scanner teclado= new Scanner (System.in);

       //----------------------------------------------
       //               Entrada de datos 
       //----------------------------------------------
       
            System.out.println("Ejercicio 5. ¡Vamos al parque acuático!");
            System.out.println("---------------------------------------");
            
            System.out.print("Introduce la cantidad de entradas DE ADULTO que deseas adquirir: ");
            entradasAdulto = teclado.nextInt();

            System.out.print("Introduce la cantidad de entradas INFANTILES que deseas adquirir: ");
            entradasInfantil = teclado.nextInt();
            
       //----------------------------------------------
       //                 Procesamiento 
       //----------------------------------------------
            importeBase = entradasInfantil*PRECIO_INFANTIL  + entradasAdulto*PRECIO_ADULTO; // cálculo del importe base (número de entradas de cada tipo por su precio)

            descuentoAplicar = (importeBase>LIMITE_DESCUENTO2)? PORCENTAJE_DESCUENTO2 :     // si el importe es superior al límite para aplicar el mayor descuento
                               (importeBase>LIMITE_DESCUENTO1)? PORCENTAJE_DESCUENTO1 :     // si el importe es superior al límite para aplicar el otro descuento
                               NO_HAY_DESCUENTO;                                            // si el importe es inferior al límite para aplicar descuentos

            textoDescuento = (descuentoAplicar>NO_HAY_DESCUENTO)? "Se aplicará un descuento del " + descuentoAplicar*100 +"%" :  "No procede descuento en esta compra";
            importeTotalConDescuento = importeBase * (1-descuentoAplicar);
            importeFinalIVAIncl = importeTotalConDescuento * (1+IVA);
            cantidadPagar = (int)importeFinalIVAIncl;
       
       //----------------------------------------------
       //              Salida de resultados 
       //----------------------------------------------
           System.out.println();
           System.out.println("RESULTADO");
           System.out.println("---------");
           System.out.printf("Se comprarán %d entradas de tipo ADULTO y %d entradas de tipo INFANTIL\n", entradasAdulto, entradasInfantil);
           System.out.printf("El coste de las entradas antes de aplicar descuentos es de %.2f €\n", importeBase);
           System.out.println(textoDescuento);
           System.out.printf( "Tras aplicar posibles descuentos el importe total de las entradas (sin IVA) es de %.2f €\n", importeTotalConDescuento);
           System.out.printf("El importe IVA incluido es de %.2f €\n", importeFinalIVAIncl);
           System.out.printf("La cantidad final a pagar por el cliente es de %d €\n", cantidadPagar);
       }    
}