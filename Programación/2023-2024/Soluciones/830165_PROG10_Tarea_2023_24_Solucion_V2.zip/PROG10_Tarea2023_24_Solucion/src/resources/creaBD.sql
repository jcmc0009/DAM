DROP TABLE IF EXISTS Disponible_en ;

DROP TABLE IF EXISTS Plataformas ;

DROP TABLE IF EXISTS Peliculas ;


--
-- Estructura de las tablas
--
create table IF NOT EXISTS Peliculas (
	codigo		INT primary key,
	titulo		varchar(60) not null,
	sinopsis	varchar(300),
	fEstreno	date not null
);

create table IF NOT EXISTS Plataformas (
	codigo		INT primary key,
	nombre		varchar(20) not null,
	urlLogotipo	varchar(200)
);

create table IF NOT EXISTS Disponible_en (
	codPlataforma           INT,
	codPelicula             INT,
	fDisponibilidad	date not null,
	primary key (codPlataforma, codPelicula),
	foreign key (codPlataforma) references Plataformas(codigo),
	foreign key (codPelicula) references Peliculas(codigo)
);