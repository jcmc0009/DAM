/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repasoMoodle.ejeInterfaces.Supermercado;

/**
 *
 * @author JoseManuel
 */
public interface ConDescuento {
    public void setDescuento(double des);
    public double getDescuento();
    public double getPrecioDescuento();
}
