package junio.ejercicio2;

/**
 * Interface Transformacion
 *
 * @author
 */
public interface Transformacion {

    /**
     *
     */
    public void transformarse();

}
