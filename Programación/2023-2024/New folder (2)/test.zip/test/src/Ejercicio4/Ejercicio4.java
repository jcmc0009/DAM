/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio4;



/**
 * Programa para trabajar con DOM.
 * @profesorado
 */
public class Ejercicio4 {

    /**
    * Método principal.
    */
    public static void main(String[] args) {
        
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
       
                
        // Variables de salida
      
        
        // Variables auxiliares
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        
        
            
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
         
        
        System.out.println ();
	System.out.println ("Archivo cerrado y procesamento finalizado");
	System.out.println ("---------");
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
    }
}
