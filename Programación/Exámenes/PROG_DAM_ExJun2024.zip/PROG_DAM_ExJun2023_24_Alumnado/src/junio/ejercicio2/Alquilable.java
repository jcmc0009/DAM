package junio.ejercicio2;

/**
 * Interfaz Alquilable
 * @author Alumno/a
 */
