package junio.ejercicio2;

/**
 * Programa de pruebas
 * @author Alumno/a
 */
public class PruebaInmuebles {

    public static void main(String[] args) {
        
        //  Intentos de creación de inmuebles no válidos según las especificaciones del enunciado
        System.out.println("------CREACIÓN DE INMUEBLES CON DATOS NO VÁLIDOS------");
                
        // Intento de crear un objeto de tipo Casa con número de habitaciones no válido y los siguientes datos
        // Ref. catastral: 1VH222S3, dirección: Avenida La Paz, habitaciones: 0, fecha de construcción: 25/01/2007, plantas: 2, tipo de casa: Individual, piscina: no
        
        
        // Intento de crear un objeto de tipo Piso con año no válido y los siguientes datos
        // Ref. catastral: 1VH222S3, dirección: Avenida La Paz, habitaciones: 2, fecha de construcción: 31/12/1949, comunidad: 27.50 euros

        
        // Creación de inmuebles con datos válidos
        System.out.println("-------------CREACIÓN DE INMUEBLES VÁLIDOS------------");
        
        // Creación de un inmueble de tipo Casa con los siguientes datos
        // Ref. catastral: 1VH222S3, dirección: Avenida La Paz, habitaciones: 4, fecha de construcción: 25/01/2007, plantas: 2, tipo de casa: Individual, piscina: no.
        System.out.println("Creando un inmueble 'casa1' de tipo Casa...");
        
        
        // Creación de un inmueble de tipo Casa con los siguientes datos
        // Ref. catastral: 1GY782L3, dirección: Calle Sacramento, habitaciones: 3, fecha de construcción: 02/09/2000
        System.out.println("Creando un inmueble 'casa2' de tipo Casa...");
        
        
        // Creación de un inmueble de tipo Piso con datos válidos
        // Ref. catastral: 1VJ256Z7, dirección: Avenida Pedro Muñoz Seca, habitaciones: 2, fecha de construcción: 23/10/2002, comunidad: 27.50 euros
        System.out.println("Creando un inmueble 'piso1' de tipo Piso...");

        
        //Imprimimos los datos de los tres inmuebles junto con la tarifa de alquiler de cada uno
        System.out.println("-------------INFORMACIÓN DE LOS INMUEBLES------------");
        System.out.println("Datos del inmueble 'casa1' de tipo Casa:");
        
        
        
        System.out.println("Datos del inmueble 'casa2' de tipo Casa:");
        
        
        
        System.out.println("Datos del inmueble 'piso1' de tipo Piso:");
        
        
        
        
        //Imprimimos la cantidad de inmuebles creados
        System.out.println("\n------------------INFORMACIÓN GENERAL-----------------");

        
    }
    
}
