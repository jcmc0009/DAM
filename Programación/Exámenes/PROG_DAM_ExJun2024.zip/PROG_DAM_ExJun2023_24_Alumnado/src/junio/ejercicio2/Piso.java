package junio.ejercicio2;

/**
 * Clase que representa un <strong>Inmueble</strong> de tipo Piso
 * para la gestión de viviendas en una inmobiliaria.
 *  
 * @author Alumno/a
 */
