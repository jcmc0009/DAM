package junio.ejercicio3;

/**
 * Ejercicio 3
 * @author Alumno/a
 */
public class Ejercicio3 {
    
    public static void main(String[] args) {
        
        //----------------------------------------------
        //    Declaración de variables y constantes
        //----------------------------------------------

        // Definir e instanciar el mapa para almacenar los datos donde las claves son enteros y los valores son listas de enteros

        
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        /* Rellenar la estructura con los 5 primeros números a partir del 2 y sus 10 primeros múltiplos
                        (nota: debes utilizar estructuras de repetición)                                 */


        
        // Generar el archivo de texto Multiplos.txt y volcar la información en él
       
        
        
    }   
}
