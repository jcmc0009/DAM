package examenfeb;

import java.util.StringTokenizer;

/**
 * Clase para simular un acto de compra en tienda de videojuegos.
 * @author profe
 */
public class CompraVideojuegos {

    // Atributos 
    private int cantidadPS5 = 0;
    private int cantidadXbox = 0;
    private int cantidadSwitch = 0;
    
    private double gastoPS5 = 0.0;
    private double gastoXbox = 0.0;
    private double gastoSwitch = 0.0;

    /**
     * Constructor que genera un objeto de tipo compra a partir de un ticket.
     * La estructura del ticket de compra debe ser:
     * Titulo del juego,Plataforma,Precio#Titulo del juego,Plataforma,Precio#. . . 
     * @param ticket 
     */
    public CompraVideojuegos(String ticket) {

        StringTokenizer tokenVideojuegos = new StringTokenizer(ticket, "#");

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        while (tokenVideojuegos.hasMoreTokens()) {
            String producto = tokenVideojuegos.nextToken();
            StringTokenizer tokenCaracteristicas = new StringTokenizer(producto, ",");

            while (tokenCaracteristicas.hasMoreTokens()) {

                String nombre = tokenCaracteristicas.nextToken();  // se puede omitir la variable porque no se va a usar
                String plataforma = tokenCaracteristicas.nextToken();
                String precioStr = (tokenCaracteristicas.nextToken());
                double precio = Double.parseDouble(precioStr);

                switch (plataforma.toUpperCase()) {
                    case "XBOX":
                        cantidadXbox++;
                        gastoXbox += precio;
                        break;

                    case "SWITCH":
                        cantidadSwitch++;
                        gastoSwitch += precio;
                        break;

                    case "PS5":
                        cantidadPS5++;
                        gastoPS5 += precio;
                        break;
                }
            }
        }

    }

    /**
     * Obtiene la cantidad de juegos comprados para una plataforma concreta (XBOX, SWITCH o PS5)
     * @param plataforma
     * @return 
     */
    public int getCantidad(String plataforma) {
        int cantidad = 0;
        switch (plataforma) {
            case "XBOX":
                cantidad = cantidadXbox;
                break;

            case "SWITCH":
                cantidad = cantidadSwitch;
                break;

            case "PS5":
                cantidad = cantidadPS5;
                break;
        }
        return cantidad;
    }
    
    /**
     * Obtiene el gasto realizado para una plataforma concreta (XBOX, SWITCH o PS5)
     * @param plataforma
     * @return 
     */
    public double getGasto (String plataforma) {
        double gasto = 0.0;
        switch (plataforma) {
            case "XBOX":
                gasto = gastoXbox;
                break;

            case "SWITCH":
                gasto = gastoSwitch;
                break;

            case "PS5":
                gasto = gastoPS5;
                break;
        }
        return gasto;
    }

    /**
     * Obtiene el gasto total de la compra
     * @return 
     */
    public double getGastoTotal() {
        return this.getGasto("XBOX") + this.getGasto("SWITCH") + this.getGasto("PS5");
    }
    
    
    /**
     * Programa de pruebas
     * @param args argumentos de consola
     */
    public static void main(String[] args) {
        
        final double IVA = 0.21;
        String ticket = "God of War Ragnarok,PS5,66.10#FIFA 23,XBOX,57.84#NBA 2k23,XBOX,37.18#Mario Kart 8 Deluxe,Switch,41.31#Need For Speed Unbound,PS5,56.19";


        System.out.println("EJERCICIO 3. COMPRA DE VIDEOJUEGOS");
        System.out.println("----------------------------------");
        
        System.out.printf ("Creando objeto de compra con el ticket:\n\"%s\"\n", ticket);
        CompraVideojuegos compra = new CompraVideojuegos (ticket);
        

        System.out.println();
        System.out.printf("%d Videojuego/s PS5\t%6.2f€\t(%6.2f€ IVA incluido)\n", 
                compra.getCantidad("PS5"), 
                compra.getGasto("PS5"), 
                (compra.getGasto("PS5")*(1+IVA)));

        System.out.printf("%d Videojuego/s SWITCH\t%6.2f€\t(%6.2f€ IVA incluido)\n", 
                compra.getCantidad("SWITCH"), 
                compra.getGasto("SWITCH"), 
                (compra.getGasto("SWITCH")*(1+IVA)));
        
        System.out.printf("%d Videojuego/s XBOX\t%6.2f€\t(%6.2f€ IVA incluido)\n", 
                compra.getCantidad("XBOX"), 
                compra.getGasto("XBOX"), 
                (compra.getGasto("XBOX")*(1+IVA)));
                
        System.out.println("------------------------------------------------------");
        System.out.printf("\t\tTotal:\t%.2f€\t(%.2f€ IVA incluido)\n\n", 
                compra.getGastoTotal(), 
                compra.getGastoTotal()*(1+IVA) );

    }
}
