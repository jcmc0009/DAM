package examenfeb;

import java.util.Arrays;

/**
 * Comprobar en un array dado, las posiciones de aquellos elementos enteros 
 * que cumplen que en dicha posición, el elemento anterior es menor que el 
 * actual y mayor que el siguiente.
 * 
 * @author JJBH
 */
public class Ejercicio02 {
    
    public static void main(String[] args) {
        
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        int[] numeros = {1, 15, 35, 40, 7, 8, 8, 8, 10, 51, 41, 42, 99, 1, 2, 2, 3, 3 } ;
        int vecesIguales = 0;
        int vecesDecrecim = 0;

        //----------------------------------------------
        //               Entrada de datos 
        //                       +
        //                 Procesamiento 
        //                       +
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println("EJERCICIO 2. NÚMEROS NO CRECIENTES");
        System.out.println("----------------------------------");
        System.out.println (Arrays.toString(numeros));
        
        // Recorremos el array para detectar cuándo se deja de crecer
        System.out.println();
        System.out.println ("Se decrece en las posiciones: ");
        for (int contador=0; contador< numeros.length-1; contador++) {
                if ( numeros[contador+1] < numeros[contador] ) {
                    System.out.printf ("%2d: %d -> %d.\n", 
                            contador+1, numeros[contador], numeros[contador+1]);
                    vecesDecrecim++;
                }                             
        }
        System.out.printf ("Total: %d.\n", vecesDecrecim);

        // Recorremos el array para detectar cuándo se repiten dos seguidos
        System.out.println();
        System.out.println ("Se repiten valores seguidos en las posiciones: ");
        for (int contador=0; contador< numeros.length-1; contador++) {
                if ( numeros[contador+1] == numeros[contador] ) {
                    System.out.printf ("%2d: %d -> %d.\n", 
                            contador+1, numeros[contador], numeros[contador+1]);
                    vecesIguales++;
                }            
        }
        System.out.printf ("Total: %d.\n", vecesIguales);


    }
    
}
