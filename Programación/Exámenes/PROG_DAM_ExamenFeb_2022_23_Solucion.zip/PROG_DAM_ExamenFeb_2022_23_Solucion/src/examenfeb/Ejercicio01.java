package examenfeb;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Ejercicio 1.
 * @author profe
 */
public class Ejercicio01 {
    
    public static void main(String[] args) {
        
    //----------------------------------------------
    //          Declaración de variables 
    //----------------------------------------------
        long numero = 0 ;        
        int totalBytes = 0, totalEnteros = 0, totalShorts = 0, totalLongs = 0;


    //----------------------------------------------
    //               Entrada de datos 
    //                       +
    //                 Procesamiento 
    //                       +
    //              Salida de resultados 
    //----------------------------------------------

        System.out.println("EJERCICIO 1. TIPOS ENTEROS ENTEROS JAVA");
        System.out.println("---------------------------------------");
        
        // Bucle mientras que no se lea un 0, momento en que acabará el programa
        // (se mezclan entrada de datos, procesamiento y salida de resultados)
        do {
            try {
                // Objeto Scanner para lectura desde teclado
                Scanner teclado = new Scanner(System.in);
                // Leer y almacenar en entero
                System.out.print("\nEscriba número entero (byte, short, int o long): ") ;
                numero = teclado.nextLong() ;

                // Si es un byte
                if (numero >= Byte.MIN_VALUE && numero <= Byte.MAX_VALUE) {
                    byte numConvertido = (byte) numero ;
                    System.out.printf("byte de valor %d.\n",numConvertido) ;
                    totalBytes++ ;
                // Si no, si está en el rango de los short
                } else if (numero >= Short.MIN_VALUE && numero <= Short.MAX_VALUE) {
                    short numConvertido = (short) numero ;
                    System.out.printf("short de valor %d.\n",numConvertido) ;
                    totalShorts++ ;
                // Si el número se puede alojar en un entero
                } else if (numero >= Integer.MIN_VALUE && numero <= Integer.MAX_VALUE) {
                    int numConvertido =  (int) numero ;
                    System.out.printf("int de valor %d.\n",numConvertido) ;
                    totalEnteros++ ;
                } else {
                    System.out.printf("long de valor %d.\n",numero) ;
                    totalLongs++ ;
                }

            } catch (InputMismatchException e) {
                System.out.println("Error: se esperaba un número entero.");
                numero = -1 ;
                
            } /*catch (Exception e) {
                System.out.printf("Error. %s\n", e.getMessage());
                System.out.println();
                numero = -1 ;
            }*/
            
        } while (!(numero == 0)) ;
                       
        // Salida final de los contadores
        System.out.println();
        System.out.printf("Hubo %d bytes %d shorts %d enteros %d long \n", totalBytes, totalShorts, totalEnteros, totalLongs) ;
        
    }
    
}
