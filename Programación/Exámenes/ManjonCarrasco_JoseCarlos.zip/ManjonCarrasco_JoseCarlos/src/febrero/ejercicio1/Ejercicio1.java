package febrero.ejercicio1;

/**
 * Ejercicio 1
 * @author Alumno/a
 */

public class Ejercicio1 {

    public static void main(String[] args) {
        
        
        //----------------------------------------------
        //    Declaración de variables y constantes
        //----------------------------------------------

        
        // Definición e inicializción de la matriz
        double[][] matriz = {
            {79.5, 27.3, 53.7, 44.1, 55.6},
            {69.2, 17.8, 38.4, 99.0, 10.5},
            {11.1, 12.6, 10.2, 14.7, 1.3},
            {16.8, 17.4, 18.9, 19.5, 20.0},
            {20.6, 21.1, 22.7, 23.3, 24.8},
            {23.1, 45.6, 33.2, 84.7, 90.3},
            {12.8, 23.4, 89.9, 23.5, 12.0}
        };

        
        // Variables de salida 
        



        
        
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        // Se muestra la matriz con formato de dos decimales



        
        // Cálculo de la media de cada fila y almacenamiento en un array unidimensional


        
        
        // Se inicializan los valores de las medias
        

        
        
        // Recorrer el array de medias y calcular la media total, el valor medio mayor y el valor medio menor 


        
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        // Imprimir los valores del array (medias de cada fila) con dos dígitos decimales
        
        

        // Imprimir la media total, el valor medio mayor y el valor medio menor del array
        
        
        
    }
}
