package tarea03;

/**
 * Ejercicio 3: Vamos al cine.<br>
 * En este ejercicio trabajaremos con objetos de tipo fecha y de tipo hora a través de las clases LocalDate y LocalTime respectivamente.
 *
 * @author [COLOCA AQUÍ TU NOMBRE]
 */
public class Ejercicio3 {

    public static void main(String[] args) {

        System.out.println("\nEjercicio 3. ¡Vamos al cine!");
        System.out.println("----------------------------");

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        





        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------

        // 1.- Lectura por teclado de la fecha para la que se quiere reservar (mínimo con una semana de antelación)
        /* Se deberán cumplir los requisitos del enunciado y determinará si es uno de los Días del Espectador */


        






        
        
        // 2. Lectura por teclado y comprobación de hora y minuto (cumpliendo los requisitos del enunciado)

   










        // 3. Creación de los objetos LocalTime de referencia:
        
        // 3.1. Creación de un objeto LocalTime de referencia para almacenar la hora de la primera sesión de cine (17:00)

        


        // 3.2 Creación de objeto LocalTime con la hora indicada a partir de los datos (hora y minuto) leídos por teclado





        //----------------------------------------------
        //               Procesamiento 
        //----------------------------------------------
        
        // 4. Obtener la siguiente sesión (y su precio) a la que el usuario puede entrar según la hora que ha indicado
        









        

        //----------------------------------------------
        //            Salida de resultados 
        //----------------------------------------------
        // 5. Mostrar por pantalla los resultados obtenidos según el procesamiento realizado.







        
        System.out.println();
        System.out.println("El programa ha finalizado!!");
        System.out.println();

    }
}
