package trenes.controladores;


/**
 * Clase abstracta ControlServicio. Servirá para agrupar todas las
 * características comunes a los diferentes controles que pueda presentar cada
 * vagón del tren.
 *
 * @author David - IES Trassierra
 * @version 1.0
 */

public class ControlServicio {


	/*
	 * Atributo de clase numControlesConfigurados. Sirve para controlar el número de
	 * objetos de tipo ControlServicio en cada instante.
	 */


	/*
	 * Atributo inmutable idControlServicio. Sirve para identificar con un número a
	 * cada Control que se cree de esta clase.
	 */


	/*
	 * Atributo nombreControlServicio. Sirve para darle un nombre a cada control.
	 */


	/*
	 * Atributo tipoControlServicio. Sirve para asignarle un tipo a cada control, el
	 * tipo dependerá el control que estemos trabajando, en princpio puede ser de
	 * cuatro tipos: PuertaVagon
	 */


	/*
	 * Constructor con un parámetro de ControlServicio. Este constructor simplemente
	 * recibe un nombre de control de servicio para asignarlo al control que se va a
	 * crear. Automáticamente asignar el identificador de Control de Servicio
	 * (idControlServicio) a partir del número de controles existentes ya
	 * configurados. Y asigna como tipo de Control de servicio (tipoControlServicio)
	 * el valor "Desconocido"
	 */


	/*
	 * Constructor sin parámetros de ControlServicio. Este constructor simplemente
	 * inicializa valores por defecto al control que se va a crear. Automáticamente
	 * asignar el identificador de Control de Servicio (idControlServicio) a partir
	 * del número de controles existentes ya configurados. Y asigna como tipo de
	 * Control de servicio (tipoControlServicio) el valor "Desconocido". De la misma
	 * forma asigna "Desconocido" al nombre de control de Servicio
	 * (nombreControlServicio)
	 */


	/*
	 * Método estático observador (getter) que devuelve el número de controles
	 * actualmente configurados
	 */


	/*
	 * Método estático modificador (setter) que asigna el número de controles
	 * actualmente configurados. Para que se pueda asignar dicho valor se debe
	 * comprobar que sea mayor o igual que cero.
	 */


	/*
	 * Método observador (getter) que devuelve el identificador de control
	 * de servicio
	 */




	/*
	 * Método  observador (getter) que devuelve el nombre del control de servicio
	 */


	/*
	 * Método modificador (setter) que asigna el nombre de control de servicio al
	 * que pertenece este objeto.
	 * 
	 */


	/*
	 * Método observador (getter) que devuelve el tipo de control de servicio del
	 * objeto
	 */


	/*
	 * Método modificador (setter) que asigna el tipo de control de servicio al que
	 * pertenece este objeto. Para que se pueda asignar dicho valor se debe
	 * comprobar que pertenezca a uno de los cuatro tipos permitidos: "Puerta",
	 * Ventanilla, "Altavoz" o "TiraLuz". En caso se no corresponderse el parámetro
	 * para asignar con ninguno de estos cuatro tipos se asignará "Desconocido"

	 */

	/*
	 * Método toString devuelve un String con los valores actuales de los atributos
	 * Cada atributo aparecerá en una línea y su tabulación
	 */

    
    
    


}
