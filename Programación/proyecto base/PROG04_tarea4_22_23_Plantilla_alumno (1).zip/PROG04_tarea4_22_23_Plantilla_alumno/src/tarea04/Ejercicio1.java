package tarea04;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author luisnavarro
 */
public class Ejercicio1 {

    public static void main(String[] args) {
        
        String alfabeto = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String[] palabrasProhibidas = {"STAR", "THE", "AL", "DE","AS"};
        
        String correspondencia="";

        System.out.println("Las letras correspondientes a :" + alfabeto);
        System.out.println("son las siguientes en orden.. :" + correspondencia);
        System.out.println("");
        System.out.println("Letra sin codificar-------Letra codificada");

    }
}
