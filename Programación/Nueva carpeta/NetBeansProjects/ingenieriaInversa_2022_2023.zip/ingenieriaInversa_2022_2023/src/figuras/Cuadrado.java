package figuras;

/**
 *
 * @author Ana Espina Martínez
 */
public class Cuadrado extends Rectangulo {

    public Cuadrado(double lado) {
        super(lado, lado);
    }
    
}
