package tarea03;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

/**
 * Ejercicio 2: ¡A jugar! Utilización de las clases CartonBingo y Bombo para simular una partida.<br>
 * En este ejercicio probamos el funcionamiento de la clase Bombo tratando de conocer los métodos que tiene y el funcionamiento de cada uno de ellos.
 * 
 * @author Fran Jiménez
 */
public class Ejercicio2 {
    
    public static void main(String[] args) {
        
        final LocalDate HOY = LocalDate.now();
    
        // 1. Presentación del ejercicio
        System.out.println("Ejercicio 2. ¡A jugar!");
        System.out.println("----------------------");
        /* 
            Debes mostrar la fecha ACTUAL (hoy) usando la API de LocalDate
            (usa también DateTimeFormatter para formatear la fechala correctamente (ej. 08/11/2022)
        */
        System.out.printf("Fecha ACTUAL de ejecución: %s\n", HOY.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) );
        System.out.println();  
        
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        
        // Constantes 
        final int NUMEROS_CARTON = 15;
        
        // Variables de entrada
        String nombreJugador1, nombreJugador2;
        
        // Variables auxiliares
        CartonBingo cartonJugador1, cartonJugador2;
        int bolaBombo;
        Scanner teclado = new Scanner(System.in);
        boolean hayLineaValida = false, hayBingoValido = false;

        
        //----------------------------------------------
        //          Entrada de datos
        //----------------------------------------------
        
        System.out.println("Introduce el nombre del/la primer/a jugador/a: ");
        nombreJugador1 = teclado.nextLine();
        
        System.out.println("\nIntroduce el nombre del/la segundo/a jugador/a: ");
        nombreJugador2 = teclado.nextLine();
        
        
        
        //----------------------------------------------
        //     Procesamiento + Salida de resultados
        //----------------------------------------------
        
        // 2. Creación de los cartones para los jugadores
        
        System.out.println("\nCreando el cartón de "+ nombreJugador1 + " con " + NUMEROS_CARTON + " números para el sorteo de hoy...");
        cartonJugador1 = new CartonBingo(NUMEROS_CARTON, nombreJugador1, HOY);
        System.out.println(cartonJugador1);
        
        System.out.println("\nCreando el cartón de "+ nombreJugador2 + " con " + NUMEROS_CARTON + " números para el sorteo de hoy...");
        cartonJugador2 = new CartonBingo(NUMEROS_CARTON, nombreJugador2, HOY);
        System.out.println(cartonJugador2);
        
        
        // 3. Creación del bombo para el sorteo de hoy
        
        System.out.println("\nCreando el bombo para el sorteo de hoy...");
        Bombo bombo = new Bombo(HOY);
        
        // 4. Comienza el juego. Jugamos para "Línea"
        
        System.out.println("Comienza el juego, jugamos para \"Línea\"...\n\n");
        
        do {
            
            bolaBombo = bombo.sacarBola();
            System.out.println( bombo.cantarNumero(bolaBombo) );
            
            cartonJugador1.marcarNumero(bolaBombo);
            cartonJugador2.marcarNumero(bolaBombo);
            
            if(cartonJugador1.cantarLinea() && hayLineaValida == false)
            {
                System.out.println("\n***** " + cartonJugador1.getPropietario() +": LINEEEEAAA! *****\n" );
                System.out.println("Verificamos la línea cantada por " + cartonJugador1.getPropietario() +"...");
                
                hayLineaValida = bombo.verificarLinea(cartonJugador1);
                
                if(hayLineaValida) {
                    System.out.println(cartonJugador1);
                    System.out.println("La línea cantada por " + cartonJugador1.getPropietario() + " es VÁLIDA\n");
                }
                else               System.out.println("La línea cantada por " + cartonJugador1.getPropietario() + " NO es VÁLIDA");
            }
            if(cartonJugador2.cantarLinea() && hayLineaValida == false)
            {
                System.out.println("\n***** " + cartonJugador2.getPropietario() +": LINEEEEAAA! *****\n" );
                System.out.println("Verificamos la línea cantada por " + cartonJugador2.getPropietario() +"...");
                
                hayLineaValida = bombo.verificarLinea(cartonJugador2);
                
                if(hayLineaValida) {
                    System.out.println(cartonJugador2);
                    System.out.println("La línea cantada por " + cartonJugador2.getPropietario() + " es VÁLIDA\n");
                }
                else               System.out.println("La línea cantada por " + cartonJugador2.getPropietario() + " NO es VÁLIDA\n");
            }
            
        } while(!hayLineaValida);

        System.out.println("\n\nSeguimos para \"Bingo\"...");
        
        do {            
            bolaBombo = bombo.sacarBola();
            System.out.println( bombo.cantarNumero(bolaBombo) );
            
            cartonJugador1.marcarNumero(bolaBombo);
            cartonJugador2.marcarNumero(bolaBombo);
            
            if(cartonJugador1.cantarBingo() && hayBingoValido == false)
            {
                System.out.println("\n***** " + cartonJugador1.getPropietario() +": BIIIINGOOO! *****\n" );
                System.out.println("Verificamos el bingo cantado por " + cartonJugador1.getPropietario() +"...");
                
                hayBingoValido = bombo.verificarBingo(cartonJugador1);
                
                if(hayBingoValido) {
                    System.out.println(cartonJugador1);
                    System.out.println("El bingo cantado por " + cartonJugador1.getPropietario() + " es VÁLIDO");
                    System.out.println(cartonJugador1.getPropietario() +  " ha GANADO el juego!!\n");
                }
                else               System.out.println("El bingo cantado por " + cartonJugador1.getPropietario() + " NO es VÁLIDO");
            }
            
            if(cartonJugador2.cantarBingo() && hayBingoValido == false)
            {
                System.out.println("\n***** " + cartonJugador2.getPropietario() +": BIIIINGOOO! *****\n" );
                
                System.out.println("Verificamos el bingo cantado por " + cartonJugador2.getPropietario() +"...");
                
                hayBingoValido = bombo.verificarBingo(cartonJugador2);
                
                if(hayBingoValido) {
                    System.out.println(cartonJugador2);
                    System.out.println("El bingo cantado por " + cartonJugador2.getPropietario() + " es VÁLIDO");
                    System.out.println(cartonJugador2.getPropietario() +  " ha GANADO el juego!!\n");
                }
                else  System.out.println("La bingo cantado por " + cartonJugador2.getPropietario() + " NO es VÁLIDA");
            }
            
            
        } while(!hayBingoValido);

        System.out.println(bombo);
    }
}
