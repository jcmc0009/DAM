package tarea03;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Ejercicio 3: Vamos al cine.
 * En este ejercicio trabajaremos con objetos de tipo fecha y de tipo hora a través de las clases LocalDate y LocalTime respectivamente.
 * @author Fran Jiménez
 */
public class Ejercicio3 {

    public static void main(String[] args) {
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        final int HORA_PRIMERA = 17;
        final int MINUTOS_PRIMERA = 0;
        final LocalTime primeraSesion;
        final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("d/M/yyyy");
        final double PRECIO_BASE = 4.50; // precio base de las sesiones
        final int SUPLEMENTO_ULTIMA_SESION = 1; // la última sesión tiene un incremento de 1€ por alta demanda
        final double DESCUENTO_DIAS_ESPECTADOR = 0.50; // descuento del 50% en los días del espectador
        final int DURACION_SESION = 150; // 2 horas 30 minutos, son 150 minutos
                    

        // Variables de entrada
        String fechaTeclado;
        int hora=0, minuto=0;

        // Variables de salida
        String mensajeFinal ="";
        double precioFinalEntrada;
        

        // Variables auxiliares
        LocalDate fechaReserva;
        LocalTime horaLeida;
        boolean errorEntrada;
        boolean fechaCorrecta = false;
        boolean esDiaEspectador = false;
        boolean haySesion = true; // hay sesión para la hora que indica el usuario

        // Objeto Scanner para lectura desde teclado
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("\nEjercicio 3. ¡Vamos al cine!");
        System.out.println("----------------------------");

//*
        // 1. Lectura por teclado de la fecha para la que se quiere reservar (mínimo con una semana de antelación)

        System.out.println("Introduce la fecha para la que quieres comprar la entrada");
        System.out.println("---------------------------------------------------------");
        
        // 1.1. Lectura por teclado de la fecha para la que se quiere reservar (mínimo con una semana de antelación)
        do {
            System.out.print("- Fecha (ej. 06/04/2023): ");
            fechaTeclado = teclado.nextLine();

            // 1.2. Se intenta crear un objeto LocalDate para la fecha anterior
            
            try {
                fechaReserva = LocalDate.parse(fechaTeclado, FORMATO_FECHA);
                if(fechaReserva.isAfter(LocalDate.now().plusDays(7))) {
                    fechaCorrecta = true;
                    if(fechaReserva.getDayOfWeek() == DayOfWeek.MONDAY || fechaReserva.getDayOfWeek() == DayOfWeek.THURSDAY ){
                        esDiaEspectador = true;
                    }
                }
                else {
                    System.err.println("¡ERROR! No se permiten reservas con menos de una semana de antelación\n");
                }
                
            } catch (DateTimeParseException e) {
                System.err.println("¡ERROR! La fecha introducida NO es válida (utiliza el formato sugerido)\n");
            }
        } while (!fechaCorrecta); // 1.3. Si la fecha no es correcta o no tiene antelación suficiente se vuelven a pedir los datos
        
        
        // 2. Lectura por teclado y comprobación de hora y minuto

        System.out.println("\nIntroduce la hora para la que quieres comprar la entrada");
        System.out.println("--------------------------------------------------------");
   
        // 2.1. Leer y comprobar la hora (debe estar entre 0 y 23)
        do {
            System.out.print("- Hora (00-23): ");
            try {
                hora = teclado.nextInt();
                errorEntrada = (hora < 0 || hora > 23);
                if(errorEntrada)  System.err.println("¡ERROR! Hora fuera del rango 0-23");
            } catch (InputMismatchException ex) {
                System.err.println("¡ERROR! No se ha introducido un número válido");
                errorEntrada = true;
                teclado.nextLine(); // "Purgamos" lo que haya en el teclado, que es incorrecto
            }
        } while (errorEntrada);

        
        // 2.2.  Leer y comprobar el minuto (debe estar entre 0 y 59)
        do {
            System.out.print("- Minuto (00-59): ");
            try {
                minuto = teclado.nextInt();
                errorEntrada = (minuto < 0 || minuto > 59);
                if(errorEntrada)  System.err.println("¡ERROR! Minuto fuera del rango 0-59");
            } catch (InputMismatchException ex) {
                System.err.println("¡ERROR! No se ha introducido un número válido");
                errorEntrada = true;
                teclado.nextLine(); // "Purgamos" lo que haya en el teclado, que es incorrecto
            }
        } while (errorEntrada);

        //*/


        // 3. Creación de los objetos LocalTime de referencia:
        
        // 3.1. Creación de un objeto LocalTime de referencia para almacenar la hora de la primera sesión de cine (17:00)
        primeraSesion = LocalTime.of(HORA_PRIMERA, MINUTOS_PRIMERA);
        
        // 3.2 Creación de objeto LocalTime con la hora indicada a partir de los datos (hora y minuto) leídos por teclado
        horaLeida = LocalTime.of(hora, minuto);

        //----------------------------------------------
        //               Procesamiento 
        //----------------------------------------------
        
        // 4. Obtener la siguiente sesión (y su precio) a la que el usuario puede entrar según la hora que ha indicado
        
        // 4.1. Obtener la siguiente sesión (y su precio) a la que el usuario puede entrar según la hora que ha indicado
        if (horaLeida.isBefore(primeraSesion.plusMinutes(1))) { // Antes de la primera sesión
            mensajeFinal += String.format ("\nA la hora indicada faltarían %s minutos para el inicio de la primera sesión", horaLeida.until(primeraSesion, ChronoUnit.MINUTES));
            precioFinalEntrada = PRECIO_BASE * ((esDiaEspectador)? DESCUENTO_DIAS_ESPECTADOR: 1);
            mensajeFinal += String.format ("\nEl precio de una entrada para esta sesión es de %.2f€", precioFinalEntrada);
            
        } 
        else if (horaLeida.isBefore(primeraSesion.plusMinutes(1+DURACION_SESION))) { // entre la primera y la segunda sesión (antes de las 19:30)
            mensajeFinal += String.format ("\nA la hora indicada faltarían %s minutos para el inicio de la sesión de las 19:30", horaLeida.until(primeraSesion.plusMinutes(DURACION_SESION), ChronoUnit.MINUTES));
            precioFinalEntrada = PRECIO_BASE * ((esDiaEspectador)? DESCUENTO_DIAS_ESPECTADOR: 1);
            mensajeFinal += String.format ("\nEl precio de una entrada para esta sesión es de %.2f€", precioFinalEntrada);
            
        } else if (horaLeida.isBefore(primeraSesion.plusMinutes(1+DURACION_SESION*2) )) { // entre la segunda y la última sesión (antes de las 22:00)
            mensajeFinal += String.format ("\nA la hora indicada faltarían %s minutos para el inicio de la sesión de las 22:00", horaLeida.until(primeraSesion.plusMinutes(DURACION_SESION*2), ChronoUnit.MINUTES));
            precioFinalEntrada = (PRECIO_BASE+SUPLEMENTO_ULTIMA_SESION) * ((esDiaEspectador)? DESCUENTO_DIAS_ESPECTADOR: 1);
            mensajeFinal += String.format ("\nEl precio de una entrada para esta sesión es de %.2f€", precioFinalEntrada);
            
        } else {  // Después que haya comenzado la última sesión
            mensajeFinal = String.format ("\nLa última sesión de este día comienza %s minutos ANTES de la hora indicada", primeraSesion.plusMinutes(DURACION_SESION*2).until(horaLeida, ChronoUnit.MINUTES));
            mensajeFinal += String.format ("\nNo hay más sesiones después de esta");
            haySesion = false;
        }
        
        mensajeFinal += ((esDiaEspectador && haySesion)? "\nNota: se aplica un descuento del " + DESCUENTO_DIAS_ESPECTADOR*100 + "% por ser Día del Espectador": "");

        //----------------------------------------------
        //            Salida de resultados 
        //----------------------------------------------
        // 5. Mostrar por pantalla los resultados obtenidos según el procesamiento realizado.
        System.out.println(mensajeFinal);
    }
}
