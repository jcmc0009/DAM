package tarea03;

import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;

/**
 * Ejercicio 1: Creación y uso de cartones de bingo. <br>
 * En este ejercicio probamos el funcionamiento de la clase CartonBingo tratando de conocer los métodos que tiene y el funcionamiento de cada uno de ellos
 *
 * @author Fran Jiménez
 */
public class Ejercicio1 {

    public static void main(String[] args) {

        // 1. Presentación del ejercicio
        System.out.println("Ejercicio 1. Creación y uso de cartones de bingo");
        System.out.println("------------------------------------------------");
        /* 
            Debes mostrar la fecha ACTUAL (hoy) usando la API de LocalDate
            (usa también DateTimeFormatter para formatear la fechala correctamente (ej. 08/11/2022)
         */
        System.out.printf("Fecha ACTUAL de ejecución: %s\n", LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        System.out.println();

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        final int NUMEROS_NO_VALIDOS = 30;  // ejemplo de cantidad no válida de números en un cartón

        // 2.- Declaración de tres variables referencia a objetos instancia de la clase CartonBingo
        CartonBingo cartonMaria, cartonAda, cartonJuan;

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        /* 
            En este ejercicio no habrá entrada de datos como tal ya que los datos que se piden en el enunciado son fijos, 
            y son introducidos por el/la programador/a (no hay que pedir datos por teclado al usuario de la aplicación).
         */
        // 3.- Instanciación de objetos de la clase CartonBingo
        System.out.println("Creación de los cartones para cada uno de los personajes (uso de constructores)");
        System.out.println("-------------------------------------------------------------------------------");

        // 3.1.- Comprobación del lanzamiento de excepciones (se intentan crear cartones no válidos)
        // 3.1.1.- Intento de creación de un cartón de bingo con fecha de sorteo de la semana pasada (hay gestionar la posible excepción)
        try {
            LocalDate fechaNoValida = LocalDate.now().minusWeeks(1);
            System.out.println("Intentando crear un cartón para el sorteo celebrado hace una semana (" + fechaNoValida.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + ").");
            cartonMaria = new CartonBingo(fechaNoValida);
        } catch (IllegalStateException e) {
            System.out.println(e.getMessage());
        }

        // 3.1.2.- Intento de creación de un cartón de bingo con una cantidad de números no válida (30 números)
        try {
            System.out.println("\nIntentando crear un cartón con 30 números (cantidad no válida)");
            cartonMaria = new CartonBingo(NUMEROS_NO_VALIDOS, "Desconocido", LocalDate.now());
        } catch (IllegalStateException e) {
            System.out.println(e.getMessage());
        }

        // 3.2 Creación de cartones válidos
        System.out.println("\nCreamos ahora cartones válidos para nuestros tres jugadores...");

        // 3.2.1.- Creación de un cartón válido para María siguiendo las especificaciones del enunciado
        System.out.println("\nCreando un cartón de 18 números y fecha de sorteo del 5 de Marzo de 2023 para María:");
        cartonMaria = new CartonBingo(18, "María", LocalDate.of(2023, Month.MARCH, 5));

        // 3.2.2.- Creación de un cartón válido para Ada siguiendo las especificaciones del enunciado
        System.out.println("\nCreando un cartón para Ada, sin indicar nada más:");
        cartonAda = new CartonBingo("Ada");

        // 3.2.3.- Creación de un cartón válido para Juan siguiendo las especificaciones del enunciado
        System.out.println("\nCreando un cartón para Juan, utilizando los valores por defecto:");
        cartonJuan = new CartonBingo();

        //----------------------------------------------
        //       Procesamiento + Salida de Resultados
        //----------------------------------------------
        /* 
            Dado que se va a ir mostrando información de salida a la vez que se van realizando operaciones, podemos considerar en este caso
            que el procesamiento y la salida de resultado van unidos y "mezclados" 
         */
        // 4.- Obtención de información de los cartones creados
        System.out.printf("\n\nObtención de información de los cartones creados\n");
        System.out.printf("------------------------------------------------\n");
        System.out.printf("Total de cartones que se han creado:  %d\n", CartonBingo.getTotalCartones());
        System.out.printf("Identificador del cartón de María:  %s\n", cartonMaria.getIdCarton());
        System.out.printf("Cantidad de números que tiene el cartón de Ada:  %s números\n", cartonAda.getTotalNumerosCarton());
        System.out.printf("Fecha de sorteo del cartón de Juan (%s) y del cartón de María (%s)\n", cartonJuan.getFechaSorteo(), cartonMaria.getFechaSorteo());
        System.out.printf("Lista de números del cartón de Ada:  %s\n", cartonAda.listadoNumerosPendientes());
        System.out.printf("Número de días que faltan hasta el sorteo en el que participa María:  %d\n", cartonMaria.diasHastaSorteo());
        System.out.printf("Cartones participan en el sorteo de hoy:  %d\n", CartonBingo.totalCartonesSorteo(LocalDate.now()));
        System.out.println();

        // 5.- Realización de algunas operaciones con los cartones creados
        // 5.1.- Marcar los números del 10 al 25 en los tres cartones
        System.out.println("Realización de algunas operaciones con los cartones creados");
        System.out.println("-----------------------------------------------------------");
        System.out.println("Marcamos los números desde el 10 hasta el número 25 ambos incluidos en los tres cartones...");

        for (int i = 20; i <= 35; i++) {
            cartonMaria.marcarNumero(i);  /// marcamos los números en el cartón de María (si están)
            cartonAda.marcarNumero(i);    /// marcamos los números en el cartón de Ada (si están)
            cartonJuan.marcarNumero(i);   /// marcamos los números en el cartón de Juan (si están)
        }

        // 5.2.- Mostrar los números que han podido marcar correctamente en cada uno de los cartones
        System.out.println("De los números anteriores, mostramos la lista de números que sí se han podido marcar en cada uno de los tres cartones ...");
        System.out.printf("- En el cartón de María estaban los números: %s\n", cartonMaria.listadoNumerosMarcados());
        System.out.printf("- En el cartón de Ada estaban los números: %s\n", cartonAda.listadoNumerosMarcados());
        System.out.printf("- En el cartón de Juan estaban los números: %s\n", cartonJuan.listadoNumerosMarcados());

        // 5.3.- Indica de los tres cartones, a cuál de ellos le quedan menos números
        System.out.print("\nAl jugador/a que le quedan menos números pendientes de marcar en su cartón es... ");

        if (cartonMaria.getCantidadNumerosPendientes() < cartonAda.getCantidadNumerosPendientes()) {
            if (cartonMaria.getCantidadNumerosPendientes() < cartonJuan.getCantidadNumerosPendientes()) {
                System.out.println("María, que le quedan " + cartonMaria.getCantidadNumerosPendientes() + " números por marcar");
            } else {
                System.out.println("Juan, que le quedan " + cartonJuan.getCantidadNumerosPendientes() + " números por marcar");
            }
        } else {
            if (cartonAda.getCantidadNumerosPendientes() < cartonJuan.getCantidadNumerosPendientes()) {
                System.out.println("Ada, que le quedan " + cartonAda.getCantidadNumerosPendientes() + " números por marcar");
            } else {
                System.out.println("Juan, que le quedan " + cartonJuan.getCantidadNumerosPendientes() + " números por marcar");
            }
        }

        // 6.- Muestra el estado final de los cartones
        System.out.println("\nEstado final de todos los cartones");
        System.out.println("------------------------------------");
        System.out.println(cartonMaria);
        System.out.println(cartonAda);
        System.out.println(cartonJuan);
        System.out.println();
        System.out.println("El programa ha finalizado!!");
        System.out.println();

    }
}
