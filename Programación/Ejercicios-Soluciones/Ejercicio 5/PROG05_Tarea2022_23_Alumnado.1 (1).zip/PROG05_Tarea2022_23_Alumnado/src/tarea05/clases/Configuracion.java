package tarea05.clases;

/**
 * Clase que nos servirá para la configuración del sistema
 * @author Profe
 */
public class Configuracion {
    
    //Precios según tamaños.
    final static float BASE_PEQUENHA = 5f;
    final static float BASE_MEDIANA = 9f;
    final static float BASE_GRANDE = 13f;
    
    //Precios según el tipo de pizza.
    final static float PIZZA_MARGARITA = 1f;
    final static float PIZZA_CARBONARA = 4f;
    final static float PIZZA_BARBACOA = 6f;
    final static float PIZZA_4ESTACIONES = 5f;
  
}
