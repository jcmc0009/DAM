package tarea05.clases;

import utilidades.ES;

/**
 *
 * @author profe
 */
public class GestorPedidos {

    //----------------------------------------------
    //          Declaración de variables 
    //----------------------------------------------
    //Constantes
    private final int INTRODUCIR_PIZZA = 1;
    private final int MOSTRAR_PEDIDO = 2;
    private final int FINALIZAR_PEDIDO = 3;
    private final int SALIR = 4;
    
    public GestorPedidos() {
        //Por hacer
    }

    public void gestionarPedidos() {//Método que mostrará el menú de la aplicación y que lanzará los diferentes métodos internos en función de lo se pida
        //Variables        
        boolean terminar = false;

        // Variables de entrada
        int opcionElegida = 0;

        //----------------------------------------------
        //               Procesamiento 
        //----------------------------------------------
        do {
            ES.msgln("\nMenú Pedido Pizza");
            ES.msgln("-------------------------");
            ES.msgln(INTRODUCIR_PIZZA + ".- Introducir pizza en el pedido.");
            ES.msgln(MOSTRAR_PEDIDO + ".- Ver estado del pedido.");
            ES.msgln(FINALIZAR_PEDIDO + ".- Finalizar Pedido.");
            ES.msgln(SALIR + ".- Apagar aplicación.");
            opcionElegida = ES.leeEntero("elija una opción:", 1, 4); //Leeremos un número entero entre 1 y 4.

            switch (opcionElegida) {

                case INTRODUCIR_PIZZA: //Crearemos una pizza y la guardaremos.
                    // Llamar al método nsertarPizzaEnPedido
                break;

                case MOSTRAR_PEDIDO: //Mostraremos las pizzas del pedido.
                    //Llamar al método mostrarPedido         
                    break;

                case FINALIZAR_PEDIDO: // Mostraremos las pizzas del pedido, el coste y prepararemos la aplicación para un nuevo pedido.
                    //Llamar al método finalizaPedido
                    break;

                case SALIR:
                    terminar = true;
                    break;
            }

        } while (!terminar);
        ES.msg("Finalizando aplicación...\n");
    }

    //Crear todos el resto de métodos de la clase.
}
