INSERT INTO ACTIVIDAD VALUES
(1, 'Carrera', 30, 3.5),
(2, 'Natación', 45, 1.2),
(3, 'Ciclismo', 60, 12.3),
(4, 'Fuerza', 50, 0.0);

INSERT INTO USUARIO VALUES
(1, 'Juan'),
(2, 'María'); 

INSERT INTO ENTRENAMIENTO VALUES
(1, 1, 1, '2023-05-08'),
(2, 1, 2, '2023-04-10'),
(3, 2, 3, '2023-03-01');
