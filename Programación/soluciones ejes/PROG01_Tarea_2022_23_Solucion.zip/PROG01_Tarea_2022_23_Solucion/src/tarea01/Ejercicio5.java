package tarea01;

import java.util.Scanner;

/**
 * Ejercicio 5: venta de pienso para animales
 * @author Profesorado
 */
public class Ejercicio5 {

    public static void main(String[] args) {
    
    //----------------------------------------------
    //    Declaración de variables y constantes
    //----------------------------------------------
        
        // Variables de entrada (aquí se definen las variables que recibirán valores, si fueran necesarias)
        int numeroSacos;
        
        // Constantes (aquí se definen los datos que tienen siempre un valor fijo)
        final int MINIMO_SACOS_DESCUENTO1 = 5;     // para aplicar el primer descuento, el mínimo son 5 sacos
        final float DESCUENTO1 = 5.5f/100;         // el descuento1 es del 5.5%, que es lo mismo que 5.5/100 
        final int MINIMO_SACOS_DESCUENTO2 = 8;     // para aplicar el primer descuento, el mínimo son 8 sacos
        final float DESCUENTO2 = 10.3f/100;        // el descuento2 es del 10.3%, que es lo mismo que 10.3/100
        final float PRECIO_SACO = 9.75f;           // precio unitario de cada uno de los sacos
        final float PORCENTAJE_IVA = 10/100f;      // el IVA es del 10% que es lo mismo que 10/100
        
        // Nota: se han definido las constantes como float, pero podrían ser double también
        
        // Variables auxiliares (aquí se definen las variables necesarias para realizar cálculos intermedios, si fueran necesarias)
        double importeTotalSinIVA, importeTotalIncluidoIVA;
        float descuentoAplicar;
        
        // Variables de salida (aquí se definen las variables que almacenarán resultados y se mostrarán al usuario, si fueran necesarias)
        int cantidadPagar;        
        
        // Clase Scanner para petición de datos al usuario a través del teclado
        Scanner teclado= new Scanner (System.in);
        
    //----------------------------------------------
    //               Entrada de datos 
    //----------------------------------------------
        System.out.println("Ejercicio 5. Venta de pienso para animales");
        System.out.println("------------------------------------------");
        
        System.out.print("Introduce el número de sacos que quiere comprar el cliente: ");   // mostramos un mensaje sobre la información que vamos a pedir por teclado
        numeroSacos = teclado.nextInt();                                                    // a través del Scanner pedimos al usuario el número de sacos a comprar
        

    //----------------------------------------------
    //                 Procesamiento 
    //----------------------------------------------

        /* 
            se utiliza un operador ternario para saber qué descuento aplicar (es una condicional ternaria anidada dentro de otra condicional ternaria):
            · Si el número de sacos es mayor que el mínimo para el DESCUENTO2 (8 sacos) se aplica el DESCUENTO2
            · Si no, si el número de sacos es mayor que el mínimo para el DESCUENTO1 (5 sacos) el descuento será DESCUENTO1
            · Si no se cumple ninguna de las anteriores (menos de 8 sacos y menos de 5 sacos) no se aplica descuento (0) 
        */
        descuentoAplicar = (numeroSacos>MINIMO_SACOS_DESCUENTO2)? DESCUENTO2 :  (numeroSacos>MINIMO_SACOS_DESCUENTO1)? DESCUENTO1 : 0;
        
        // se calcula el importe teniendo en cuenta el descuento conseguido
        importeTotalSinIVA = numeroSacos*PRECIO_SACO*(1-descuentoAplicar);

        // se calcula el importe total considerando el IVA 
        importeTotalIncluidoIVA = importeTotalSinIVA * (1+PORCENTAJE_IVA);
        
        // para obtener la cantidad a pagar sin decimales se puede hacer un casteo a entero
        cantidadPagar = (int)importeTotalIncluidoIVA;
        
        
    //----------------------------------------------
    //              Salida de resultados 
    //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("----------");        
        System.out.println("El cliente va a comprar " + numeroSacos + " sacos");   // se muestra la cantidad de sacos que se comprarán
        System.out.println("Se aplica un descuento del "+ descuentoAplicar*100 + "%");   // se muestra el descuento que se aplicará
        System.out.printf("El importe aplicando el descuento (sin IVA) es de %.2f€\n", importeTotalSinIVA );   // se muestra el descuento que se aplicará usando dos decimales únicamente
        System.out.printf("El importe total (IVA incl.) asciende a: %.2f€\n", importeTotalIncluidoIVA);   // se muestra el importe total usando dos decimales únicamente
        System.out.println("El importe final a pagar (IVA incl.) asciende a: " + cantidadPagar + "€");   // se muestra la cantidad a pagar
        System.out.println ();
        System.out.println ("Fin del programa.");           
    }
}
