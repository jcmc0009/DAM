package tarea01;

import java.util.Scanner;

/**
 * Ejercicio 1: cálculo del área de un trapecio.
 * @author Profesorado
 */
public class Ejercicio1 {

    public static void main(String[] args) {
    
    //----------------------------------------------
    //    Declaración de variables y constantes
    //----------------------------------------------
        
        // Variables de entrada (aquí se definen las variables que recibirán valores, si fueran necesarias)
        double baseMayor, baseMenor, altura;
        
        // Variables de salida (aquí se definen las variables que almacenarán resultados y se mostrarán al usuario, si fueran necesarias)
        double areaTrapecio;
        
        // Clase Scanner para petición de datos al usuario a través del teclado
        Scanner teclado= new Scanner (System.in);
        
    //----------------------------------------------
    //               Entrada de datos 
    //----------------------------------------------
        System.out.println("Ejercicio 1. Cálculo del área de un trapecio regular");
        System.out.println("----------------------------------------------------");
        
        System.out.print("Introduce la base mayor del trapecio: ");   // mostramos un mensaje sobre la información que vamos a pedir por teclado
        baseMayor = teclado.nextDouble();                             // a través del Scanner pedimos al usuario que introduzca un número real para la base mayor
        
        /* hacemos igual para el resto de valores de la fórmula */
        System.out.print("Introduce la base menor del trapecio: ");   
        baseMenor = teclado.nextDouble();                             
        
        System.out.print("Introduce la altura del trapecio: ");       
        altura = teclado.nextDouble();                                

    //----------------------------------------------
    //                 Procesamiento 
    //----------------------------------------------
        areaTrapecio = ((baseMayor + baseMenor)/2)*altura; // se calcula el área utilizando la fórmula que nos proporcionan
        
    //----------------------------------------------
    //              Salida de resultados 
    //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");        
        // se muestran los resultados
        System.out.println("El área del trapecio base menor " + baseMenor + ", base mayor " + baseMayor + " y altura " + altura + " es " + areaTrapecio); 
        System.out.println ();
        System.out.println ("Fin del programa.");           
    }
}
