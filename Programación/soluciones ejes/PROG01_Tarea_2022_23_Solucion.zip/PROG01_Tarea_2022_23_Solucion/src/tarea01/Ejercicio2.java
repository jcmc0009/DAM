package tarea01;

import java.util.Scanner;

/**
 * Ejercicio 2: operadores aritméticos
 * @author Profesorado
 */
public class Ejercicio2 {

    public static void main(String[] args) {
    
    //----------------------------------------------
    //    Declaración de variables y constantes
    //----------------------------------------------
        
        // Variables de entrada (aquí se definen las variables que recibirán valores, si fueran necesarias)
        int numero1, numero2, numero3;
        
        // Variables de salida (aquí se definen las variables que almacenarán resultados y se mostrarán al usuario, si fueran necesarias)
        boolean sumaPar, restoDistinto0, multiplicacionMayor, menorQue0;
        double division;
        
        // Clase Scanner para petición de datos al usuario a través del teclado
        Scanner teclado= new Scanner (System.in);
        
    //----------------------------------------------
    //               Entrada de datos 
    //----------------------------------------------
        System.out.println("Ejercicio 2. Operadores aritméticos");
        System.out.println("-----------------------------------");
        
        System.out.print("Introduce el primer número: ");   // mostramos un mensaje sobre la información que vamos a pedir por teclado
        numero1 = teclado.nextInt();                        // a través del Scanner pedimos al usuario que introduzca un número int
        
        /* hacemos igual para el resto de números */
        System.out.print("Introduce el segundo número: ");  
        numero2 = teclado.nextInt();                        
        
        System.out.print("Introduce el tercer número: ");   
        numero3 = teclado.nextInt();                        
        

    //----------------------------------------------
    //                 Procesamiento 
    //----------------------------------------------
        division = ((numero1+numero2)/(double)numero3);  // hallar la suma de dos primeros números dividida por el tercer número
        sumaPar = (numero1+numero2+numero3)%2 == 0; // ver si la suma de los tres números es par
        restoDistinto0 = (numero1%numero2) != 0; // ver si resto del primer número dividido por el segundo número es distinto de 0
        multiplicacionMayor = (numero1*numero2/2) > numero3; // ver si la multiplicación del primer número por la mitad del segundo número es mayor que el tercer número
        menorQue0 = (numero1*numero1 - 3*(numero2*numero3)) < 0; /* ver si el resultado del cuadrado del primer número menos el triple del segundo número 
                                                                    por el tercer número es menor que 0 */
       
    //----------------------------------------------
    //              Salida de resultados 
    //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADOS");
        System.out.println("----------");        
        // se muestra los resultados obtenidos
        System.out.println("Comprobamos el valor de la suma de dos primeros números dividida por el tercer número: " + division); 
        System.out.println("Comprobamos si la suma de los tres números es par: " + sumaPar); 
        System.out.println("Comprobamos si el resto del primer número dividido por el segundo número es distinto de 0: " + restoDistinto0); 
        System.out.println("Comprobamos si la multiplicación del primer número por la mitad del segundo número es mayor que el tercer número: " + multiplicacionMayor); 
        System.out.println("Comprobamos si el resultado del cuadrado del primer número menos el triple del segundo número por el tercer número es menor que 0: " + menorQue0); 
        System.out.println ();
        System.out.println ("Fin del programa.");           
    }
}
