package tarea01;

import java.util.Scanner;

/**
 * Ejercicio 4: horas, minutos y segundos
 * @author Profesorado
 */
public class Ejercicio4 {

    public static void main(String[] args) {
    
    //----------------------------------------------
    //    Declaración de variables y constantes
    //----------------------------------------------
        
        // Variables de entrada (aquí se definen las variables que recibirán valores, si fueran necesarias)
        int totalSegundos, horasTeclado, minutosTeclado, segundosTeclado, totalSegundosTeclado;
        
        // Constantes (aquí se definen los datos que tienen siempre un valor fijo)
        final int SEGUNDOS_HORA = 3600;
        final int SEGUNDOS_MINUTO = 60;
        
        // Variables auxiliares (aquí se definen las variables necesarias para realizar cálculos intermedios, si fueran necesarias)
        int sumaTotal; /// total de segundos tras hacer la suma de todas las cantidades en segundos
        int horasFinal, minutosFinal, segundosFinal; // valores enteros para los resultados antes de mostrarlos en la cadena resultado
        
        // Variables de salida (aquí se definen las variables que almacenarán resultados y se mostrarán al usuario, si fueran necesarias)
        String resultado;
        
        // Clase Scanner para petición de datos al usuario a través del teclado
        Scanner teclado= new Scanner (System.in);
        
    //----------------------------------------------
    //               Entrada de datos 
    //----------------------------------------------
        System.out.println("Ejercicio 4. Horas, minutos y segundos");
        System.out.println("--------------------------------------");
        
        System.out.print("Introduce el total de segundos: ");   // mostramos un mensaje sobre la información que vamos a pedir por teclado
        totalSegundos = teclado.nextInt();                      // a través del Scanner pedimos al usuario el total de segundos
        
        System.out.print("Introduce el número de horas: ");    // mostramos un mensaje sobre la información que vamos a pedir por teclado
        horasTeclado = teclado.nextInt();                      // a través del Scanner pedimos al usuario el número de horas
        
        System.out.print("Introduce el número de minutos: ");   // mostramos un mensaje sobre la información que vamos a pedir por teclado
        minutosTeclado = teclado.nextInt();                     // a través del Scanner pedimos al usuario el número de minutos
        
        System.out.print("Introduce el número de segundos: ");   // mostramos un mensaje sobre la información que vamos a pedir por teclado
        segundosTeclado = teclado.nextInt();                     // a través del Scanner pedimos al usuario el número de minutos
        

    //----------------------------------------------
    //                 Procesamiento 
    //----------------------------------------------
        
        // hacemos la conversión a segundos de la cantidad de tiempo introducida como horas, minutos y segundos
        totalSegundosTeclado = horasTeclado * SEGUNDOS_HORA + minutosTeclado * SEGUNDOS_MINUTO + segundosTeclado;
        sumaTotal = totalSegundos + totalSegundosTeclado;  /*  hacemos la suma de ambas cantidades (en segundos)
                                                               totalSegundos es la primera cantidad introducida (en segundos) por el usuario
                                                               totalSegundosTeclado es la cantidad en segundos introducida mediante horas, minutos y segundos
                                                           */
        
        horasFinal = sumaTotal / SEGUNDOS_HORA;  /* al dividir (/) la suma total por los segundos que tiene una hora nos quedamos con el número de 
                                                    horas completas que tenemos en la cantidad de segundos total (no hay que castear porque son datos int) */
        
        minutosFinal = (sumaTotal % SEGUNDOS_HORA)/SEGUNDOS_MINUTO; /* si hacemos módulo (%) de la suma total entre los segundos que hay en una hora nos 
                                                                        quedarán  los segundos que sobraron de una hora que no se pudo completar (no había 
                                                                        segundos para conseguir sumar otra hora más). Al dividir (/) por los segundos de un 
                                                                        minuto  nos da los minutos completos */
                                    
        segundosFinal = (sumaTotal % SEGUNDOS_HORA)%SEGUNDOS_MINUTO; /* del mismo modo, si calculamos los segundos restantes de una hora y calculamos de 
                                                                        esa cantidad cuantos segundos nos sobran al aplicar el módulo de minutos, el resto
                                                                        sobrante será la cantidad de segundos que no pudieron llegar a ser un nuevo minuto */
        
        // almacenamos en una variable de salida el resultado (se puede hacer también directamente en el println al final)
        resultado = "Las cantidades introducidas suman un total de " + horasFinal + " horas, " + minutosFinal + " minutos y " + segundosFinal + " segundos.";
        
    //----------------------------------------------
    //              Salida de resultados 
    //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("----------");        
        System.out.println(resultado); // se muestra el resultado
        System.out.println ();
        System.out.println ("Fin del programa.");           
    }
}
