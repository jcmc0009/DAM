package tarea01;

import java.util.Scanner;

/**
 * Ejercicio 3: recluido en casa
 * @author Profesorado
 */
public class Ejercicio3 {

    public static void main(String[] args) {
    
    //----------------------------------------------
    //    Declaración de variables y constantes
    //----------------------------------------------
        
        // Variables de entrada (aquí se definen las variables que recibirán valores, si fueran necesarias)
        boolean lloviendo, tarea, supermercado;
        
        // Variables de salida (aquí se definen las variables que almacenarán resultados y se mostrarán al usuario, si fueran necesarias)
        boolean salirCalle;
        
        // Clase Scanner para petición de datos al usuario a través del teclado
        Scanner teclado= new Scanner (System.in);
        
    //----------------------------------------------
    //               Entrada de datos 
    //----------------------------------------------
        System.out.println("Ejercicio 3. Recluido en casa");
        System.out.println("-----------------------------");
        
        System.out.print("Indica si está lloviendo (true/false): ");   // mostramos un mensaje sobre la información que vamos a pedir por teclado
        lloviendo = teclado.nextBoolean();                             // a través del Scanner pedimos al usuario que introduzca un valor booleano
        
        // igual para el resto de condiciones que tenemos que cumplir
        System.out.print("Indica si has terminado la tarea online de Programación (true/false): ");  
        tarea = teclado.nextBoolean();                                 
        
        System.out.print("Indica si tienes que ir al supermercado (true/false): ");   
        supermercado = teclado.nextBoolean();                             
        

    //----------------------------------------------
    //                 Procesamiento 
    //----------------------------------------------
        /* se podrá salir a la calle (true) si NO llueve y he terminado la tarea 
           o siempre que tenga que salir al supermercado */
        salirCalle = (!lloviendo && tarea) || supermercado;
        
        
    //----------------------------------------------
    //              Salida de resultados 
    //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("----------");        
        // se muestra el resultado
        System.out.println("Considerando la información anterior, ¿debo salir a la calle?\n" + ((salirCalle)? "SI":"NO") ); // se muestra el resultado
        System.out.println ();
        System.out.println ("Fin del programa.");           
    }
}
